#!/usr/bin/env python3
"""
Lin64x Sudo Commands
Tool for running elevated (sudo) commands on Linux.
Includes safety warnings and Windows alternative notes.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox, simpledialog, font as tkfont
import subprocess
import threading
import platform
import os
import sys

class SudoCommands:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Sudo Commands")
        self.root.geometry("850x580")
        self.root.configure(bg="#1a1a1a")

        self.is_linux = platform.system() == "Linux"
        self.is_windows = platform.system() == "Windows"
        self.mono = tkfont.Font(family="Consolas", size=11)

        self.create_ui()
        self.write_warning()

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#2d2d2d", height=50)
        header.pack(fill="x")
        tk.Label(header, text="Sudo Commands", font=("Segoe UI", 16, "bold"),
                 fg="#ff6b6b", bg="#2d2d2d").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="Elevated privilege tool", font=("Segoe UI", 10),
                 fg="#aaa", bg="#2d2d2d").pack(side="left")

        # Output
        self.output = scrolledtext.ScrolledText(
            self.root, bg="#1a1a1a", fg="#d4d4d4", insertbackground="#ffffff",
            font=self.mono, relief="flat"
        )
        self.output.pack(fill="both", expand=True, padx=8, pady=8)
        self.output.tag_config("warning", foreground="#ff6b6b")
        self.output.tag_config("info", foreground="#58a6ff")
        self.output.tag_config("success", foreground="#4ec9b0")
        self.output.tag_config("error", foreground="#f44747")

        # Input
        input_frame = tk.Frame(self.root, bg="#1a1a1a")
        input_frame.pack(fill="x", padx=8, pady=(0, 8))

        tk.Label(input_frame, text="sudo", fg="#ff6b6b", bg="#1a1a1a", font=self.mono).pack(side="left")
        self.entry = tk.Entry(input_frame, bg="#252526", fg="#ffffff", insertbackground="#ffffff",
                              font=self.mono, relief="flat")
        self.entry.pack(side="left", fill="x", expand=True, padx=6)
        self.entry.bind("<Return>", self.on_run)

        tk.Button(input_frame, text="Run", command=self.on_run, bg="#c42b1c", fg="white",
                  relief="flat", padx=12).pack(side="left")

        # Quick actions
        quick = tk.Frame(self.root, bg="#1a1a1a")
        quick.pack(fill="x", padx=8, pady=(0, 6))
        tk.Label(quick, text="Quick:", fg="#888", bg="#1a1a1a").pack(side="left")
        for label, cmd in [("whoami", "whoami"), ("apt update", "apt update"), ("systemctl status", "systemctl status")]:
            tk.Button(quick, text=label, command=lambda c=cmd: self.set_and_run(c),
                      bg="#3c3c3c", fg="white", relief="flat").pack(side="left", padx=3)

        # Status
        status_text = "Linux" if self.is_linux else ("Windows (limited)" if self.is_windows else platform.system())
        self.status = tk.Label(self.root, text=f"Sudo Commands | {status_text}",
                               bg="#2d2d2d", fg="#888", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def write_warning(self):
        warning = """⚠️  WARNING: Sudo Commands Tool

This tool runs commands with elevated privileges (sudo) on Linux.
- Commands are executed as root
- There is no undo
- Incorrect commands can damage your system
- Password is requested by the system sudo prompt (not stored by this app)

On Windows: sudo is not native. Use Linux4_(Cmd) or run as Administrator instead.
Always double-check commands before running.
"""
        self.output.insert("end", warning, "warning")
        self.output.see("end")

    def set_and_run(self, cmd):
        self.entry.delete(0, "end")
        self.entry.insert(0, cmd)
        self.on_run()

    def is_command_safe(self, cmd):
        """Basic safety classification for sudo commands."""
        cmd_lower = cmd.lower().strip()
        dangerous_patterns = [
            "rm -rf", "rm -r /", "mkfs", "dd ", "shutdown", "reboot", "halt",
            "passwd", "userdel", "groupdel", "chmod 777", "chown -r /",
            "mv /", "cp /dev", "> /dev", "format", "fdisk", "parted"
        ]
        caution_patterns = [
            "apt remove", "apt purge", "dnf remove", "pacman -R",
            "systemctl stop", "systemctl disable", "kill", "pkill"
        ]
        for pat in dangerous_patterns:
            if pat in cmd_lower:
                return "dangerous", "This command looks DANGEROUS and could damage your system."
        for pat in caution_patterns:
            if pat in cmd_lower:
                return "caution", "This command should be used with caution."
        return "safe", "This command appears relatively safe."

    def on_run(self, event=None):
        cmd = self.entry.get().strip()
        if not cmd:
            return
        self.entry.delete(0, "end")

        if not self.is_linux:
            self.output.insert("end", f"\n[Not Linux] Cannot run sudo here.\nCommand was: {cmd}\n", "error")
            self.output.see("end")
            return

        # Safety check
        level, message = self.is_command_safe(cmd)
        self.output.insert("end", f"\n--- Safety Check ---\n", "info")
        if level == "dangerous":
            self.output.insert("end", f"⚠️  DANGEROUS: {message}\n", "error")
            title = "DANGEROUS Command"
            prompt = f"⚠️ This command looks DANGEROUS:\n\nsudo {cmd}\n\n{message}\n\nType YES to confirm you want to run it:"
        elif level == "caution":
            self.output.insert("end", f"⚠️  CAUTION: {message}\n", "warning")
            title = "Caution"
            prompt = f"This command needs caution:\n\nsudo {cmd}\n\n{message}\n\nRun it? (Yes/No)"
        else:
            self.output.insert("end", f"✓ SAFE: {message}\n", "success")
            title = "Confirm Command"
            prompt = f"Command appears safe:\n\nsudo {cmd}\n\n{message}\n\nRun it? (Yes/No)"

        # y/n confirmation
        if level == "dangerous":
            answer = simpledialog.askstring(title, prompt)
            confirmed = answer and answer.strip().upper() == "YES"
        else:
            confirmed = messagebox.askyesno(title, prompt)

        if not confirmed:
            self.output.insert("end", "Cancelled by user (n).\n", "info")
            self.output.see("end")
            return

        self.output.insert("end", "Confirmed (y). Running...\n", "success")
        self.output.insert("end", f"$ sudo {cmd}\n", "info")
        self.run_sudo(cmd)

    def run_sudo(self, cmd):
        def worker():
            try:
                # Use sudo -S to allow password from stdin if needed, but prefer interactive
                # For simplicity and safety, run with sudo and let the system handle auth
                full = f"sudo {cmd}"
                result = subprocess.run(
                    full, shell=True,
                    capture_output=True, text=True, timeout=120
                )
                output = result.stdout
                if result.stderr:
                    output += result.stderr
                if not output.strip():
                    output = f"[Exit code {result.returncode}]\n"
                tag = "success" if result.returncode == 0 else "error"
                self.root.after(0, lambda: self.append(output, tag))
            except subprocess.TimeoutExpired:
                self.root.after(0, lambda: self.append("Command timed out.\n", "error"))
            except Exception as e:
                self.root.after(0, lambda: self.append(f"Error: {e}\n", "error"))

        threading.Thread(target=worker, daemon=True).start()

    def append(self, text, tag=None):
        self.output.insert("end", text, tag)
        self.output.see("end")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 425
    y = (root.winfo_screenheight() // 2) - 290
    root.geometry(f"+{x}+{y}")
    app = SudoCommands(root)
    root.mainloop()

if __name__ == "__main__":
    main()
