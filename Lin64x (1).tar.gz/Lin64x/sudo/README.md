# Sudo Commands

Elevated privilege tool for Lin64x (Linux-focused).

## Safety Features
- Automatic safety classification (safe / caution / dangerous)
- y/n confirmation required before every command
- Dangerous commands require typing "YES" to confirm
- Clear warnings displayed in the console

## Important
This tool executes commands as root. Use with extreme caution.
Password authentication is handled by the system `sudo` (not stored by the app).

## Run
```bash
python sudo/sudo_commands.py
```

On Windows this tool is limited — use Linux4_(Cmd) or run tools as Administrator instead.
