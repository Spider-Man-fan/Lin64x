#!/usr/bin/env python3
"""
terminate64xlin - Lin64x Process Terminator
Terminate running apps/processes using Python (with optional Java note).
Includes safety confirmations.
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import platform
import subprocess
import os
import sys

class Terminate64xlin:
    def __init__(self, root):
        self.root = root
        self.root.title("terminate64xlin")
        self.root.geometry("900x620")
        self.root.configure(bg="#1e1e1e")

        self.is_linux = platform.system() == "Linux"
        self.is_windows = platform.system() == "Windows"

        self.create_ui()
        self.refresh_processes()

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#c42b1c", height=50)
        header.pack(fill="x")
        tk.Label(header, text="terminate64xlin", font=("Segoe UI", 16, "bold"),
                 fg="white", bg="#c42b1c").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="Terminate apps / processes", font=("Segoe UI", 10),
                 fg="#ffcccc", bg="#c42b1c").pack(side="left")

        # Warning
        warn = tk.Label(self.root, text="⚠️  Terminating processes can cause data loss. Confirm before killing.",
                        bg="#3c1f1f", fg="#ff6b6b", font=("Segoe UI", 9))
        warn.pack(fill="x")

        # Toolbar
        toolbar = tk.Frame(self.root, bg="#1e1e1e")
        toolbar.pack(fill="x", padx=8, pady=6)
        tk.Button(toolbar, text="Refresh", command=self.refresh_processes, bg="#3c3c3c", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Terminate Selected", command=self.terminate_selected, bg="#c42b1c", fg="white",
                  relief="flat", padx=10).pack(side="left", padx=4)
        tk.Button(toolbar, text="Terminate by Name", command=self.terminate_by_name, bg="#8b0000", fg="white",
                  relief="flat").pack(side="left", padx=4)

        # Process list
        list_frame = tk.Frame(self.root, bg="#1e1e1e")
        list_frame.pack(fill="both", expand=True, padx=8, pady=4)

        self.tree = ttk.Treeview(list_frame, columns=("pid", "user", "cpu", "mem"), show="tree headings")
        self.tree.heading("#0", text="Process / App")
        self.tree.heading("pid", text="PID")
        self.tree.heading("user", text="User")
        self.tree.heading("cpu", text="CPU")
        self.tree.heading("mem", text="Memory")
        self.tree.column("#0", width=280)
        self.tree.column("pid", width=80)
        self.tree.column("user", width=100)
        self.tree.column("cpu", width=60)
        self.tree.column("mem", width=80)
        self.tree.pack(side="left", fill="both", expand=True)

        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")

        # Log
        self.log = scrolledtext.ScrolledText(self.root, height=6, bg="#252526", fg="#d4d4d4",
                                              font=("Consolas", 9), relief="flat")
        self.log.pack(fill="x", padx=8, pady=4)
        self.log.tag_config("ok", foreground="#4ec9b0")
        self.log.tag_config("err", foreground="#f44747")
        self.log.tag_config("info", foreground="#58a6ff")

        # Status
        self.status = tk.Label(self.root, text="Ready", bg="#c42b1c", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def log_msg(self, text, tag="info"):
        self.log.insert("end", text + "\n", tag)
        self.log.see("end")

    def refresh_processes(self):
        self.tree.delete(*self.tree.get_children())
        self.log_msg("Refreshing process list...", "info")
        try:
            if self.is_linux:
                result = subprocess.check_output(["ps", "aux"], text=True, timeout=10)
                lines = result.strip().splitlines()[1:]  # skip header
                for line in lines[:80]:
                    parts = line.split(None, 10)
                    if len(parts) >= 11:
                        user, pid, cpu, mem, cmd = parts[0], parts[1], parts[2], parts[3], parts[10]
                        self.tree.insert("", "end", text=cmd[:60], values=(pid, user, cpu, mem))
            elif self.is_windows:
                result = subprocess.check_output(["tasklist", "/FO", "CSV", "/NH"], text=True, timeout=10)
                for line in result.strip().splitlines()[:80]:
                    parts = [p.strip('"') for p in line.split('","')]
                    if len(parts) >= 5:
                        name, pid, mem = parts[0], parts[1], parts[4]
                        self.tree.insert("", "end", text=name, values=(pid, "-", "-", mem))
            else:
                self.log_msg("Process listing not supported on this platform.", "err")
        except Exception as e:
            self.log_msg(f"Error listing processes: {e}", "err")
        self.status.config(text=f"{len(self.tree.get_children())} processes listed")

    def terminate_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("terminate64xlin", "Select a process first.")
            return
        item = self.tree.item(sel[0])
        name = item["text"]
        pid = item["values"][0]
        if not messagebox.askyesno("Confirm Terminate",
                                   f"Terminate this process?\n\n{name}\nPID: {pid}\n\nThis cannot be undone."):
            self.log_msg("Cancelled.", "info")
            return
        self.kill_pid(pid, name)

    def terminate_by_name(self):
        name = tk.simpledialog.askstring("Terminate by Name", "Process / app name (partial match):")
        if not name:
            return
        if not messagebox.askyesno("Confirm", f"Terminate all processes matching '{name}'?"):
            return
        self.kill_by_name(name)

    def kill_pid(self, pid, name=""):
        try:
            if self.is_linux:
                subprocess.run(["kill", "-15", str(pid)], check=False, timeout=5)
                self.log_msg(f"Sent SIGTERM to PID {pid} ({name})", "ok")
            elif self.is_windows:
                subprocess.run(["taskkill", "/PID", str(pid), "/F"], check=False, timeout=5)
                self.log_msg(f"Terminated PID {pid} ({name})", "ok")
            else:
                self.log_msg("Terminate not supported.", "err")
                return
            self.root.after(500, self.refresh_processes)
        except Exception as e:
            self.log_msg(f"Failed to terminate: {e}", "err")

    def kill_by_name(self, name):
        try:
            if self.is_linux:
                subprocess.run(["pkill", "-f", name], check=False, timeout=5)
                self.log_msg(f"Sent terminate to processes matching '{name}'", "ok")
            elif self.is_windows:
                subprocess.run(["taskkill", "/IM", f"{name}*", "/F"], check=False, timeout=5)
                self.log_msg(f"Terminated processes matching '{name}'", "ok")
            self.root.after(500, self.refresh_processes)
        except Exception as e:
            self.log_msg(f"Error: {e}", "err")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 310
    root.geometry(f"+{x}+{y}")
    app = Terminate64xlin(root)
    root.mainloop()

if __name__ == "__main__":
    main()
