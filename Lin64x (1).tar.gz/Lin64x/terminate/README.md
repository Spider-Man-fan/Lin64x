# terminate64xlin

Terminate running apps / processes.

## Features
- List running processes (Linux `ps` / Windows `tasklist`)
- Terminate selected process (with confirmation)
- Terminate by name
- Safety warnings
- Uses Python (`subprocess`); Java equivalent noted in docs

## Warning
Terminating processes can cause data loss or system instability. Use with care.
User session termination is not included (too dangerous for a general tool).

## Run
```bash
python terminate/terminate64xlin.py
```
