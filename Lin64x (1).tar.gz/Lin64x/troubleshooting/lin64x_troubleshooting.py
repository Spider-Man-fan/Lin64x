#!/usr/bin/env python3
"""
Lin64x(problem and troubleshooting)
Diagnostic and troubleshooting tool for common Linux issues.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import platform
import subprocess
import os
import sys
from pathlib import Path

class TroubleshootingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x(problem and troubleshooting)")
        self.root.geometry("950x650")
        self.root.configure(bg="#1e1e1e")

        self.is_linux = platform.system() == "Linux"
        self.project_root = Path(__file__).parent.parent

        self.create_ui()
        self.show_overview()

    def create_ui(self):
        # Sidebar
        sidebar = tk.Frame(self.root, bg="#252526", width=240)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        tk.Label(sidebar, text="Troubleshooting", font=("Segoe UI", 14, "bold"),
                 bg="#252526", fg="#ffffff").pack(pady=15, padx=10, anchor="w")
        tk.Label(sidebar, text="Lin64x", font=("Segoe UI", 9),
                 bg="#252526", fg="#888").pack(padx=10, anchor="w")

        problems = [
            ("Overview", self.show_overview),
            ("Boot Problems", self.show_boot),
            ("Network Issues", self.show_network),
            ("Package / Updates", self.show_packages),
            ("Permissions", self.show_permissions),
            ("Display / Graphics", self.show_display),
            ("Disk / Storage", self.show_disk),
            ("Services", self.show_services),
            ("Quick Fixes", self.show_quick_fixes),
        ]
        for name, cmd in problems:
            btn = tk.Button(sidebar, text=name, font=("Segoe UI", 10),
                            bg="#252526", fg="#cccccc", relief="flat", anchor="w",
                            command=cmd)
            btn.pack(fill="x", padx=6, pady=1)

        # Content
        self.content = tk.Frame(self.root, bg="#1e1e1e")
        self.content.pack(side="right", fill="both", expand=True)

    def clear(self):
        for w in self.content.winfo_children():
            w.destroy()

    def add_title(self, title):
        tk.Label(self.content, text=title, font=("Segoe UI", 18, "bold"),
                 bg="#1e1e1e", fg="#ffffff").pack(pady=12, padx=20, anchor="w")

    def add_text(self, text):
        box = scrolledtext.ScrolledText(self.content, bg="#1e1e1e", fg="#d4d4d4",
                                         font=("Consolas", 10), relief="flat")
        box.pack(fill="both", expand=True, padx=20, pady=8)
        box.insert("1.0", text)
        box.config(state="disabled")

    def add_buttons(self, buttons):
        frame = tk.Frame(self.content, bg="#1e1e1e")
        frame.pack(pady=6)
        for text, cmd in buttons:
            tk.Button(frame, text=text, command=cmd, bg="#0078d4", fg="white",
                      relief="flat", padx=10, pady=4).pack(side="left", padx=4)

    def show_overview(self):
        self.clear()
        self.add_title("Lin64x Troubleshooting")
        text = """Common Linux problem categories:

• Boot Problems      — GRUB, kernel, dual-boot
• Network Issues     — No internet, DNS, Wi-Fi
• Package / Updates  — Broken packages, failed upgrades
• Permissions        — Access denied, ownership
• Display / Graphics — Black screen, resolution
• Disk / Storage     — Full disk, mount errors
• Services           — Failed systemd units

Select a category on the left for details and suggested fixes.

Tip: Use Sudo Commands or Linux4_(Cmd) to run the suggested commands.
"""
        self.add_text(text)
        self.add_buttons([
            ("Open Sudo Tool", self.open_sudo),
            ("Open Cmd", self.open_cmd),
            ("Open Settings", self.open_settings),
        ])

    def show_boot(self):
        self.clear()
        self.add_title("Boot Problems")
        text = """Common boot issues and fixes:

1. GRUB not showing / Windows missing
   sudo update-grub
   sudo grub-install /dev/sdX

2. Kernel panic or failed boot
   - Boot older kernel from GRUB Advanced options
   - Check /var/log/boot.log or journalctl -b -1

3. Dual-boot time issues
   timedatectl set-local-rtc 1

4. Black screen after update
   - Add nomodeset to GRUB kernel line temporarily
   - Reinstall graphics drivers

Always backup important data before bootloader changes.
"""
        self.add_text(text)

    def show_network(self):
        self.clear()
        self.add_title("Network Issues")
        text = """Network troubleshooting steps:

1. Check interface
   ip link
   ip addr

2. Restart networking
   sudo systemctl restart NetworkManager
   # or
   sudo systemctl restart systemd-networkd

3. DNS problems
   ping 8.8.8.8
   cat /etc/resolv.conf

4. Wi-Fi
   nmcli device wifi list
   nmcli device wifi connect "SSID" password "pass"

5. Firewall blocking
   sudo ufw status
   sudo ufw allow 80/tcp
"""
        self.add_text(text)

    def show_packages(self):
        self.clear()
        self.add_title("Package / Updates")
        text = """Package manager fixes:

Debian/Ubuntu:
  sudo apt update
  sudo apt --fix-broken install
  sudo dpkg --configure -a
  sudo apt full-upgrade

Arch:
  sudo pacman -Syu
  sudo pacman -Syyu

Fedora:
  sudo dnf update
  sudo dnf distro-sync

Clear cache if disk is full:
  sudo apt clean
  sudo pacman -Sc
"""
        self.add_text(text)

    def show_permissions(self):
        self.clear()
        self.add_title("Permissions")
        text = """Permission troubleshooting:

1. Check ownership
   ls -l /path/to/file
   sudo chown user:user /path

2. Fix home directory permissions
   sudo chown -R $USER:$USER ~

3. Executable bit
   chmod +x script.sh

4. Sudo issues
   sudo -l
   Check /etc/sudoers (use visudo)

Never run chmod 777 on system directories.
"""
        self.add_text(text)

    def show_display(self):
        self.clear()
        self.add_title("Display / Graphics")
        text = """Display and graphics issues:

1. Resolution / multi-monitor
   xrandr
   arandr (GUI)

2. NVIDIA
   sudo ubuntu-drivers autoinstall
   # or
   sudo pacman -S nvidia

3. Wayland vs X11
   Log out and choose session at login screen

4. Black screen
   - Boot with nomodeset
   - Check journalctl -b | grep -i drm
"""
        self.add_text(text)

    def show_disk(self):
        self.clear()
        self.add_title("Disk / Storage")
        text = """Disk and storage problems:

1. Check space
   df -h
   du -sh /* 2>/dev/null | sort -h

2. Mount issues
   lsblk
   sudo mount /dev/sdXY /mnt
   Check /etc/fstab

3. Filesystem check (unmounted)
   sudo fsck /dev/sdXY

4. Clean old kernels / logs
   sudo journalctl --vacuum-size=100M
"""
        self.add_text(text)

    def show_services(self):
        self.clear()
        self.add_title("Services")
        text = """Systemd service troubleshooting:

1. Check failed services
   systemctl --failed
   systemctl status service-name

2. Restart a service
   sudo systemctl restart NetworkManager
   sudo systemctl restart ssh

3. View logs
   journalctl -u service-name -e
   journalctl -b -p err

4. Enable on boot
   sudo systemctl enable --now service-name
"""
        self.add_text(text)

    def show_quick_fixes(self):
        self.clear()
        self.add_title("Quick Fixes")
        text = """One-line quick fixes (run with care):

• Update package lists
  sudo apt update || sudo pacman -Sy

• Fix broken packages
  sudo apt --fix-broken install

• Restart display manager
  sudo systemctl restart gdm   # or sddm / lightdm

• Flush DNS
  sudo systemd-resolve --flush-caches

• Check listening ports
  ss -tuln

Use the Sudo Commands tool for elevated operations.
"""
        self.add_text(text)
        self.add_buttons([
            ("Open Sudo Tool", self.open_sudo),
            ("Open Cmd", self.open_cmd),
        ])

    def open_sudo(self):
        path = self.project_root / "sudo" / "sudo_commands.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

    def open_cmd(self):
        path = self.project_root / "cmd" / "linux4_cmd.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

    def open_settings(self):
        path = self.project_root / "settings" / "settings_linux_windows.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 475
    y = (root.winfo_screenheight() // 2) - 325
    root.geometry(f"+{x}+{y}")
    app = TroubleshootingApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
