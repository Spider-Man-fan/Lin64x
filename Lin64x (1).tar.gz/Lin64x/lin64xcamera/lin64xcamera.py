#!/usr/bin/env python3
"""
lin64xcamera - Lin64x Camera
Simple camera viewer and capture tool.
Uses OpenCV if available, otherwise shows a placeholder.
"""

import tkinter as tk
from tkinter import messagebox, filedialog
import platform
import os
from pathlib import Path
from datetime import datetime

# Try optional OpenCV
try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

class Lin64xCamera:
    def __init__(self, root):
        self.root = root
        self.root.title("lin64xcamera")
        self.root.geometry("800x600")
        self.root.configure(bg="#1a1a1a")

        self.cap = None
        self.running = False
        self.current_frame = None

        self.create_ui()
        if HAS_CV2:
            self.start_camera()
        else:
            self.show_placeholder()

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#252526", height=46)
        header.pack(fill="x")
        tk.Label(header, text="lin64xcamera", font=("Segoe UI", 16, "bold"),
                 fg="#ffffff", bg="#252526").pack(side="left", padx=15, pady=8)
        status = "OpenCV ready" if HAS_CV2 else "OpenCV not installed"
        tk.Label(header, text=status, font=("Segoe UI", 9),
                 fg="#888", bg="#252526").pack(side="left")

        # Video area
        self.video_label = tk.Label(self.root, bg="#000000", fg="#666",
                                     text="Camera preview", font=("Segoe UI", 14))
        self.video_label.pack(fill="both", expand=True, padx=10, pady=10)

        # Controls
        controls = tk.Frame(self.root, bg="#1a1a1a")
        controls.pack(fill="x", pady=8)
        tk.Button(controls, text="Start", command=self.start_camera, bg="#107c10", fg="white",
                  relief="flat", padx=12).pack(side="left", padx=6)
        tk.Button(controls, text="Stop", command=self.stop_camera, bg="#c42b1c", fg="white",
                  relief="flat", padx=12).pack(side="left", padx=6)
        tk.Button(controls, text="Capture", command=self.capture, bg="#0078d4", fg="white",
                  relief="flat", padx=12).pack(side="left", padx=6)
        tk.Button(controls, text="Save Last", command=self.save_last, bg="#5c2d91", fg="white",
                  relief="flat", padx=12).pack(side="left", padx=6)

        self.status = tk.Label(self.root, text="Ready", bg="#0078d4", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def show_placeholder(self):
        self.video_label.config(
            text="Camera not available\n\nInstall OpenCV for live preview:\n  pip install opencv-python\n\n"
                 "On Linux you may also need camera permissions.",
            fg="#888"
        )
        self.status.config(text="OpenCV missing — placeholder mode")

    def start_camera(self):
        if not HAS_CV2:
            messagebox.showinfo("lin64xcamera", "OpenCV is not installed.\nInstall with: pip install opencv-python")
            return
        if self.running:
            return
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            messagebox.showwarning("Camera", "Could not open camera (device 0).")
            self.status.config(text="Camera open failed")
            return
        self.running = True
        self.status.config(text="Camera running")
        self.update_frame()

    def update_frame(self):
        if not self.running or not self.cap:
            return
        ret, frame = self.cap.read()
        if ret:
            self.current_frame = frame
            # Convert to PhotoImage-compatible format
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # Resize for display
            h, w = frame_rgb.shape[:2]
            scale = min(760 / w, 460 / h, 1.0)
            if scale < 1.0:
                frame_rgb = cv2.resize(frame_rgb, (int(w * scale), int(h * scale)))
            from PIL import Image, ImageTk
            img = Image.fromarray(frame_rgb)
            imgtk = ImageTk.PhotoImage(image=img)
            self.video_label.imgtk = imgtk
            self.video_label.config(image=imgtk, text="")
        self.root.after(30, self.update_frame)

    def stop_camera(self):
        self.running = False
        if self.cap:
            self.cap.release()
            self.cap = None
        self.video_label.config(image="", text="Camera stopped")
        self.status.config(text="Stopped")

    def capture(self):
        if self.current_frame is None:
            messagebox.showinfo("Capture", "No frame available. Start the camera first.")
            return
        self.last_capture = self.current_frame.copy()
        self.status.config(text="Frame captured — use Save Last")
        messagebox.showinfo("lin64xcamera", "Frame captured.")

    def save_last(self):
        if not hasattr(self, "last_capture") or self.last_capture is None:
            messagebox.showinfo("Save", "No captured frame. Press Capture first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg")],
            initialfile=f"lin64x_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        )
        if path and HAS_CV2:
            cv2.imwrite(path, self.last_capture)
            self.status.config(text=f"Saved: {os.path.basename(path)}")
            messagebox.showinfo("Saved", f"Saved to:\n{path}")

    def on_close(self):
        self.stop_camera()
        self.root.destroy()

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 400
    y = (root.winfo_screenheight() // 2) - 300
    root.geometry(f"+{x}+{y}")
    app = Lin64xCamera(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()

if __name__ == "__main__":
    main()
