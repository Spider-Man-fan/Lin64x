# lin64xcamera

Lin64x Camera app.

## Features
- Live camera preview (requires OpenCV)
- Start / Stop
- Capture frame
- Save captured image
- Placeholder mode if OpenCV is not installed

## Optional dependency
```bash
pip install opencv-python
# For image display you may also want:
pip install pillow
```

## Run
```bash
python lin64xcamera/lin64xcamera.py
```

On Linux, ensure your user has access to the camera device (`/dev/video0`).
