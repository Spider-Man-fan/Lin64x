# App Fixer

Diagnose and fix common Lin64x app issues.

## Features
- Run Checks — verify core apps and config
- Fix Permissions — set executable bit on Linux
- Clear Cache — remove `__pycache__` and `.pyc`
- Reinstall Tips — common fix steps

## Run
```bash
python app_fixer/app_fixer.py
```
