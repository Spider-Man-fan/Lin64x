#!/usr/bin/env python3
"""
Lin64x App Fixer
Diagnose and fix common issues with Lin64x apps.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox, ttk
import platform
import subprocess
import sys
import os
from pathlib import Path

class AppFixer:
    def __init__(self, root):
        self.root = root
        self.root.title("App Fixer — Lin64x")
        self.root.geometry("860x600")
        self.root.configure(bg="#1e1e1e")

        self.project_root = Path(__file__).parent.parent
        self.is_linux = platform.system() == "Linux"
        self.is_windows = platform.system() == "Windows"

        self.create_ui()
        self.run_checks()

    def create_ui(self):
        header = tk.Frame(self.root, bg="#0078d4", height=50)
        header.pack(fill="x")
        tk.Label(header, text="App Fixer", font=("Segoe UI", 16, "bold"),
                 fg="white", bg="#0078d4").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="Diagnose & Repair", font=("Segoe UI", 10),
                 fg="#e0e0e0", bg="#0078d4").pack(side="left")

        toolbar = tk.Frame(self.root, bg="#1e1e1e")
        toolbar.pack(fill="x", padx=8, pady=6)
        tk.Button(toolbar, text="Run Checks", command=self.run_checks, bg="#0078d4", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Fix Permissions", command=self.fix_permissions, bg="#107c10", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Clear Cache", command=self.clear_cache, bg="#ff8c00", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Reinstall Tips", command=self.show_reinstall, bg="#5c2d91", fg="white",
                  relief="flat").pack(side="left", padx=4)

        self.output = scrolledtext.ScrolledText(self.root, bg="#1e1e1e", fg="#d4d4d4",
                                                 font=("Consolas", 10), relief="flat")
        self.output.pack(fill="both", expand=True, padx=8, pady=4)
        self.output.tag_config("ok", foreground="#4ec9b0")
        self.output.tag_config("warn", foreground="#ffcc00")
        self.output.tag_config("err", foreground="#f44747")
        self.output.tag_config("info", foreground="#58a6ff")

        self.status = tk.Label(self.root, text="Ready", bg="#0078d4", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def log(self, text, tag="info"):
        self.output.insert("end", text + "\n", tag)
        self.output.see("end")

    def run_checks(self):
        self.output.delete("1.0", "end")
        self.log("=== App Fixer Checks ===", "info")
        self.log(f"Platform: {platform.system()} {platform.release()}")
        self.log(f"Python: {sys.version.split()[0]}")
        self.log(f"Project: {self.project_root}")
        self.log("")

        # Check key apps
        apps = [
            "os_apps/desktop.py",
            "settings/settings_linux_windows.py",
            "cmd_sudo/cmd_sudo.py",
            "software_maker/lin64x_software_maker.py",
            "web/web.py",
            "lin64xfile/lin64xfile.py",
        ]
        missing = 0
        for app in apps:
            path = self.project_root / app
            if path.exists():
                self.log(f"OK  {app}", "ok")
            else:
                self.log(f"MISSING  {app}", "err")
                missing += 1

        # Check config files
        self.log("")
        self.log("--- Config files ---", "info")
        home = Path.home()
        for name in [".lin64x_accounts.json", ".lin64x_config.json"]:
            p = home / name
            if p.exists():
                self.log(f"Found  {name}", "ok")
            else:
                self.log(f"Not found  {name} (will be created when needed)", "warn")

        # Check optional tools
        self.log("")
        self.log("--- Optional tools ---", "info")
        for cmd in ["git", "python3", "pip"]:
            found = shutil_which(cmd)
            if found:
                self.log(f"OK  {cmd}", "ok")
            else:
                self.log(f"Missing  {cmd}", "warn")

        self.log("")
        if missing == 0:
            self.log("All core apps present.", "ok")
            self.status.config(text="Checks passed")
        else:
            self.log(f"{missing} app(s) missing. Re-extract the archive.", "err")
            self.status.config(text=f"{missing} missing")

    def fix_permissions(self):
        self.log("\n--- Fix Permissions ---", "info")
        if not self.is_linux:
            self.log("Permission fix is mainly for Linux.", "warn")
            return
        count = 0
        for py in self.project_root.rglob("*.py"):
            try:
                py.chmod(0o755)
                count += 1
            except Exception:
                pass
        self.log(f"Set executable bit on {count} Python files.", "ok")
        self.status.config(text="Permissions updated")

    def clear_cache(self):
        self.log("\n--- Clear Cache ---", "info")
        removed = 0
        for pyc in self.project_root.rglob("__pycache__"):
            try:
                import shutil
                shutil.rmtree(pyc)
                removed += 1
            except Exception:
                pass
        for pyc in self.project_root.rglob("*.pyc"):
            try:
                pyc.unlink()
                removed += 1
            except Exception:
                pass
        self.log(f"Removed {removed} cache items.", "ok")
        self.status.config(text="Cache cleared")

    def show_reinstall(self):
        self.output.delete("1.0", "end")
        text = """=== Reinstall Tips ===

If an app will not start:

1. Re-extract Lin64x.tar.gz
2. Make sure you are in the Lin64x folder
3. Run with: python path/to/app.py
4. Check Python version (3.8+)
5. On Linux, run Fix Permissions
6. Clear Cache and try again

Common fixes:
• "No module named tkinter" → install python3-tk
• Permission denied → Fix Permissions button
• App missing → re-extract the archive

Desktop shell:
  python os_apps/desktop.py

Settings:
  python settings/settings_linux_windows.py
"""
        self.output.insert("1.0", text)
        self.status.config(text="Reinstall tips shown")

def shutil_which(cmd):
    import shutil
    return shutil.which(cmd)

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 430
    y = (root.winfo_screenheight() // 2) - 300
    root.geometry(f"+{x}+{y}")
    app = AppFixer(root)
    root.mainloop()

if __name__ == "__main__":
    main()
