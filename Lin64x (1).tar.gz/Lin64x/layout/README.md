# Layout Performance

Shows where Lin64x apps can be placed and a basic performance overview.

## Tabs
- **Layout** — Visual grid of app positions
- **Performance** — System info and estimated load
- **App List** — Full list with status and file sizes

## Run
```bash
python layout/layout_performance.py
```
