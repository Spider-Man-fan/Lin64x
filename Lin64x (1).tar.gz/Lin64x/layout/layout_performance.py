#!/usr/bin/env python3
"""
Layout Performance - Lin64x
Shows where apps can be placed and basic performance overview.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
import platform
import os
import sys
from pathlib import Path

class LayoutPerformance:
    def __init__(self, root):
        self.root = root
        self.root.title("Layout Performance")
        self.root.geometry("980x680")
        self.root.configure(bg="#1e1e1e")

        self.project_root = Path(__file__).parent.parent
        self.apps = self.discover_apps()

        self.create_ui()
        self.show_layout()

    def discover_apps(self):
        """List known Lin64x apps and their locations."""
        known = [
            ("Desktop Shell", "os_apps/desktop.py"),
            ("Software Maker", "software_maker/lin64x_software_maker.py"),
            ("ai chaticon", "ai_chaticon/ai_chaticon.py"),
            ("web", "web/web.py"),
            ("Settings", "settings/settings_linux_windows.py"),
            ("Security", "security/lin64x_security.py"),
            ("Linux4_(Cmd)", "cmd/linux4_cmd.py"),
            ("win64x(PowerShell)", "powershell/win64x_powershell.py"),
            ("Sudo Commands", "sudo/sudo_commands.py"),
            ("Troubleshooting", "troubleshooting/lin64x_troubleshooting.py"),
            ("VMware", "vmware/lin64x_vmware.py"),
            ("Kali Linux", "kali/lin64x_kali.py"),
            ("Lin(python)", "python/lin_python.py"),
            ("python.lin32", "python/python_lin32.py"),
            ("Win32x64(notepad)", "notepad/win32x64_notepad.py"),
            ("OOBE Wizard", "oobe/oobe_wizard.py"),
            ("SD Save Card", "sd_card/digital_save.py"),
            ("Code Editor", "editor/lin64x_editor.py"),
            ("File Explorer", "os_apps/file_explorer.py"),
        ]
        result = []
        for name, rel in known:
            path = self.project_root / rel
            result.append({
                "name": name,
                "path": str(path),
                "exists": path.exists(),
                "size": path.stat().st_size if path.exists() else 0,
            })
        return result

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#252526", height=50)
        header.pack(fill="x")
        tk.Label(header, text="Layout Performance", font=("Segoe UI", 16, "bold"),
                 fg="#ffffff", bg="#252526").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="App layout & performance overview", font=("Segoe UI", 10),
                 fg="#888", bg="#252526").pack(side="left")

        # Notebook
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=8, pady=8)

        self.tab_layout = tk.Frame(self.notebook, bg="#1e1e1e")
        self.tab_perf = tk.Frame(self.notebook, bg="#1e1e1e")
        self.tab_list = tk.Frame(self.notebook, bg="#1e1e1e")

        self.notebook.add(self.tab_layout, text="Layout")
        self.notebook.add(self.tab_perf, text="Performance")
        self.notebook.add(self.tab_list, text="App List")

        self.build_layout_tab()
        self.build_perf_tab()
        self.build_list_tab()

        # Status
        self.status = tk.Label(self.root, text="Ready", bg="#0078d4", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def build_layout_tab(self):
        canvas = tk.Canvas(self.tab_layout, bg="#1e1e1e", highlightthickness=0)
        canvas.pack(fill="both", expand=True, padx=10, pady=10)

        # Simple visual grid of app slots
        tk.Label(self.tab_layout, text="App Layout Grid (where apps can be placed)",
                 bg="#1e1e1e", fg="#cccccc", font=("Segoe UI", 11)).pack(anchor="w", padx=12)

        grid_frame = tk.Frame(self.tab_layout, bg="#1e1e1e")
        grid_frame.pack(fill="both", expand=True, padx=12, pady=8)

        positions = [
            (0, 0, "Desktop"), (1, 0, "Software Maker"), (2, 0, "web"),
            (0, 1, "ai chaticon"), (1, 1, "Settings"), (2, 1, "Security"),
            (0, 2, "Cmd"), (1, 2, "PowerShell"), (2, 2, "Sudo"),
            (0, 3, "Troubleshooting"), (1, 3, "VMware"), (2, 3, "Kali"),
        ]
        for col, row, name in positions:
            cell = tk.Frame(grid_frame, bg="#2d2d30", width=180, height=70, relief="ridge", bd=1)
            cell.grid(row=row, column=col, padx=6, pady=6, sticky="nsew")
            cell.grid_propagate(False)
            tk.Label(cell, text=name, bg="#2d2d30", fg="#ffffff",
                     font=("Segoe UI", 9)).pack(expand=True)

        for i in range(3):
            grid_frame.columnconfigure(i, weight=1)

    def build_perf_tab(self):
        text = scrolledtext.ScrolledText(self.tab_perf, bg="#1e1e1e", fg="#d4d4d4",
                                          font=("Consolas", 10), relief="flat")
        text.pack(fill="both", expand=True, padx=10, pady=10)

        lines = ["=== Layout Performance Overview ===\n"]
        lines.append(f"Platform     : {platform.system()} {platform.release()}")
        lines.append(f"Python       : {sys.version.split()[0]}")
        lines.append(f"CPU Count    : {os.cpu_count()}")
        lines.append(f"Project Root : {self.project_root}\n")

        existing = sum(1 for a in self.apps if a["exists"])
        total = len(self.apps)
        lines.append(f"Apps found   : {existing} / {total}")
        lines.append(f"Missing      : {total - existing}\n")

        lines.append("--- Estimated Load ---")
        lines.append("Desktop Shell     : Low")
        lines.append("Software Maker    : Medium (code execution)")
        lines.append("web browser       : Low (launches system browser)")
        lines.append("Security          : Medium (process/firewall checks)")
        lines.append("Sudo Commands     : High (elevated execution)")
        lines.append("Kali reference    : Low")
        lines.append("VMware helper     : Low–Medium")
        lines.append("")
        lines.append("Tip: Launch heavy tools one at a time for best performance.")
        lines.append("Use Settings → Lin64xwin64P for processor details.")

        text.insert("1.0", "\n".join(lines))
        text.config(state="disabled")

    def build_list_tab(self):
        tree = ttk.Treeview(self.tab_list, columns=("status", "size", "path"), show="tree headings")
        tree.heading("#0", text="App")
        tree.heading("status", text="Status")
        tree.heading("size", text="Size")
        tree.heading("path", text="Location")
        tree.column("#0", width=180)
        tree.column("status", width=80)
        tree.column("size", width=80)
        tree.column("path", width=400)
        tree.pack(fill="both", expand=True, padx=8, pady=8)

        for app in self.apps:
            status = "OK" if app["exists"] else "Missing"
            size = f"{app['size']:,} B" if app["exists"] else "-"
            tree.insert("", "end", text=app["name"], values=(status, size, app["path"]))

        self.status.config(text=f"{len(self.apps)} apps listed")

    def show_layout(self):
        pass  # built in create_ui

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 490
    y = (root.winfo_screenheight() // 2) - 340
    root.geometry(f"+{x}+{y}")
    app = LayoutPerformance(root)
    root.mainloop()

if __name__ == "__main__":
    main()
