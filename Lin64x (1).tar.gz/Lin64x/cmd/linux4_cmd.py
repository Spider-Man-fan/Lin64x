#!/usr/bin/env python3
"""
Linux4_(Cmd) - Lin64x Command Prompt
Hybrid terminal that runs shell commands on Linux and Windows.
"""

import tkinter as tk
from tkinter import scrolledtext, font as tkfont
import subprocess
import threading
import os
import platform
import sys

class Linux4Cmd:
    def __init__(self, root):
        self.root = root
        self.root.title("Linux4_(Cmd)")
        self.root.geometry("900x550")
        self.root.configure(bg="#0c0c0c")

        self.is_linux = platform.system() == "Linux"
        self.is_windows = platform.system() == "Windows"
        self.cwd = os.getcwd()

        # Font
        self.mono = tkfont.Font(family="Consolas", size=11)

        self.create_ui()
        self.write_banner()
        self.prompt()

    def create_ui(self):
        # Output area
        self.output = scrolledtext.ScrolledText(
            self.root, bg="#0c0c0c", fg="#cccccc", insertbackground="#ffffff",
            font=self.mono, relief="flat", wrap="word"
        )
        self.output.pack(fill="both", expand=True, padx=5, pady=5)
        self.output.tag_config("prompt", foreground="#00ff00")
        self.output.tag_config("error", foreground="#ff6b6b")
        self.output.tag_config("info", foreground="#58a6ff")

        # Input line
        input_frame = tk.Frame(self.root, bg="#0c0c0c")
        input_frame.pack(fill="x", padx=5, pady=(0, 5))

        self.prompt_label = tk.Label(input_frame, text=">", fg="#00ff00", bg="#0c0c0c", font=self.mono)
        self.prompt_label.pack(side="left")

        self.entry = tk.Entry(input_frame, bg="#0c0c0c", fg="#ffffff", insertbackground="#ffffff",
                              font=self.mono, relief="flat", borderwidth=0)
        self.entry.pack(side="left", fill="x", expand=True, padx=5)
        self.entry.bind("<Return>", self.on_enter)
        self.entry.focus()

        # Status
        self.status = tk.Label(self.root, text=f"Linux4_(Cmd) | {platform.system()}",
                               bg="#1f1f1f", fg="#888888", anchor="w", font=("Segoe UI", 8))
        self.status.pack(fill="x", side="bottom")

    def write_banner(self):
        banner = """
Linux4_(Cmd) - Lin64x Hybrid Command Prompt
Type 'help' for commands. Works on Linux and Windows.
"""
        self.output.insert("end", banner, "info")
        self.output.see("end")

    def prompt(self):
        prompt_text = f"{self.cwd}> " if self.is_windows else f"{os.path.basename(self.cwd)}$ "
        self.prompt_label.config(text=prompt_text[-40:])  # keep it short

    def on_enter(self, event=None):
        cmd = self.entry.get().strip()
        self.entry.delete(0, "end")
        if not cmd:
            return

        # Echo command
        self.output.insert("end", f"{self.prompt_label.cget('text')}{cmd}\n", "prompt")
        self.output.see("end")

        # Built-in commands
        if cmd.lower() == "help":
            self.show_help()
            return
        if cmd.lower() == "clear" or cmd.lower() == "cls":
            self.output.delete("1.0", "end")
            self.write_banner()
            self.prompt()
            return
        if cmd.lower() == "exit":
            self.root.destroy()
            return
        if cmd.startswith("cd "):
            self.change_dir(cmd[3:].strip())
            return

        # Run external command
        self.run_command(cmd)

    def show_help(self):
        help_text = """
Built-in commands:
  help          Show this help
  clear / cls   Clear screen
  cd <path>     Change directory
  exit          Close Linux4_(Cmd)

Any other command is executed in the system shell.
Examples: ls / dir, python --version, ipconfig / ifconfig
"""
        self.output.insert("end", help_text, "info")
        self.output.see("end")
        self.prompt()

    def change_dir(self, path):
        try:
            new_path = os.path.abspath(os.path.join(self.cwd, path))
            if os.path.isdir(new_path):
                self.cwd = new_path
                os.chdir(self.cwd)
                self.output.insert("end", f"Changed to {self.cwd}\n")
            else:
                self.output.insert("end", f"Directory not found: {path}\n", "error")
        except Exception as e:
            self.output.insert("end", f"Error: {e}\n", "error")
        self.output.see("end")
        self.prompt()

    def run_command(self, cmd):
        def worker():
            try:
                shell = True
                result = subprocess.run(
                    cmd, shell=shell, cwd=self.cwd,
                    capture_output=True, text=True, timeout=30
                )
                output = result.stdout
                if result.stderr:
                    output += result.stderr
                if not output:
                    output = f"[Exit code {result.returncode}]\n"
                self.root.after(0, lambda: self.append_output(output))
            except subprocess.TimeoutExpired:
                self.root.after(0, lambda: self.append_output("Command timed out.\n", "error"))
            except Exception as e:
                self.root.after(0, lambda: self.append_output(f"Error: {e}\n", "error"))

        threading.Thread(target=worker, daemon=True).start()

    def append_output(self, text, tag=None):
        self.output.insert("end", text, tag)
        self.output.see("end")
        self.prompt()

def main():
    root = tk.Tk()
    # Center window
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 275
    root.geometry(f"+{x}+{y}")
    app = Linux4Cmd(root)
    root.mainloop()

if __name__ == "__main__":
    main()
