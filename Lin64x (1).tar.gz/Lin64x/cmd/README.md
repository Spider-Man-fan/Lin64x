# Linux4_(Cmd)

Hybrid command prompt for Lin64x.

## Features
- Runs system shell commands on Linux and Windows
- Built-in: help, clear/cls, cd, exit
- Dark terminal-style UI
- Working directory tracking

## Run
```bash
python cmd/linux4_cmd.py
```

Also available from the Desktop shell Start menu.
