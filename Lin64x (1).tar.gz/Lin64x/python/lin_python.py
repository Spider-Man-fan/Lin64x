#!/usr/bin/env python3
"""
Lin(python) - Lin64x Python Application
Main Python environment and launcher for the hybrid suite.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox, filedialog
import sys
import os
import platform
import subprocess
from pathlib import Path

class LinPython:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin(python)")
        self.root.geometry("800x550")
        self.root.configure(bg="#0d1117")

        self.project_root = Path(__file__).parent.parent
        self.create_ui()
        self.show_info()

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#161b22", height=60)
        header.pack(fill="x")
        tk.Label(header, text="Lin(python)", font=("Segoe UI", 20, "bold"),
                 fg="#58a6ff", bg="#161b22").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="Hybrid Python Environment", font=("Segoe UI", 10),
                 fg="#8b949e", bg="#161b22").pack(side="left", pady=10)

        # Main area
        main = tk.Frame(self.root, bg="#0d1117")
        main.pack(fill="both", expand=True, padx=10, pady=10)

        # Buttons
        btn_frame = tk.Frame(main, bg="#0d1117")
        btn_frame.pack(fill="x", pady=5)

        buttons = [
            ("Launch python.lin32 REPL", self.launch_repl),
            ("Run Python Script...", self.run_script),
            ("Open Code Editor", self.open_editor),
            ("System Python Info", self.show_info),
            ("Install Packages (pip)", self.pip_install),
        ]
        for text, cmd in buttons:
            tk.Button(btn_frame, text=text, command=cmd, bg="#21262d", fg="#c9d1d9",
                      relief="flat", font=("Segoe UI", 10), padx=12, pady=6).pack(side="left", padx=4)

        # Output
        self.output = scrolledtext.ScrolledText(main, bg="#0d1117", fg="#c9d1d9",
                                                 font=("Consolas", 10), relief="flat")
        self.output.pack(fill="both", expand=True, pady=5)

        # Status
        self.status = tk.Label(self.root, text="Ready", bg="#161b22", fg="#8b949e", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def set_status(self, msg):
        self.status.config(text=msg)

    def show_info(self):
        self.output.delete("1.0", "end")
        info = f"""=== Lin(python) ===
Python Version : {sys.version}
Platform       : {platform.system()} {platform.release()}
Architecture   : {platform.machine()}
Executable     : {sys.executable}
Project Root   : {self.project_root}

Available tools:
  - python.lin32  → Interactive REPL
  - Code Editor   → lin64x_editor.py
  - Linux4_(Cmd)  → Command prompt

This is the main Python app for the Lin64x hybrid suite.
"""
        self.output.insert("1.0", info)
        self.set_status("System info displayed")

    def launch_repl(self):
        repl = self.project_root / "python" / "python_lin32.py"
        if repl.exists():
            subprocess.Popen([sys.executable, str(repl)])
            self.set_status("Launched python.lin32 REPL")
        else:
            messagebox.showwarning("Not found", "python.lin32 not found")

    def run_script(self):
        path = filedialog.askopenfilename(filetypes=[("Python files", "*.py"), ("All files", "*.*")])
        if not path:
            return
        self.output.delete("1.0", "end")
        self.output.insert("end", f"Running: {path}\n\n")
        try:
            result = subprocess.run([sys.executable, path], capture_output=True, text=True, timeout=60)
            self.output.insert("end", result.stdout)
            if result.stderr:
                self.output.insert("end", "\n--- stderr ---\n" + result.stderr)
            self.set_status(f"Finished (exit {result.returncode})")
        except Exception as e:
            self.output.insert("end", f"Error: {e}")
            self.set_status("Error running script")

    def open_editor(self):
        editor = self.project_root / "editor" / "lin64x_editor.py"
        if editor.exists():
            subprocess.Popen([sys.executable, str(editor)])
            self.set_status("Opened Code Editor")
        else:
            messagebox.showwarning("Not found", "Code Editor not found")

    def pip_install(self):
        pkg = tk.simpledialog.askstring("pip install", "Package name:")
        if not pkg:
            return
        self.output.delete("1.0", "end")
        self.output.insert("end", f"Installing {pkg}...\n")
        self.root.update()
        try:
            result = subprocess.run([sys.executable, "-m", "pip", "install", pkg],
                                    capture_output=True, text=True, timeout=120)
            self.output.insert("end", result.stdout + result.stderr)
            self.set_status("pip finished")
        except Exception as e:
            self.output.insert("end", f"Error: {e}")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 400
    y = (root.winfo_screenheight() // 2) - 275
    root.geometry(f"+{x}+{y}")
    app = LinPython(root)
    root.mainloop()

if __name__ == "__main__":
    main()
