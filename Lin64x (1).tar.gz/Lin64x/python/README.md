# python.lin32

Lin64x Python runner and interactive REPL.

## Features
- Interactive Python console (REPL)
- Execute expressions and statements
- Run .py files
- Dark editor-style UI
- Works on Linux and Windows

## Run
```bash
python python/python_lin32.py
```

Also available from the Desktop shell.
