# Lin(python)

Main Python application and launcher for Lin64x.

## Features
- System Python information
- Launch python.lin32 REPL
- Run Python scripts
- Open the Code Editor
- Quick pip install

## Run
```bash
python python/lin_python.py
```
