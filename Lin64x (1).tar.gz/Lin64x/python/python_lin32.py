#!/usr/bin/env python3
"""
python.lin32 - Lin64x Python Runner / REPL
Hybrid Python console for Linux and Windows.
"""

import tkinter as tk
from tkinter import scrolledtext, font as tkfont, messagebox
import sys
import io
import traceback
import platform
from contextlib import redirect_stdout, redirect_stderr

class PythonLin32:
    def __init__(self, root):
        self.root = root
        self.root.title("python.lin32")
        self.root.geometry("900x600")
        self.root.configure(bg="#1e1e1e")

        self.mono = tkfont.Font(family="Consolas", size=11)
        self.namespace = {"__name__": "__main__"}

        self.create_ui()
        self.write_banner()

    def create_ui(self):
        # Output
        self.output = scrolledtext.ScrolledText(
            self.root, bg="#1e1e1e", fg="#d4d4d4", insertbackground="#ffffff",
            font=self.mono, relief="flat"
        )
        self.output.pack(fill="both", expand=True, padx=5, pady=5)
        self.output.tag_config("prompt", foreground="#569cd6")
        self.output.tag_config("error", foreground="#f44747")
        self.output.tag_config("result", foreground="#4ec9b0")
        self.output.tag_config("info", foreground="#9cdcfe")

        # Input
        input_frame = tk.Frame(self.root, bg="#1e1e1e")
        input_frame.pack(fill="x", padx=5, pady=(0, 5))

        tk.Label(input_frame, text=">>>", fg="#569cd6", bg="#1e1e1e", font=self.mono).pack(side="left")

        self.entry = tk.Entry(input_frame, bg="#252526", fg="#ffffff", insertbackground="#ffffff",
                              font=self.mono, relief="flat")
        self.entry.pack(side="left", fill="x", expand=True, padx=5)
        self.entry.bind("<Return>", self.on_enter)
        self.entry.focus()

        # Toolbar
        toolbar = tk.Frame(self.root, bg="#252526")
        toolbar.pack(fill="x", side="bottom")
        tk.Button(toolbar, text="Clear", command=self.clear, bg="#333", fg="white", relief="flat").pack(side="left", padx=4, pady=4)
        tk.Button(toolbar, text="Run File...", command=self.run_file, bg="#333", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Label(toolbar, text=f"python.lin32 | {platform.system()} | Python {sys.version.split()[0]}",
                 bg="#252526", fg="#888", font=("Segoe UI", 8)).pack(side="right", padx=8)

    def write_banner(self):
        banner = f"""python.lin32 - Lin64x Python Console
Python {sys.version}
Type Python code and press Enter. Use 'exit()' or close the window to quit.
"""
        self.output.insert("end", banner, "info")
        self.output.see("end")

    def clear(self):
        self.output.delete("1.0", "end")
        self.write_banner()

    def on_enter(self, event=None):
        code = self.entry.get().strip()
        self.entry.delete(0, "end")
        if not code:
            return

        self.output.insert("end", f">>> {code}\n", "prompt")

        if code in ("exit()", "quit()", "exit", "quit"):
            self.root.destroy()
            return

        self.execute(code)

    def execute(self, code):
        stdout = io.StringIO()
        stderr = io.StringIO()
        try:
            with redirect_stdout(stdout), redirect_stderr(stderr):
                # Try as expression first
                try:
                    result = eval(code, self.namespace)
                    if result is not None:
                        print(repr(result))
                except SyntaxError:
                    exec(code, self.namespace)
            out = stdout.getvalue()
            err = stderr.getvalue()
            if out:
                self.output.insert("end", out, "result")
            if err:
                self.output.insert("end", err, "error")
        except Exception:
            tb = traceback.format_exc()
            self.output.insert("end", tb, "error")
        self.output.see("end")

    def run_file(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(filetypes=[("Python files", "*.py"), ("All files", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                code = f.read()
            self.output.insert("end", f"\n--- Running {path} ---\n", "info")
            self.execute(code)
        except Exception as e:
            self.output.insert("end", f"Error loading file: {e}\n", "error")
        self.output.see("end")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 300
    root.geometry(f"+{x}+{y}")
    app = PythonLin32(root)
    root.mainloop()

if __name__ == "__main__":
    main()
