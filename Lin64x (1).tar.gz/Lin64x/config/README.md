# configlin

Lin64x configuration app.

## Features
- Theme, language, startup app
- Toggle Lin64xwin64P visibility
- Notes field
- Save / Reset / Show config file location
- Settings stored in `~/.lin64x_config.json`

## Run
```bash
python config/configlin.py
```
