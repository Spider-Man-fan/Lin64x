#!/usr/bin/env python3
"""
configlin - Lin64x Configuration
View and edit basic Lin64x settings.
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import json
from pathlib import Path
import platform

class ConfigLin:
    def __init__(self, root):
        self.root = root
        self.root.title("configlin")
        self.root.geometry("700x560")
        self.root.configure(bg="#1e1e1e")

        self.config_file = Path.home() / ".lin64x_config.json"
        self.config = self.load_config()

        self.create_ui()
        self.load_values()

    def load_config(self):
        default = {
            "theme": "dark",
            "language": "en",
            "auto_update_check": False,
            "show_hidden_processor": True,
            "default_browser": "system",
            "startup_app": "desktop",
            "notes": ""
        }
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    default.update(data)
            except Exception:
                pass
        return default

    def save_config(self):
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=2)
            return True
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return False

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#252526", height=48)
        header.pack(fill="x")
        tk.Label(header, text="configlin", font=("Segoe UI", 16, "bold"),
                 fg="#ffffff", bg="#252526").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="Lin64x Configuration", font=("Segoe UI", 10),
                 fg="#888", bg="#252526").pack(side="left")

        # Form
        form = tk.Frame(self.root, bg="#1e1e1e")
        form.pack(fill="both", expand=True, padx=20, pady=15)

        # Theme
        tk.Label(form, text="Theme", bg="#1e1e1e", fg="#cccccc").grid(row=0, column=0, sticky="w", pady=6)
        self.theme_var = tk.StringVar()
        ttk.Combobox(form, textvariable=self.theme_var, values=["dark", "light", "system"],
                     state="readonly", width=20).grid(row=0, column=1, sticky="w", padx=10)

        # Language
        tk.Label(form, text="Language", bg="#1e1e1e", fg="#cccccc").grid(row=1, column=0, sticky="w", pady=6)
        self.lang_var = tk.StringVar()
        ttk.Combobox(form, textvariable=self.lang_var, values=["en", "es", "fr", "de"],
                     state="readonly", width=20).grid(row=1, column=1, sticky="w", padx=10)

        # Startup app
        tk.Label(form, text="Startup App", bg="#1e1e1e", fg="#cccccc").grid(row=2, column=0, sticky="w", pady=6)
        self.startup_var = tk.StringVar()
        ttk.Combobox(form, textvariable=self.startup_var,
                     values=["desktop", "settings", "web", "software_maker", "none"],
                     state="readonly", width=20).grid(row=2, column=1, sticky="w", padx=10)

        # Checkboxes
        self.update_var = tk.BooleanVar()
        ttk.Checkbutton(form, text="Check for updates on start", variable=self.update_var).grid(
            row=3, column=0, columnspan=2, sticky="w", pady=6)

        self.processor_var = tk.BooleanVar()
        ttk.Checkbutton(form, text="Show Lin64xwin64P in Settings", variable=self.processor_var).grid(
            row=4, column=0, columnspan=2, sticky="w", pady=6)

        # Notes
        tk.Label(form, text="Notes", bg="#1e1e1e", fg="#cccccc").grid(row=5, column=0, sticky="nw", pady=6)
        self.notes = scrolledtext.ScrolledText(form, height=6, width=40, bg="#252526", fg="#d4d4d4",
                                                font=("Consolas", 10), relief="flat")
        self.notes.grid(row=5, column=1, sticky="w", padx=10, pady=6)

        # Buttons
        btn_frame = tk.Frame(form, bg="#1e1e1e")
        btn_frame.grid(row=6, column=0, columnspan=2, pady=15)
        tk.Button(btn_frame, text="Save", command=self.save, bg="#0078d4", fg="white",
                  relief="flat", padx=16).pack(side="left", padx=4)
        tk.Button(btn_frame, text="Reset to Defaults", command=self.reset, bg="#3c3c3c", fg="white",
                  relief="flat", padx=12).pack(side="left", padx=4)
        tk.Button(btn_frame, text="Show Config File", command=self.show_file, bg="#3c3c3c", fg="white",
                  relief="flat", padx=12).pack(side="left", padx=4)

        # Status
        self.status = tk.Label(self.root, text=f"Config: {self.config_file}", bg="#252526",
                               fg="#888", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def load_values(self):
        self.theme_var.set(self.config.get("theme", "dark"))
        self.lang_var.set(self.config.get("language", "en"))
        self.startup_var.set(self.config.get("startup_app", "desktop"))
        self.update_var.set(self.config.get("auto_update_check", False))
        self.processor_var.set(self.config.get("show_hidden_processor", True))
        self.notes.delete("1.0", "end")
        self.notes.insert("1.0", self.config.get("notes", ""))

    def save(self):
        self.config["theme"] = self.theme_var.get()
        self.config["language"] = self.lang_var.get()
        self.config["startup_app"] = self.startup_var.get()
        self.config["auto_update_check"] = self.update_var.get()
        self.config["show_hidden_processor"] = self.processor_var.get()
        self.config["notes"] = self.notes.get("1.0", "end-1c")
        if self.save_config():
            self.status.config(text="Saved successfully")
            messagebox.showinfo("configlin", "Configuration saved.")

    def reset(self):
        if messagebox.askyesno("Reset", "Reset all settings to defaults?"):
            self.config_file.unlink(missing_ok=True)
            self.config = self.load_config()
            self.load_values()
            self.status.config(text="Reset to defaults")

    def show_file(self):
        messagebox.showinfo("Config File", f"Location:\n{self.config_file}")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 350
    y = (root.winfo_screenheight() // 2) - 280
    root.geometry(f"+{x}+{y}")
    app = ConfigLin(root)
    root.mainloop()

if __name__ == "__main__":
    main()
