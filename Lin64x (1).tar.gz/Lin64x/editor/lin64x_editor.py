#!/usr/bin/env python3
"""
Lin64x Linux Code Editor App
Lightweight cross-platform code editor focused on Linux development.
Supports open/save, basic syntax highlighting for Python, line numbers.
"""

import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import os
import re

class Lin64xEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Code Editor")
        self.root.geometry("1000x700")
        self.root.configure(bg="#1e1e1e")
        
        self.current_file = None
        self.create_menu()
        self.create_editor()
        self.create_status()
        
        # Basic Python keywords for highlighting
        self.keywords = r'\b(def|class|import|from|if|else|elif|for|while|return|try|except|with|as|True|False|None|print)\b'

    def create_menu(self):
        menubar = tk.Menu(self.root, bg="#2d2d2d", fg="white")
        file_menu = tk.Menu(menubar, tearoff=0, bg="#2d2d2d", fg="white")
        file_menu.add_command(label="New", command=self.new_file, accelerator="Ctrl+N")
        file_menu.add_command(label="Open", command=self.open_file, accelerator="Ctrl+O")
        file_menu.add_command(label="Save", command=self.save_file, accelerator="Ctrl+S")
        file_menu.add_command(label="Save As", command=self.save_as)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)
        
        edit_menu = tk.Menu(menubar, tearoff=0, bg="#2d2d2d", fg="white")
        edit_menu.add_command(label="Highlight Python", command=self.highlight_python)
        menubar.add_cascade(label="Edit", menu=edit_menu)
        
        self.root.config(menu=menubar)
        
        # Key bindings
        self.root.bind("<Control-n>", lambda e: self.new_file())
        self.root.bind("<Control-o>", lambda e: self.open_file())
        self.root.bind("<Control-s>", lambda e: self.save_file())

    def create_editor(self):
        # Line numbers frame
        self.line_frame = tk.Frame(self.root, width=50, bg="#252526")
        self.line_frame.pack(side="left", fill="y")
        self.line_numbers = tk.Text(self.line_frame, width=4, padx=5, takefocus=0,
                                    border=0, background="#252526", foreground="#858585",
                                    state="disabled", font=("Consolas", 11))
        self.line_numbers.pack(fill="both", expand=True)
        
        # Main text area
        self.text = scrolledtext.ScrolledText(self.root, wrap="none", undo=True,
                                              bg="#1e1e1e", fg="#d4d4d4", insertbackground="white",
                                              font=("Consolas", 11), relief="flat")
        self.text.pack(side="right", fill="both", expand=True)
        self.text.bind("<KeyRelease>", self.on_key_release)
        self.text.bind("<Button-1>", self.update_line_numbers)

    def create_status(self):
        self.status = tk.Label(self.root, text="Ready | Lin64x Editor", bg="#007acc", fg="white",
                               anchor="w", font=("Segoe UI", 9))
        self.status.pack(side="bottom", fill="x")

    def update_line_numbers(self, event=None):
        lines = self.text.get("1.0", "end-1c").count("\n") + 1
        self.line_numbers.config(state="normal")
        self.line_numbers.delete("1.0", "end")
        self.line_numbers.insert("1.0", "\n".join(str(i) for i in range(1, lines + 1)))
        self.line_numbers.config(state="disabled")

    def on_key_release(self, event=None):
        self.update_line_numbers()
        self.highlight_python()

    def highlight_python(self):
        self.text.tag_remove("keyword", "1.0", "end")
        content = self.text.get("1.0", "end-1c")
        for match in re.finditer(self.keywords, content):
            start = f"1.0 + {match.start()} chars"
            end = f"1.0 + {match.end()} chars"
            self.text.tag_add("keyword", start, end)
        self.text.tag_config("keyword", foreground="#569cd6")

    def new_file(self):
        self.text.delete("1.0", "end")
        self.current_file = None
        self.root.title("Lin64x Code Editor - Untitled")
        self.status.config(text="New file")

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[("Python files", "*.py"), ("All files", "*.*")])
        if path:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                self.text.delete("1.0", "end")
                self.text.insert("1.0", content)
                self.current_file = path
                self.root.title(f"Lin64x Code Editor - {os.path.basename(path)}")
                self.status.config(text=f"Opened: {path}")
                self.update_line_numbers()
                self.highlight_python()
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def save_file(self):
        if self.current_file:
            self._write_file(self.current_file)
        else:
            self.save_as()

    def save_as(self):
        path = filedialog.asksaveasfilename(defaultextension=".py",
                                           filetypes=[("Python files", "*.py"), ("All files", "*.*")])
        if path:
            self.current_file = path
            self._write_file(path)

    def _write_file(self, path):
        try:
            content = self.text.get("1.0", "end-1c")
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            self.root.title(f"Lin64x Code Editor - {os.path.basename(path)}")
            self.status.config(text=f"Saved: {path}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

def main():
    root = tk.Tk()
    editor = Lin64xEditor(root)
    root.mainloop()

if __name__ == "__main__":
    main()
