; Lin64x Bootloader
; First-stage bootloader for BIOS systems
; Assemble: nasm -f bin bootloader.asm -o bootloader.bin

[org 0x7c00]
[bits 16]

start:
    ; Setup segments and stack
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    sti

    ; Save boot drive
    mov [boot_drive], dl

    ; Clear screen
    mov ax, 0x0003
    int 0x10

    ; Print banner
    mov si, banner
    call print

    ; Load kernel (sectors 2-17) to 0x1000
    mov si, loading
    call print

    mov ah, 0x02        ; BIOS read
    mov al, 16          ; 16 sectors
    mov ch, 0           ; cylinder 0
    mov cl, 2           ; start at sector 2
    mov dh, 0           ; head 0
    mov dl, [boot_drive]
    mov bx, 0x1000      ; destination
    int 0x13
    jc load_fail

    ; Success
    mov si, ok_msg
    call print

    ; Jump to loaded kernel
    jmp 0x0000:0x1000

load_fail:
    mov si, fail_msg
    call print
    jmp $

; Print null-terminated string in SI
print:
    pusha
.loop:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0e
    mov bh, 0
    int 0x10
    jmp .loop
.done:
    popa
    ret

banner   db "Lin64x Bootloader", 13, 10, 0
loading  db "Loading kernel...", 13, 10, 0
ok_msg   db "OK", 13, 10, 0
fail_msg db "Load failed", 13, 10, 0
boot_drive db 0

; Boot signature
times 510-($-$$) db 0
dw 0xaa55
