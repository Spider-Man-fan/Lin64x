# Lin64x Bootloader

First-stage bootloader for BIOS systems.

## Files
- `bootloader.asm` — bootloader source
- `grub.cfg` — GRUB menu configuration
- `grub.cfg.example` — alternate example

## Build
```bash
nasm -f bin bootloader/bootloader.asm -o bootloader.bin
```

## What it does
- Sets up segments and stack
- Clears the screen
- Loads 16 sectors from disk to `0x1000`
- Jumps to the loaded code
- Includes the required `0xAA55` boot signature

## Install to a disk image (VM only)
```bash
# Create a small disk image
dd if=/dev/zero of=disk.img bs=512 count=2880

# Write bootloader to first sector
dd if=bootloader.bin of=disk.img conv=notrunc

# Write kernel starting at sector 2
dd if=kernel.bin of=disk.img bs=512 seek=1 conv=notrunc
```

## GRUB
Use `grub.cfg` as a base for dual-boot setups, then run `update-grub`.

## Warning
Writing a bootloader to a real disk can make the system unbootable.  
Use a virtual machine or disk image for testing.
