#!/usr/bin/env python3
"""
Lin64x VMware App
Helper for managing and launching VMware virtual machines on Linux and Windows.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import platform
import subprocess
import os
import sys
import shutil
import json
from pathlib import Path

MODE_FILE = Path.home() / ".lin64x_vmware_mode.json"

class VMwareApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x VMware")
        self.root.geometry("900x620")
        self.root.configure(bg="#1e1e1e")

        self.is_linux = platform.system() == "Linux"
        self.is_windows = platform.system() == "Windows"
        self.project_root = Path(__file__).parent.parent
        self.vmware_cmd = self.detect_vmware()
        self.mode = self.load_mode()

        self.create_ui()
        self.show_status()

    def load_mode(self):
        if MODE_FILE.exists():
            try:
                with open(MODE_FILE) as f:
                    return json.load(f).get("mode", "normal")
            except Exception:
                pass
        return "normal"

    def save_mode(self, mode):
        try:
            with open(MODE_FILE, "w") as f:
                json.dump({"mode": mode}, f)
            self.mode = mode
            return True
        except Exception:
            return False

    def detect_vmware(self):
        candidates = []
        if self.is_windows:
            candidates = [
                r"C:\Program Files (x86)\VMware\VMware Workstation\vmware.exe",
                r"C:\Program Files\VMware\VMware Workstation\vmware.exe",
                "vmware.exe",
                "vmplayer.exe",
            ]
        else:
            candidates = ["vmware", "vmplayer", "vmware-modconfig"]
        for cmd in candidates:
            if shutil.which(cmd) or (os.path.exists(cmd) if os.path.isabs(cmd) else False):
                return cmd
        return None

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#252526", height=55)
        header.pack(fill="x")
        tk.Label(header, text="Lin64x VMware", font=("Segoe UI", 16, "bold"),
                 fg="#00a4ef", bg="#252526").pack(side="left", padx=15, pady=12)
        tk.Label(header, text="Virtual Machine Helper", font=("Segoe UI", 10),
                 fg="#888", bg="#252526").pack(side="left")

        # Toolbar
        toolbar = tk.Frame(self.root, bg="#1e1e1e")
        toolbar.pack(fill="x", padx=10, pady=6)
        tk.Button(toolbar, text="Launch VMware", command=self.launch_vmware,
                  bg="#0078d4", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Open .vmx", command=self.open_vmx,
                  bg="#107c10", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Refresh Status", command=self.show_status,
                  bg="#3c3c3c", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Create Template", command=self.create_template,
                  bg="#5c2d91", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="VMware Mode", command=self.configure_mode,
                  bg="#ff8c00", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Leave Mode", command=self.leave_mode,
                  bg="#c42b1c", fg="white", relief="flat").pack(side="left", padx=4)

        # Output
        self.output = scrolledtext.ScrolledText(self.root, bg="#1e1e1e", fg="#d4d4d4",
                                                 font=("Consolas", 10), relief="flat")
        self.output.pack(fill="both", expand=True, padx=10, pady=5)
        self.output.tag_config("info", foreground="#58a6ff")
        self.output.tag_config("success", foreground="#4ec9b0")
        self.output.tag_config("error", foreground="#f44747")
        self.output.tag_config("warning", foreground="#ffcc00")

        # Status
        self.status = tk.Label(self.root, text="Ready", bg="#0078d4", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def show_status(self):
        self.output.delete("1.0", "end")
        lines = ["=== Lin64x VMware Status ===\n"]
        lines.append(f"Platform: {platform.system()} {platform.release()}")
        if self.vmware_cmd:
            lines.append(f"VMware detected: {self.vmware_cmd}")
            lines.append("Status: Ready to launch")
        else:
            lines.append("VMware not detected on this system.")
            lines.append("")
            if self.is_windows:
                lines.append("Install VMware Workstation or Player from:")
                lines.append("  https://www.vmware.com/products/workstation-player.html")
            else:
                lines.append("On Linux install VMware Workstation/Player or use:")
                lines.append("  - VirtualBox (free alternative)")
                lines.append("  - QEMU/KVM")
                lines.append("  - GNOME Boxes")
        lines.append("\n--- VMware Mode ---")
        lines.append(f"Current mode: {self.mode}")
        lines.append("• VMware Mode — change mode (normal / player / workstation)")
        lines.append("• Leave Mode — return to normal mode")
        self.output.insert("1.0", "\n".join(lines))
        self.status.config(text=f"Mode: {self.mode}" + (" | VMware ready" if self.vmware_cmd else " | VMware not found"))

    def configure_mode(self):
        """Change VMware mode."""
        win = tk.Toplevel(self.root)
        win.title("VMware Mode")
        win.geometry("360x220")
        win.configure(bg="#1e1e1e")
        win.transient(self.root)
        tk.Label(win, text="Select VMware Mode", font=("Segoe UI", 12, "bold"),
                 bg="#1e1e1e", fg="white").pack(pady=10)
        mode_var = tk.StringVar(value=self.mode)
        for m, label in [("normal", "Normal"), ("player", "Player"), ("workstation", "Workstation")]:
            tk.Radiobutton(win, text=label, variable=mode_var, value=m,
                           bg="#1e1e1e", fg="white", selectcolor="#3c3c3c").pack(anchor="w", padx=20)
        def apply():
            new_mode = mode_var.get()
            if self.save_mode(new_mode):
                self.output.insert("end", f"\nVMware mode changed to: {new_mode}\n", "success")
                self.status.config(text=f"Mode: {new_mode}")
                messagebox.showinfo("Mode", f"VMware mode set to: {new_mode}")
            else:
                messagebox.showerror("Error", "Could not save mode.")
            win.destroy()
        tk.Button(win, text="Apply", command=apply, bg="#0078d4", fg="white",
                  relief="flat").pack(pady=12)

    def leave_mode(self):
        """Leave special VMware mode and return to normal."""
        if self.mode == "normal":
            messagebox.showinfo("Mode", "Already in normal mode.")
            return
        if self.save_mode("normal"):
            self.output.insert("end", "\nLeft VMware mode — returned to normal.\n", "success")
            self.status.config(text="Mode: normal")
            messagebox.showinfo("Mode", "Returned to normal mode.")
        else:
            messagebox.showerror("Error", "Could not change mode.")

    def launch_vmware(self):
        if not self.vmware_cmd:
            messagebox.showwarning("Not found", "VMware is not installed or not in PATH.")
            return
        try:
            subprocess.Popen([self.vmware_cmd])
            self.output.insert("end", "\nLaunched VMware.\n", "success")
            self.status.config(text="VMware launched")
        except Exception as e:
            self.output.insert("end", f"\nError: {e}\n", "error")

    def open_vmx(self):
        path = filedialog.askopenfilename(
            title="Select VMware .vmx file",
            filetypes=[("VMware VM", "*.vmx"), ("All files", "*.*")]
        )
        if not path:
            return
        if not self.vmware_cmd:
            messagebox.showwarning("Not found", "VMware is not installed.")
            return
        try:
            subprocess.Popen([self.vmware_cmd, path])
            self.output.insert("end", f"\nOpened: {path}\n", "success")
        except Exception as e:
            self.output.insert("end", f"\nError: {e}\n", "error")

    def create_template(self):
        name = tk.simpledialog.askstring("VM Name", "Virtual machine name:", initialvalue="Lin64x-VM")
        if not name:
            return
        path = filedialog.asksaveasfilename(
            title="Save .vmx template",
            defaultextension=".vmx",
            initialfile=f"{name}.vmx",
            filetypes=[("VMware VM", "*.vmx")]
        )
        if not path:
            return
        template = f'''.encoding = "UTF-8"
config.version = "8"
virtualHW.version = "19"
displayName = "{name}"
guestOS = "otherlinux-64"
memsize = "2048"
numvcpus = "2"
scsi0.present = "TRUE"
scsi0.virtualDev = "lsilogic"
sata0.present = "TRUE"
ethernet0.present = "TRUE"
ethernet0.connectionType = "nat"
usb.present = "TRUE"
ehci.present = "TRUE"
sound.present = "TRUE"
'''
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(template)
            self.output.insert("end", f"\nCreated template: {path}\n", "success")
            messagebox.showinfo("Created", f"VMX template saved to:\n{path}")
        except Exception as e:
            self.output.insert("end", f"\nError: {e}\n", "error")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 310
    root.geometry(f"+{x}+{y}")
    app = VMwareApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
