# Lin64x VMware App

Helper for managing and launching VMware virtual machines.

## Features
- Detect VMware Workstation / Player
- Launch VMware
- Open existing .vmx files
- Create basic .vmx templates
- Works on Linux and Windows

## Run
```bash
python vmware/lin64x_vmware.py
```

Requires VMware Workstation or Player to be installed for full functionality.
