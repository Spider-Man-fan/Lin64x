#!/usr/bin/env python3
"""
Win32x64(notepad) - Lin64x Notepad
Simple hybrid notepad for Linux and Windows.
"""

import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox, font as tkfont
import os

class Win32x64Notepad:
    def __init__(self, root):
        self.root = root
        self.root.title("Win32x64(notepad)")
        self.root.geometry("800x600")
        self.root.configure(bg="#ffffff")

        self.current_file = None
        self.mono = tkfont.Font(family="Consolas", size=11)

        self.create_menu()
        self.create_editor()
        self.create_status()

    def create_menu(self):
        menubar = tk.Menu(self.root)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New", command=self.new_file, accelerator="Ctrl+N")
        file_menu.add_command(label="Open...", command=self.open_file, accelerator="Ctrl+O")
        file_menu.add_command(label="Save", command=self.save_file, accelerator="Ctrl+S")
        file_menu.add_command(label="Save As...", command=self.save_as)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        edit_menu = tk.Menu(menubar, tearoff=0)
        edit_menu.add_command(label="Cut", command=lambda: self.text.event_generate("<<Cut>>"))
        edit_menu.add_command(label="Copy", command=lambda: self.text.event_generate("<<Copy>>"))
        edit_menu.add_command(label="Paste", command=lambda: self.text.event_generate("<<Paste>>"))
        edit_menu.add_separator()
        edit_menu.add_command(label="Select All", command=lambda: self.text.tag_add("sel", "1.0", "end"))
        menubar.add_cascade(label="Edit", menu=edit_menu)

        self.root.config(menu=menubar)

        self.root.bind("<Control-n>", lambda e: self.new_file())
        self.root.bind("<Control-o>", lambda e: self.open_file())
        self.root.bind("<Control-s>", lambda e: self.save_file())

    def create_editor(self):
        self.text = scrolledtext.ScrolledText(
            self.root, wrap="word", undo=True,
            bg="#ffffff", fg="#000000", insertbackground="#000000",
            font=self.mono, relief="flat"
        )
        self.text.pack(fill="both", expand=True, padx=2, pady=2)
        self.text.bind("<KeyRelease>", self.update_status)

    def create_status(self):
        self.status = tk.Label(self.root, text="Ready | Win32x64(notepad)", 
                               bg="#f0f0f0", fg="#333333", anchor="w", font=("Segoe UI", 9))
        self.status.pack(side="bottom", fill="x")

    def update_status(self, event=None):
        content = self.text.get("1.0", "end-1c")
        lines = content.count("\n") + 1
        chars = len(content)
        name = os.path.basename(self.current_file) if self.current_file else "Untitled"
        self.status.config(text=f"{name} | Lines: {lines} | Characters: {chars}")

    def new_file(self):
        self.text.delete("1.0", "end")
        self.current_file = None
        self.root.title("Win32x64(notepad) - Untitled")
        self.update_status()

    def open_file(self):
        path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if path:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                self.text.delete("1.0", "end")
                self.text.insert("1.0", content)
                self.current_file = path
                self.root.title(f"Win32x64(notepad) - {os.path.basename(path)}")
                self.update_status()
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def save_file(self):
        if self.current_file:
            self._write(self.current_file)
        else:
            self.save_as()

    def save_as(self):
        path = filedialog.asksaveasfilename(defaultextension=".txt",
                                           filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if path:
            self.current_file = path
            self._write(path)

    def _write(self, path):
        try:
            content = self.text.get("1.0", "end-1c")
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            self.root.title(f"Win32x64(notepad) - {os.path.basename(path)}")
            self.update_status()
        except Exception as e:
            messagebox.showerror("Error", str(e))

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 400
    y = (root.winfo_screenheight() // 2) - 300
    root.geometry(f"+{x}+{y}")
    app = Win32x64Notepad(root)
    root.mainloop()

if __name__ == "__main__":
    main()
