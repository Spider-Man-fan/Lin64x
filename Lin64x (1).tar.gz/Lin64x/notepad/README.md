# Win32x64(notepad)

Simple hybrid notepad for Lin64x.

## Features
- New / Open / Save / Save As
- Cut / Copy / Paste
- Line and character count
- Works on Linux and Windows

## Run
```bash
python notepad/win32x64_notepad.py
```
