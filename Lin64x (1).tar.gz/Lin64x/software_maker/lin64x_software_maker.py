#!/usr/bin/env python3
"""
Lin64x Software Maker (Multi-language)
Supports Python, Python/Tkinter, C++, and Java.
Check correctness and run/test code.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox, filedialog, ttk, font as tkfont
import sys
import ast
import subprocess
import tempfile
import os
import shutil
from pathlib import Path

class SoftwareMaker:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Software Maker")
        self.root.geometry("1050x700")
        self.root.configure(bg="#1e1e1e")

        self.mono = tkfont.Font(family="Consolas", size=11)
        self.current_file = None
        self.language = tk.StringVar(value="Python")

        self.examples = {
            "Python": '''# Python example
def greet(name):
    return f"Hello, {name}!"

print(greet("Lin64x"))
print("Python code is working.")
''',
            "Python/Tkinter": '''# Python + Tkinter example
import tkinter as tk

root = tk.Tk()
root.title("Lin64x Tkinter Test")
root.geometry("300x150")

label = tk.Label(root, text="Hello from Tkinter!", font=("Arial", 14))
label.pack(pady=30)

btn = tk.Button(root, text="Close", command=root.destroy)
btn.pack()

root.mainloop()
''',
            "C++": '''// C++ example
#include <iostream>
using namespace std;

int main() {
    cout << "Hello from C++!" << endl;
    cout << "Lin64x Software Maker" << endl;
    return 0;
}
''',
            "Java": '''// Java example
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello from Java!");
        System.out.println("Lin64x Software Maker");
    }
}
'''
        }

        self.create_ui()
        self.load_example()

    def create_ui(self):
        # Toolbar
        toolbar = tk.Frame(self.root, bg="#252526", height=42)
        toolbar.pack(fill="x")
        toolbar.pack_propagate(False)

        tk.Label(toolbar, text="Language:", bg="#252526", fg="#cccccc").pack(side="left", padx=(8, 2))
        lang_combo = ttk.Combobox(toolbar, textvariable=self.language, state="readonly", width=16,
                                  values=["Python", "Python/Tkinter", "C++", "Java"])
        lang_combo.pack(side="left", padx=4)
        lang_combo.bind("<<ComboboxSelected>>", lambda e: self.on_language_change())

        buttons = [
            ("New", self.new_file),
            ("Open", self.open_file),
            ("Save", self.save_file),
            ("Check Code", self.check_code),
            ("Run / Test", self.run_code),
            ("Clear Output", self.clear_output),
        ]
        for text, cmd in buttons:
            tk.Button(toolbar, text=text, command=cmd, bg="#3c3c3c", fg="white",
                      relief="flat", padx=8).pack(side="left", padx=3, pady=6)

        # Main paned
        paned = tk.PanedWindow(self.root, orient="vertical", bg="#1e1e1e")
        paned.pack(fill="both", expand=True, padx=5, pady=5)

        # Code editor
        editor_frame = tk.Frame(paned, bg="#1e1e1e")
        self.editor_label = tk.Label(editor_frame, text="Code Editor — Python", bg="#1e1e1e",
                                      fg="#cccccc", font=("Segoe UI", 9))
        self.editor_label.pack(anchor="w")
        self.editor = scrolledtext.ScrolledText(editor_frame, bg="#1e1e1e", fg="#d4d4d4",
                                                 insertbackground="white", font=self.mono,
                                                 relief="flat", undo=True)
        self.editor.pack(fill="both", expand=True)
        paned.add(editor_frame, height=400)

        # Output
        output_frame = tk.Frame(paned, bg="#1e1e1e")
        tk.Label(output_frame, text="Check Results & Output", bg="#1e1e1e", fg="#cccccc",
                 font=("Segoe UI", 9)).pack(anchor="w")
        self.output = scrolledtext.ScrolledText(output_frame, bg="#252526", fg="#d4d4d4",
                                                 font=self.mono, relief="flat")
        self.output.pack(fill="both", expand=True)
        self.output.tag_config("success", foreground="#4ec9b0")
        self.output.tag_config("error", foreground="#f44747")
        self.output.tag_config("warning", foreground="#ffcc00")
        self.output.tag_config("info", foreground="#58a6ff")
        paned.add(output_frame)

        # Status
        self.status = tk.Label(self.root, text="Ready | Lin64x Software Maker",
                               bg="#0078d4", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def on_language_change(self):
        lang = self.language.get()
        self.editor_label.config(text=f"Code Editor — {lang}")
        self.load_example()
        self.status.config(text=f"Language set to {lang}")

    def load_example(self):
        lang = self.language.get()
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", self.examples.get(lang, ""))

    def new_file(self):
        self.editor.delete("1.0", "end")
        self.current_file = None
        self.status.config(text="New file")
        self.output.delete("1.0", "end")

    def open_file(self):
        exts = {
            "Python": [("Python", "*.py")],
            "Python/Tkinter": [("Python", "*.py")],
            "C++": [("C++", "*.cpp *.cc *.cxx"), ("C", "*.c")],
            "Java": [("Java", "*.java")],
        }
        path = filedialog.askopenfilename(filetypes=exts.get(self.language.get(), [("All", "*.*")]) + [("All files", "*.*")])
        if path:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                self.editor.delete("1.0", "end")
                self.editor.insert("1.0", content)
                self.current_file = path
                self.status.config(text=f"Opened: {os.path.basename(path)}")
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def save_file(self):
        exts = {
            "Python": ".py",
            "Python/Tkinter": ".py",
            "C++": ".cpp",
            "Java": ".java",
        }
        if not self.current_file:
            ext = exts.get(self.language.get(), ".txt")
            path = filedialog.asksaveasfilename(defaultextension=ext)
            if not path:
                return
            self.current_file = path
        try:
            content = self.editor.get("1.0", "end-1c")
            with open(self.current_file, "w", encoding="utf-8") as f:
                f.write(content)
            self.status.config(text=f"Saved: {os.path.basename(self.current_file)}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def check_code(self):
        code = self.editor.get("1.0", "end-1c")
        lang = self.language.get()
        self.output.delete("1.0", "end")
        self.output.insert("end", f"=== Code Check ({lang}) ===\n", "info")

        if not code.strip():
            self.output.insert("end", "WARNING: No code to check.\n", "warning")
            return

        if lang in ("Python", "Python/Tkinter"):
            self.check_python(code)
        elif lang == "C++":
            self.check_cpp(code)
        elif lang == "Java":
            self.check_java(code)

    def check_python(self, code):
        try:
            ast.parse(code)
            self.output.insert("end", "✓ SYNTAX CORRECT: No syntax errors found.\n", "success")
            if "tkinter" in code.lower() or "Tk()" in code:
                self.output.insert("end", "✓ Tkinter usage detected.\n", "success")
            self.status.config(text="Python check passed")
        except SyntaxError as e:
            self.output.insert("end", "✗ SYNTAX ERROR: Code is incorrect.\n", "error")
            self.output.insert("end", f"  Line {e.lineno}: {e.msg}\n", "error")
            if e.text:
                self.output.insert("end", f"  {e.text.strip()}\n", "error")
            self.status.config(text="Syntax error")

    def check_cpp(self, code):
        if not shutil.which("g++"):
            self.output.insert("end", "WARNING: g++ not found. Install a C++ compiler to fully check/run.\n", "warning")
            self.output.insert("end", "Basic check: looking for main() and includes...\n", "info")
            if "int main" in code:
                self.output.insert("end", "✓ main() function found.\n", "success")
            else:
                self.output.insert("end", "✗ No main() function detected.\n", "error")
            return
        # Try compile check
        self.output.insert("end", "Compiling with g++ (syntax check)...\n", "info")
        self.compile_and_report(code, "cpp")

    def check_java(self, code):
        if not shutil.which("javac"):
            self.output.insert("end", "WARNING: javac not found. Install JDK to fully check/run.\n", "warning")
            if "public static void main" in code:
                self.output.insert("end", "✓ main method found.\n", "success")
            else:
                self.output.insert("end", "✗ No main method detected.\n", "error")
            return
        self.output.insert("end", "Compiling with javac (syntax check)...\n", "info")
        self.compile_and_report(code, "java")

    def compile_and_report(self, code, lang):
        try:
            with tempfile.TemporaryDirectory() as tmp:
                if lang == "cpp":
                    src = os.path.join(tmp, "main.cpp")
                    with open(src, "w") as f:
                        f.write(code)
                    result = subprocess.run(["g++", "-fsyntax-only", src], capture_output=True, text=True, timeout=30)
                else:  # java
                    src = os.path.join(tmp, "Main.java")
                    with open(src, "w") as f:
                        f.write(code)
                    result = subprocess.run(["javac", src], capture_output=True, text=True, timeout=30)
                if result.returncode == 0:
                    self.output.insert("end", "✓ SYNTAX CORRECT: Compilation check passed.\n", "success")
                    self.status.config(text="Check passed")
                else:
                    self.output.insert("end", "✗ COMPILE ERROR: Code is incorrect.\n", "error")
                    self.output.insert("end", result.stderr or result.stdout, "error")
                    self.status.config(text="Compile error")
        except Exception as e:
            self.output.insert("end", f"Error during check: {e}\n", "error")

    def run_code(self):
        code = self.editor.get("1.0", "end-1c")
        lang = self.language.get()
        self.output.delete("1.0", "end")
        self.output.insert("end", f"=== Run / Test ({lang}) ===\n", "info")

        if lang in ("Python", "Python/Tkinter"):
            self.run_python(code)
        elif lang == "C++":
            self.run_cpp(code)
        elif lang == "Java":
            self.run_java(code)

    def run_python(self, code):
        try:
            ast.parse(code)
        except SyntaxError as e:
            self.output.insert("end", "✗ CANNOT RUN: Syntax error.\n", "error")
            self.output.insert("end", f"  Line {e.lineno}: {e.msg}\n", "error")
            return
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
                f.write(code)
                temp = f.name
            result = subprocess.run([sys.executable, temp], capture_output=True, text=True, timeout=20)
            os.unlink(temp)
            if result.returncode == 0:
                self.output.insert("end", "✓ RUN SUCCESSFUL\n\n", "success")
                self.output.insert("end", result.stdout or "(No output)\n")
            else:
                self.output.insert("end", "✗ RUN FAILED\n\n", "error")
                self.output.insert("end", result.stderr or result.stdout, "error")
        except subprocess.TimeoutExpired:
            self.output.insert("end", "✗ TIMEOUT\n", "error")
        except Exception as e:
            self.output.insert("end", f"Error: {e}\n", "error")

    def run_cpp(self, code):
        if not shutil.which("g++"):
            self.output.insert("end", "✗ g++ not found. Cannot compile/run C++.\n", "error")
            return
        try:
            with tempfile.TemporaryDirectory() as tmp:
                src = os.path.join(tmp, "main.cpp")
                exe = os.path.join(tmp, "main.exe" if os.name == "nt" else "main")
                with open(src, "w") as f:
                    f.write(code)
                comp = subprocess.run(["g++", src, "-o", exe], capture_output=True, text=True, timeout=30)
                if comp.returncode != 0:
                    self.output.insert("end", "✗ COMPILE FAILED\n", "error")
                    self.output.insert("end", comp.stderr, "error")
                    return
                self.output.insert("end", "✓ Compiled successfully. Running...\n", "success")
                run = subprocess.run([exe], capture_output=True, text=True, timeout=15)
                self.output.insert("end", run.stdout or "(No output)\n")
                if run.stderr:
                    self.output.insert("end", run.stderr, "error")
        except Exception as e:
            self.output.insert("end", f"Error: {e}\n", "error")

    def run_java(self, code):
        if not shutil.which("javac") or not shutil.which("java"):
            self.output.insert("end", "✗ javac/java not found. Install JDK.\n", "error")
            return
        try:
            with tempfile.TemporaryDirectory() as tmp:
                src = os.path.join(tmp, "Main.java")
                with open(src, "w") as f:
                    f.write(code)
                comp = subprocess.run(["javac", src], capture_output=True, text=True, timeout=30, cwd=tmp)
                if comp.returncode != 0:
                    self.output.insert("end", "✗ COMPILE FAILED\n", "error")
                    self.output.insert("end", comp.stderr, "error")
                    return
                self.output.insert("end", "✓ Compiled successfully. Running...\n", "success")
                run = subprocess.run(["java", "Main"], capture_output=True, text=True, timeout=15, cwd=tmp)
                self.output.insert("end", run.stdout or "(No output)\n")
                if run.stderr:
                    self.output.insert("end", run.stderr, "error")
        except Exception as e:
            self.output.insert("end", f"Error: {e}\n", "error")

    def clear_output(self):
        self.output.delete("1.0", "end")
        self.status.config(text="Output cleared")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 525
    y = (root.winfo_screenheight() // 2) - 350
    root.geometry(f"+{x}+{y}")
    app = SoftwareMaker(root)
    root.mainloop()

if __name__ == "__main__":
    main()
