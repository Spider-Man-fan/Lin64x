# Lin64x Software Maker (Multi-language)

Write code, check if it is correct, and run/test it.

## Supported Languages
- **Python**
- **Python/Tkinter**
- **C++** (requires g++)
- **Java** (requires JDK / javac + java)

## Features
- Language selector
- Example code for each language
- **Check Code** — syntax validation (or compile check)
- **Run / Test** — compile (if needed) and execute
- Clear correct / wrong / warning messages
- Open / Save files

## Requirements
- Python: built-in
- C++: `g++` in PATH
- Java: `javac` and `java` in PATH

## Run
```bash
python software_maker/lin64x_software_maker.py
```
