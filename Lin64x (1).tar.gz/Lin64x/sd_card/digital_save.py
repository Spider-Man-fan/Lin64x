#!/usr/bin/env python3
"""
Lin64x SD Digital Save Card (Upgraded)
GUI-based virtual storage / save state manager with categories, search, and export.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, simpledialog, filedialog
import json
import hashlib
from pathlib import Path
from datetime import datetime

class DigitalSaveCard:
    def __init__(self, card_path="lin64x_sd_card.json"):
        self.card_path = Path(card_path)
        self.data = self.load()

    def load(self):
        if self.card_path.exists():
            with open(self.card_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {
            "saves": {},
            "metadata": {
                "created": datetime.now().isoformat(),
                "version": "2.0",
                "capacity": "Virtual SD"
            }
        }

    def save(self):
        with open(self.card_path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)

    def create_save(self, name, content, category="General"):
        save_id = hashlib.md5(f"{name}{datetime.now().isoformat()}".encode()).hexdigest()[:10]
        self.data["saves"][save_id] = {
            "name": name,
            "content": content,
            "category": category,
            "timestamp": datetime.now().isoformat(),
            "size": len(content.encode("utf-8")),
            "modified": datetime.now().isoformat()
        }
        self.save()
        return save_id

    def delete_save(self, save_id):
        if save_id in self.data["saves"]:
            del self.data["saves"][save_id]
            self.save()
            return True
        return False

    def list_saves(self, category=None):
        items = []
        for sid, info in self.data["saves"].items():
            if category is None or info.get("category") == category:
                items.append((sid, info))
        return sorted(items, key=lambda x: x[1]["timestamp"], reverse=True)

class SDCardApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x SD Digital Save Card")
        self.root.geometry("900x600")
        self.root.configure(bg="#1a1a1a")

        self.card = DigitalSaveCard()
        self.create_ui()
        self.refresh_list()

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#252526", height=50)
        header.pack(fill="x")
        tk.Label(header, text="SD Digital Save Card", font=("Segoe UI", 16, "bold"),
                 fg="#ffffff", bg="#252526").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="v2.0", font=("Segoe UI", 10), fg="#888", bg="#252526").pack(side="left")

        # Toolbar
        toolbar = tk.Frame(self.root, bg="#1a1a1a")
        toolbar.pack(fill="x", padx=10, pady=5)
        tk.Button(toolbar, text="New Save", command=self.new_save, bg="#0078d4", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Delete", command=self.delete_selected, bg="#c42b1c", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Export", command=self.export_save, bg="#107c10", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Refresh", command=self.refresh_list, bg="#3c3c3c", fg="white", relief="flat").pack(side="left", padx=4)

        # Main split
        paned = tk.PanedWindow(self.root, orient="horizontal", bg="#1a1a1a")
        paned.pack(fill="both", expand=True, padx=10, pady=5)

        # List
        list_frame = tk.Frame(paned, bg="#1a1a1a")
        self.tree = ttk.Treeview(list_frame, columns=("category", "size", "date"), show="tree headings")
        self.tree.heading("#0", text="Name")
        self.tree.heading("category", text="Category")
        self.tree.heading("size", text="Size")
        self.tree.heading("date", text="Date")
        self.tree.column("#0", width=200)
        self.tree.column("category", width=100)
        self.tree.column("size", width=80)
        self.tree.column("date", width=140)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        paned.add(list_frame)

        # Preview
        preview_frame = tk.Frame(paned, bg="#1a1a1a")
        tk.Label(preview_frame, text="Content Preview", fg="#ccc", bg="#1a1a1a").pack(anchor="w")
        self.preview = scrolledtext.ScrolledText(preview_frame, bg="#252526", fg="#d4d4d4",
                                                  font=("Consolas", 10), relief="flat")
        self.preview.pack(fill="both", expand=True)
        paned.add(preview_frame)

        # Status
        self.status = tk.Label(self.root, text="Ready", bg="#0078d4", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def refresh_list(self):
        self.tree.delete(*self.tree.get_children())
        for sid, info in self.card.list_saves():
            size = f"{info['size']:,} B"
            date = info["timestamp"][:19].replace("T", " ")
            self.tree.insert("", "end", text=info["name"], values=(info.get("category", "General"), size, date), tags=(sid,))
        count = len(self.card.data["saves"])
        self.status.config(text=f"{count} saves | {self.card.card_path}")

    def on_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        sid = self.tree.item(sel[0])["tags"][0]
        content = self.card.data["saves"].get(sid, {}).get("content", "")
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", content)

    def new_save(self):
        name = simpledialog.askstring("New Save", "Save name:")
        if not name:
            return
        content = simpledialog.askstring("Content", "Save content (text):") or ""
        category = simpledialog.askstring("Category", "Category:", initialvalue="General") or "General"
        self.card.create_save(name, content, category)
        self.refresh_list()

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        if messagebox.askyesno("Delete", "Delete selected save?"):
            sid = self.tree.item(sel[0])["tags"][0]
            self.card.delete_save(sid)
            self.refresh_list()
            self.preview.delete("1.0", "end")

    def export_save(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Export", "Select a save first")
            return
        sid = self.tree.item(sel[0])["tags"][0]
        info = self.card.data["saves"][sid]
        path = filedialog.asksaveasfilename(defaultextension=".txt", initialfile=info["name"])
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(info["content"])
            messagebox.showinfo("Exported", f"Saved to {path}")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 300
    root.geometry(f"+{x}+{y}")
    app = SDCardApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
