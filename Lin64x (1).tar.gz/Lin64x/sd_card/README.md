# SD Digital Save Card (Upgraded)

GUI-based virtual storage manager.

## New Features (v2.0)
- Graphical interface
- Categories
- Content preview
- Delete and export
- Better save IDs and timestamps

## Run
```bash
python sd_card/digital_save.py
```
