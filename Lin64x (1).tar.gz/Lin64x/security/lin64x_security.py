#!/usr/bin/env python3
"""
Lin64x Security App (Linux-style)
Cross-platform security dashboard with Linux-inspired features:
- Process monitor
- Basic firewall / port checks
- File integrity (hash) scanner
- Permission & hardening suggestions
- System info security overview
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import platform
import os
import sys
import subprocess
import hashlib
import socket
from pathlib import Path
from datetime import datetime

class Lin64xSecurity:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Security")
        self.root.geometry("900x650")
        self.root.configure(bg="#0d1117")

        self.is_linux = platform.system() == "Linux"
        self.is_windows = platform.system() == "Windows"

        self.create_ui()
        self.refresh_all()

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#161b22", height=50)
        header.pack(fill="x")
        tk.Label(header, text="Lin64x Security", font=("Segoe UI", 16, "bold"),
                 fg="#58a6ff", bg="#161b22").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="Linux-style Hybrid Security Monitor", font=("Segoe UI", 10),
                 fg="#8b949e", bg="#161b22").pack(side="left", pady=10)

        # Notebook tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        # Tabs
        self.tab_overview = tk.Frame(self.notebook, bg="#0d1117")
        self.tab_processes = tk.Frame(self.notebook, bg="#0d1117")
        self.tab_firewall = tk.Frame(self.notebook, bg="#0d1117")
        self.tab_scanner = tk.Frame(self.notebook, bg="#0d1117")
        self.tab_harden = tk.Frame(self.notebook, bg="#0d1117")

        self.notebook.add(self.tab_overview, text="Overview")
        self.notebook.add(self.tab_processes, text="Processes")
        self.notebook.add(self.tab_firewall, text="Firewall / Ports")
        self.notebook.add(self.tab_scanner, text="File Scanner")
        self.notebook.add(self.tab_harden, text="Hardening")

        self.build_overview()
        self.build_processes()
        self.build_firewall()
        self.build_scanner()
        self.build_harden()

        # Status bar
        self.status = tk.Label(self.root, text="Ready", bg="#161b22", fg="#8b949e",
                               anchor="w", font=("Segoe UI", 9))
        self.status.pack(side="bottom", fill="x")

    def build_overview(self):
        frame = self.tab_overview
        self.overview_text = scrolledtext.ScrolledText(frame, bg="#0d1117", fg="#c9d1d9",
                                                        font=("Consolas", 10), relief="flat")
        self.overview_text.pack(fill="both", expand=True, padx=10, pady=10)
        ttk.Button(frame, text="Refresh", command=self.refresh_overview).pack(pady=5)

    def build_processes(self):
        frame = self.tab_processes
        self.proc_text = scrolledtext.ScrolledText(frame, bg="#0d1117", fg="#c9d1d9",
                                                    font=("Consolas", 9), relief="flat")
        self.proc_text.pack(fill="both", expand=True, padx=10, pady=10)
        ttk.Button(frame, text="Refresh Processes", command=self.refresh_processes).pack(pady=5)

    def build_firewall(self):
        frame = self.tab_firewall
        self.fw_text = scrolledtext.ScrolledText(frame, bg="#0d1117", fg="#c9d1d9",
                                                  font=("Consolas", 10), relief="flat")
        self.fw_text.pack(fill="both", expand=True, padx=10, pady=10)
        ttk.Button(frame, text="Check Firewall / Ports", command=self.check_firewall).pack(pady=5)

    def build_scanner(self):
        frame = self.tab_scanner
        btn_frame = tk.Frame(frame, bg="#0d1117")
        btn_frame.pack(fill="x", padx=10, pady=5)
        ttk.Button(btn_frame, text="Scan File", command=self.scan_file).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Scan Directory", command=self.scan_directory).pack(side="left", padx=5)
        self.scan_text = scrolledtext.ScrolledText(frame, bg="#0d1117", fg="#c9d1d9",
                                                    font=("Consolas", 10), relief="flat")
        self.scan_text.pack(fill="both", expand=True, padx=10, pady=5)

    def build_harden(self):
        frame = self.tab_harden
        self.harden_text = scrolledtext.ScrolledText(frame, bg="#0d1117", fg="#c9d1d9",
                                                      font=("Consolas", 10), relief="flat")
        self.harden_text.pack(fill="both", expand=True, padx=10, pady=10)
        ttk.Button(frame, text="Run Hardening Checks", command=self.run_hardening).pack(pady=5)

    def set_status(self, msg):
        self.status.config(text=msg)
        self.root.update_idletasks()

    def refresh_all(self):
        self.refresh_overview()
        self.refresh_processes()
        self.check_firewall()
        self.run_hardening()

    def refresh_overview(self):
        self.overview_text.delete("1.0", "end")
        lines = []
        lines.append("=== Lin64x Security Overview ===")
        lines.append(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"OS: {platform.system()} {platform.release()}")
        lines.append(f"Architecture: {platform.machine()}")
        lines.append(f"Python: {sys.version.split()[0]}")
        lines.append("")
        if self.is_linux:
            lines.append("Mode: Native Linux (full security features available)")
        elif self.is_windows:
            lines.append("Mode: Windows (limited / hybrid features)")
        else:
            lines.append("Mode: Other")
        lines.append("")
        lines.append("Quick status:")
        lines.append("  - Process monitor: Available")
        lines.append("  - File integrity scanner: Available")
        lines.append("  - Hardening suggestions: Available")
        if self.is_linux:
            lines.append("  - Firewall tools (ufw/iptables): Checked on demand")
        self.overview_text.insert("1.0", "\n".join(lines))
        self.set_status("Overview refreshed")

    def refresh_processes(self):
        self.proc_text.delete("1.0", "end")
        self.set_status("Reading processes...")
        try:
            if self.is_linux:
                result = subprocess.check_output(["ps", "aux"], text=True, timeout=10)
                # Limit output
                lines = result.splitlines()[:80]
                self.proc_text.insert("1.0", "\n".join(lines))
            elif self.is_windows:
                result = subprocess.check_output(["tasklist"], text=True, timeout=10)
                lines = result.splitlines()[:60]
                self.proc_text.insert("1.0", "\n".join(lines))
            else:
                self.proc_text.insert("1.0", "Process listing not supported on this OS.")
        except Exception as e:
            self.proc_text.insert("1.0", f"Error reading processes: {e}")
        self.set_status("Processes updated")

    def check_firewall(self):
        self.fw_text.delete("1.0", "end")
        lines = ["=== Firewall & Open Ports ===\n"]
        if self.is_linux:
            # Try ufw
            try:
                ufw = subprocess.check_output(["ufw", "status"], text=True, stderr=subprocess.DEVNULL, timeout=5)
                lines.append("ufw status:\n" + ufw)
            except Exception:
                lines.append("ufw not available or not installed.\n")
            # Try iptables summary
            try:
                ipt = subprocess.check_output(["iptables", "-L", "-n"], text=True, stderr=subprocess.DEVNULL, timeout=5)
                lines.append("\niptables (first 40 lines):\n" + "\n".join(ipt.splitlines()[:40]))
            except Exception:
                lines.append("\niptables not available or permission denied.\n")
            # Common listening ports
            try:
                ss = subprocess.check_output(["ss", "-tuln"], text=True, timeout=5)
                lines.append("\nListening sockets (ss -tuln):\n" + "\n".join(ss.splitlines()[:30]))
            except Exception:
                pass
        else:
            lines.append("Firewall checks are Linux-focused.\n")
            lines.append("On Windows, use Windows Defender Firewall settings.\n")
            # Simple local port check
            lines.append("\nChecking common local ports...")
            for port in [22, 80, 443, 3389, 8080]:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.5)
                result = sock.connect_ex(("127.0.0.1", port))
                status = "OPEN" if result == 0 else "closed"
                lines.append(f"  Port {port}: {status}")
                sock.close()
        self.fw_text.insert("1.0", "\n".join(lines))
        self.set_status("Firewall check complete")

    def scan_file(self):
        path = filedialog.askopenfilename(title="Select file to scan")
        if not path:
            return
        self._scan_path(path)

    def scan_directory(self):
        path = filedialog.askdirectory(title="Select directory to scan")
        if not path:
            return
        self._scan_path(path, recursive=True)

    def _scan_path(self, path, recursive=False):
        self.scan_text.delete("1.0", "end")
        self.set_status(f"Scanning {path}...")
        results = []
        results.append(f"Scan started: {datetime.now()}")
        results.append(f"Target: {path}\n")

        def hash_file(fp):
            h = hashlib.sha256()
            try:
                with open(fp, "rb") as f:
                    for chunk in iter(lambda: f.read(8192), b""):
                        h.update(chunk)
                return h.hexdigest()
            except Exception:
                return "ERROR"

        count = 0
        if os.path.isfile(path):
            h = hash_file(path)
            results.append(f"{path}\n  SHA256: {h}\n")
            count = 1
        elif os.path.isdir(path):
            for root_dir, dirs, files in os.walk(path):
                for name in files:
                    fp = os.path.join(root_dir, name)
                    h = hash_file(fp)
                    results.append(f"{fp}\n  SHA256: {h}")
                    count += 1
                    if count >= 200:  # Safety limit
                        results.append("\n... truncated (200 file limit)")
                        break
                if count >= 200:
                    break
        results.append(f"\nScanned {count} file(s).")
        results.append("Note: This is an integrity/hash scanner, not a full antivirus.")
        self.scan_text.insert("1.0", "\n".join(results))
        self.set_status(f"Scan complete ({count} files)")

    def run_hardening(self):
        self.harden_text.delete("1.0", "end")
        lines = ["=== Hardening Suggestions (Linux-style) ===\n"]
        if self.is_linux:
            checks = [
                ("SSH root login", "Check /etc/ssh/sshd_config for PermitRootLogin no"),
                ("Firewall", "Ensure ufw or iptables is enabled"),
                ("Unattended upgrades", "Enable automatic security updates"),
                ("Fail2ban", "Consider installing fail2ban for SSH protection"),
                ("File permissions", "Review world-writable files (find / -perm -0002)"),
                ("SUID binaries", "Audit SUID binaries periodically"),
            ]
            for title, advice in checks:
                lines.append(f"• {title}")
                lines.append(f"  → {advice}\n")
            # Simple checks
            try:
                subprocess.check_output(["which", "ufw"], stderr=subprocess.DEVNULL)
                lines.append("ufw is installed.")
            except Exception:
                lines.append("ufw is NOT installed. Consider: sudo apt install ufw")
        else:
            lines.append("Hardening tips are primarily for Linux.")
            lines.append("On Windows:")
            lines.append("  • Keep Windows Defender enabled")
            lines.append("  • Enable Controlled Folder Access")
            lines.append("  • Use strong account passwords / PIN")
            lines.append("  • Keep the system updated")
        lines.append("\nAlways test changes in a safe environment.")
        self.harden_text.insert("1.0", "\n".join(lines))
        self.set_status("Hardening checks ready")

def main():
    root = tk.Tk()
    # Center
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 325
    root.geometry(f"+{x}+{y}")
    app = Lin64xSecurity(root)
    root.mainloop()

if __name__ == "__main__":
    main()
