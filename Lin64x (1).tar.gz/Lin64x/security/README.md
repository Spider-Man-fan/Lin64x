# Lin64x Security App

Linux-style hybrid security monitor.

## Features
- Process list (ps / tasklist)
- Firewall & open port checks (ufw, iptables, ss on Linux)
- File integrity scanner (SHA256 hashes)
- Hardening suggestions
- Dark UI matching the rest of Lin64x

## Run
```bash
python security/lin64x_security.py
```

Works on both Linux and Windows (full features on Linux).
