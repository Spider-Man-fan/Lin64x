#!/usr/bin/env python3
"""
Lin64x Visual Studio
Helper for detecting and launching Visual Studio / VS Code.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox, filedialog
import platform
import subprocess
import os
import shutil
from pathlib import Path

class VisualStudioApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Visual Studio — Lin64x")
        self.root.geometry("860x580")
        self.root.configure(bg="#1e1e1e")

        self.is_windows = platform.system() == "Windows"
        self.is_linux = platform.system() == "Linux"
        self.vs_path = self.detect_vs()
        self.vscode_path = self.detect_vscode()

        self.create_ui()
        self.show_status()

    def detect_vs(self):
        if not self.is_windows:
            return None
        candidates = [
            r"C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\devenv.exe",
            r"C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\IDE\devenv.exe",
            r"C:\Program Files\Microsoft Visual Studio\2022\Enterprise\Common7\IDE\devenv.exe",
            r"C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\Common7\IDE\devenv.exe",
        ]
        for p in candidates:
            if os.path.exists(p):
                return p
        return shutil.which("devenv")

    def detect_vscode(self):
        for cmd in ["code", "code-insiders"]:
            path = shutil.which(cmd)
            if path:
                return path
        if self.is_windows:
            candidates = [
                os.path.expandvars(r"%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe"),
                r"C:\Program Files\Microsoft VS Code\Code.exe",
            ]
            for p in candidates:
                if os.path.exists(p):
                    return p
        return None

    def create_ui(self):
        header = tk.Frame(self.root, bg="#68217a", height=52)
        header.pack(fill="x")
        tk.Label(header, text="Visual Studio", font=("Segoe UI", 16, "bold"),
                 fg="white", bg="#68217a").pack(side="left", padx=15, pady=12)
        tk.Label(header, text="Lin64x Helper", font=("Segoe UI", 10),
                 fg="#e0c0e8", bg="#68217a").pack(side="left")

        toolbar = tk.Frame(self.root, bg="#1e1e1e")
        toolbar.pack(fill="x", padx=10, pady=6)
        tk.Button(toolbar, text="Launch Visual Studio", command=self.launch_vs,
                  bg="#68217a", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Launch VS Code", command=self.launch_vscode,
                  bg="#007acc", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Open Folder", command=self.open_folder,
                  bg="#3c3c3c", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Refresh", command=self.show_status,
                  bg="#3c3c3c", fg="white", relief="flat").pack(side="left", padx=4)

        self.output = scrolledtext.ScrolledText(self.root, bg="#1e1e1e", fg="#d4d4d4",
                                                 font=("Consolas", 10), relief="flat")
        self.output.pack(fill="both", expand=True, padx=10, pady=5)
        self.output.tag_config("ok", foreground="#4ec9b0")
        self.output.tag_config("err", foreground="#f44747")
        self.output.tag_config("info", foreground="#58a6ff")

        self.status = tk.Label(self.root, text="Ready", bg="#68217a", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def show_status(self):
        self.output.delete("1.0", "end")
        lines = ["=== Visual Studio Status ===\n"]
        lines.append(f"Platform: {platform.system()} {platform.release()}\n")
        if self.vs_path:
            lines.append(f"Visual Studio: FOUND\n  {self.vs_path}\n")
        else:
            lines.append("Visual Studio: Not detected")
            if self.is_windows:
                lines.append("  Install from https://visualstudio.microsoft.com/\n")
            else:
                lines.append("  Full Visual Studio is Windows-only. Use VS Code instead.\n")
        if self.vscode_path:
            lines.append(f"VS Code: FOUND\n  {self.vscode_path}\n")
        else:
            lines.append("VS Code: Not detected")
            lines.append("  Install from https://code.visualstudio.com/\n")
        lines.append("\n--- Actions ---")
        lines.append("• Launch Visual Studio — opens the full IDE (Windows)")
        lines.append("• Launch VS Code — opens the lightweight editor")
        lines.append("• Open Folder — open a project folder in the available editor")
        self.output.insert("1.0", "\n".join(lines))
        self.status.config(text="Status refreshed")

    def launch_vs(self):
        if not self.vs_path:
            messagebox.showwarning("Not found", "Visual Studio is not installed or not detected.")
            return
        try:
            subprocess.Popen([self.vs_path])
            self.output.insert("end", "\nLaunched Visual Studio.\n", "ok")
        except Exception as e:
            self.output.insert("end", f"\nError: {e}\n", "err")

    def launch_vscode(self):
        if not self.vscode_path:
            messagebox.showwarning("Not found", "VS Code is not installed.")
            return
        try:
            subprocess.Popen([self.vscode_path])
            self.output.insert("end", "\nLaunched VS Code.\n", "ok")
        except Exception as e:
            self.output.insert("end", f"\nError: {e}\n", "err")

    def open_folder(self):
        path = filedialog.askdirectory(title="Select project folder")
        if not path:
            return
        editor = self.vscode_path or self.vs_path
        if not editor:
            messagebox.showwarning("No editor", "Neither VS Code nor Visual Studio was found.")
            return
        try:
            subprocess.Popen([editor, path])
            self.output.insert("end", f"\nOpened folder: {path}\n", "ok")
        except Exception as e:
            self.output.insert("end", f"\nError: {e}\n", "err")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 430
    y = (root.winfo_screenheight() // 2) - 290
    root.geometry(f"+{x}+{y}")
    app = VisualStudioApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
