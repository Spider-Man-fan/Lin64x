# Visual Studio — Lin64x

Helper for Visual Studio and VS Code.

## Features
- Detect Visual Studio (Windows)
- Detect VS Code (Linux & Windows)
- Launch either editor
- Open a project folder
- Status display with install links

## Run
```bash
python visualstudio/visualstudio.py
```

Full Visual Studio is Windows-only. VS Code works on both platforms.
