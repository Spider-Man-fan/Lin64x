# Ubuntu — Lin64x

Helper and reference for Ubuntu Linux.

## Sections
- Overview
- Package Management (APT)
- System Updates
- Desktop & GNOME
- Common Commands
- Troubleshooting

## Run
```bash
python ubuntu/ubuntu.py
```
