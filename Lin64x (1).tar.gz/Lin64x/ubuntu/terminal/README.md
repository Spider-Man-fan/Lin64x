# Ubuntu Terminal & Files

Ubuntu-styled terminal and file manager for Lin64x.

## Run
```bash
python ubuntu/terminal/ubuntu_terminal.py
python ubuntu/files/ubuntu_files.py
```
