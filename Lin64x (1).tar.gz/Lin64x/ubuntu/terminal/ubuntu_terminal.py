#!/usr/bin/env python3
"""
Ubuntu Terminal — Lin64x
Simple terminal with Ubuntu styling.
"""

import tkinter as tk
from tkinter import scrolledtext, font as tkfont
import subprocess
import threading
import os
import platform

class UbuntuTerminal:
    def __init__(self, root):
        self.root = root
        self.root.title("Ubuntu Terminal")
        self.root.geometry("860x520")
        self.root.configure(bg="#300a24")

        self.cwd = os.path.expanduser("~")
        self.mono = tkfont.Font(family="Ubuntu Mono", size=12)
        if "Ubuntu Mono" not in tkfont.families():
            self.mono = tkfont.Font(family="Consolas", size=11)

        self.create_ui()
        self.write_prompt()

    def create_ui(self):
        header = tk.Frame(self.root, bg="#e95420", height=36)
        header.pack(fill="x")
        tk.Label(header, text="Ubuntu Terminal", font=("Segoe UI", 12, "bold"),
                 fg="white", bg="#e95420").pack(side="left", padx=12, pady=6)

        self.output = scrolledtext.ScrolledText(
            self.root, bg="#300a24", fg="#ffffff", insertbackground="#ffffff",
            font=self.mono, relief="flat"
        )
        self.output.pack(fill="both", expand=True, padx=4, pady=4)
        self.output.tag_config("prompt", foreground="#e95420")
        self.output.tag_config("error", foreground="#ff6b6b")

        self.output.bind("<Return>", self.on_enter)
        self.output.bind("<Key>", self.on_key)
        self.output.focus()

    def write_prompt(self):
        user = os.getenv("USER", "user")
        host = platform.node() or "ubuntu"
        short = os.path.basename(self.cwd) or "~"
        prompt = f"{user}@{host}:{short}$ "
        self.output.insert("end", prompt, "prompt")
        self.output.mark_set("input_start", "end-1c")
        self.output.see("end")

    def on_key(self, event):
        if self.output.compare("insert", "<", "input_start"):
            self.output.mark_set("insert", "end")
            return "break"

    def on_enter(self, event):
        cmd = self.output.get("input_start", "end-1c").strip()
        self.output.insert("end", "\n")
        if cmd:
            self.run_command(cmd)
        else:
            self.write_prompt()
        return "break"

    def run_command(self, cmd):
        if cmd == "exit":
            self.root.destroy()
            return
        if cmd.startswith("cd "):
            path = cmd[3:].strip() or os.path.expanduser("~")
            path = os.path.expanduser(path)
            if not os.path.isabs(path):
                path = os.path.join(self.cwd, path)
            if os.path.isdir(path):
                self.cwd = os.path.abspath(path)
            else:
                self.output.insert("end", f"bash: cd: {path}: No such file or directory\n", "error")
            self.write_prompt()
            return

        def worker():
            try:
                result = subprocess.run(cmd, shell=True, cwd=self.cwd,
                                        capture_output=True, text=True, timeout=60)
                out = result.stdout + result.stderr
                if out:
                    self.root.after(0, lambda: self.output.insert("end", out))
            except Exception as e:
                self.root.after(0, lambda: self.output.insert("end", f"{e}\n", "error"))
            self.root.after(0, self.write_prompt)
        threading.Thread(target=worker, daemon=True).start()

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 430
    y = (root.winfo_screenheight() // 2) - 260
    root.geometry(f"+{x}+{y}")
    app = UbuntuTerminal(root)
    root.mainloop()

if __name__ == "__main__":
    main()
