#!/usr/bin/env python3
"""
Ubuntu File Manager — Lin64x
Simple file manager with Ubuntu styling.
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import os
import shutil
import subprocess
import platform
from pathlib import Path
from datetime import datetime

class UbuntuFiles:
    def __init__(self, root):
        self.root = root
        self.root.title("Ubuntu Files")
        self.root.geometry("900x580")
        self.root.configure(bg="#300a24")

        self.current = Path.home()
        self.create_ui()
        self.refresh()

    def create_ui(self):
        header = tk.Frame(self.root, bg="#e95420", height=40)
        header.pack(fill="x")
        tk.Label(header, text="Ubuntu Files", font=("Segoe UI", 14, "bold"),
                 fg="white", bg="#e95420").pack(side="left", padx=12, pady=6)

        toolbar = tk.Frame(self.root, bg="#2c001e")
        toolbar.pack(fill="x")
        tk.Button(toolbar, text="↑", command=self.go_up, bg="#3c3c3c", fg="white",
                  relief="flat", width=3).pack(side="left", padx=2, pady=4)
        tk.Button(toolbar, text="Home", command=self.go_home, bg="#3c3c3c", fg="white",
                  relief="flat").pack(side="left", padx=2)
        self.path_var = tk.StringVar()
        tk.Entry(toolbar, textvariable=self.path_var, bg="#3c3c3c", fg="white",
                 insertbackground="white", relief="flat").pack(side="left", fill="x", expand=True, padx=6, ipady=3)
        tk.Button(toolbar, text="Go", command=self.go_to, bg="#e95420", fg="white",
                  relief="flat").pack(side="left", padx=4)

        list_frame = tk.Frame(self.root, bg="#300a24")
        list_frame.pack(fill="both", expand=True, padx=6, pady=4)

        self.tree = ttk.Treeview(list_frame, columns=("size", "modified"), show="tree headings")
        self.tree.heading("#0", text="Name")
        self.tree.heading("size", text="Size")
        self.tree.heading("modified", text="Modified")
        self.tree.column("#0", width=400)
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<Double-1>", self.on_open)

        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")

        actions = tk.Frame(self.root, bg="#2c001e")
        actions.pack(fill="x")
        tk.Button(actions, text="New Folder", command=self.new_folder, bg="#3c3c3c", fg="white",
                  relief="flat").pack(side="left", padx=4, pady=4)
        tk.Button(actions, text="Delete", command=self.delete, bg="#c42b1c", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(actions, text="Open", command=self.on_open, bg="#e95420", fg="white",
                  relief="flat").pack(side="left", padx=4)

        self.status = tk.Label(self.root, text="Ready", bg="#e95420", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        self.path_var.set(str(self.current))
        try:
            entries = sorted(self.current.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            for e in entries:
                try:
                    size = "" if e.is_dir() else f"{e.stat().st_size:,}"
                    mtime = datetime.fromtimestamp(e.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
                    self.tree.insert("", "end", text=e.name, values=(size, mtime))
                except Exception:
                    continue
            self.status.config(text=f"{len(entries)} items")
        except Exception as ex:
            self.status.config(text=str(ex))

    def go_up(self):
        if self.current.parent != self.current:
            self.current = self.current.parent
            self.refresh()

    def go_home(self):
        self.current = Path.home()
        self.refresh()

    def go_to(self):
        p = Path(self.path_var.get())
        if p.is_dir():
            self.current = p
            self.refresh()

    def on_open(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        name = self.tree.item(sel[0])["text"]
        path = self.current / name
        if path.is_dir():
            self.current = path
            self.refresh()
        else:
            try:
                if platform.system() == "Windows":
                    os.startfile(path)
                else:
                    subprocess.Popen(["xdg-open", str(path)])
            except Exception as e:
                messagebox.showerror("Open", str(e))

    def new_folder(self):
        name = simpledialog.askstring("New Folder", "Name:")
        if name:
            try:
                (self.current / name).mkdir()
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def delete(self):
        sel = self.tree.selection()
        if not sel:
            return
        name = self.tree.item(sel[0])["text"]
        path = self.current / name
        if messagebox.askyesno("Delete", f"Delete {name}?"):
            try:
                if path.is_dir():
                    shutil.rmtree(path)
                else:
                    path.unlink()
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error", str(e))

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 290
    root.geometry(f"+{x}+{y}")
    app = UbuntuFiles(root)
    root.mainloop()

if __name__ == "__main__":
    main()
