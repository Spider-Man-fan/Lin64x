#!/usr/bin/env python3
"""
Lin64x Ubuntu App
Helper and reference for Ubuntu Linux.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox
import platform
import subprocess
import sys
from pathlib import Path

class UbuntuApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ubuntu — Lin64x")
        self.root.geometry("900x620")
        self.root.configure(bg="#2c001e")

        self.is_linux = platform.system() == "Linux"
        self.project_root = Path(__file__).parent.parent

        self.create_ui()
        self.show_overview()

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#e95420", height=52)
        header.pack(fill="x")
        tk.Label(header, text="Ubuntu", font=("Segoe UI", 18, "bold"),
                 fg="white", bg="#e95420").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="Lin64x Helper", font=("Segoe UI", 10),
                 fg="#ffe0d0", bg="#e95420").pack(side="left")

        # Sidebar
        sidebar = tk.Frame(self.root, bg="#2c001e", width=200)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        sections = [
            ("Overview", self.show_overview),
            ("Package Management", self.show_packages),
            ("System Updates", self.show_updates),
            ("Desktop & GNOME", self.show_desktop),
            ("Common Commands", self.show_commands),
            ("Troubleshooting", self.show_troubleshoot),
        ]
        for name, cmd in sections:
            btn = tk.Button(sidebar, text=name, font=("Segoe UI", 10),
                            bg="#2c001e", fg="#ffffff", relief="flat", anchor="w",
                            command=cmd)
            btn.pack(fill="x", padx=6, pady=2)

        # Content
        self.content = tk.Frame(self.root, bg="#300a24")
        self.content.pack(side="right", fill="both", expand=True)

    def clear(self):
        for w in self.content.winfo_children():
            w.destroy()

    def add_title(self, title):
        tk.Label(self.content, text=title, font=("Segoe UI", 16, "bold"),
                 bg="#300a24", fg="#e95420").pack(pady=10, padx=15, anchor="w")

    def add_text(self, text):
        box = scrolledtext.ScrolledText(self.content, bg="#300a24", fg="#ffffff",
                                         font=("Consolas", 10), relief="flat")
        box.pack(fill="both", expand=True, padx=15, pady=5)
        box.insert("1.0", text)
        box.config(state="disabled")

    def show_overview(self):
        self.clear()
        self.add_title("Ubuntu Overview")
        text = """Ubuntu is a popular Debian-based Linux distribution.

This Lin64x app provides quick references for common Ubuntu tasks.

Key points:
• Uses APT for package management
• GNOME desktop by default
• LTS releases every 2 years
• Large community and documentation

Official site: https://ubuntu.com
"""
        self.add_text(text)

    def show_packages(self):
        self.clear()
        self.add_title("Package Management")
        text = """APT commands:

sudo apt update                 # Refresh package lists
sudo apt upgrade                # Upgrade installed packages
sudo apt full-upgrade           # Full upgrade (may remove packages)
sudo apt install package        # Install a package
sudo apt remove package         # Remove a package
sudo apt purge package          # Remove + config files
sudo apt autoremove             # Remove unused dependencies
sudo apt search keyword         # Search for packages
apt list --installed            # List installed packages

Snap (optional):
sudo snap install package
snap list
"""
        self.add_text(text)

    def show_updates(self):
        self.clear()
        self.add_title("System Updates")
        text = """Update Ubuntu:

sudo apt update && sudo apt upgrade -y

For release upgrades:
sudo do-release-upgrade

Check current version:
lsb_release -a
cat /etc/os-release

Automatic updates:
Settings → Software & Updates → Updates tab
"""
        self.add_text(text)

    def show_desktop(self):
        self.clear()
        self.add_title("Desktop & GNOME")
        text = """GNOME desktop tips:

• Activities overview: Super key
• Switch windows: Alt+Tab
• Workspaces: Super+Page Up/Down
• Settings: gnome-control-center

Extensions:
Install GNOME Extensions app or use extensions.gnome.org

Change theme:
gnome-tweaks
"""
        self.add_text(text)

    def show_commands(self):
        self.clear()
        self.add_title("Common Commands")
        text = """Useful Ubuntu commands:

whoami
pwd
ls -la
df -h
free -h
systemctl status
journalctl -xe
ip addr
ufw status
sudo reboot
sudo poweroff

Open terminal: Ctrl+Alt+T
"""
        self.add_text(text)
        btn = tk.Button(self.content, text="Open Cmd + Sudo", command=self.open_cmd,
                        bg="#e95420", fg="white", relief="flat")
        btn.pack(pady=6)

    def show_troubleshoot(self):
        self.clear()
        self.add_title("Troubleshooting")
        text = """Common Ubuntu issues:

Broken packages:
  sudo apt --fix-broken install
  sudo dpkg --configure -a

Network:
  sudo systemctl restart NetworkManager

Display:
  Boot with nomodeset (GRUB)
  Check Additional Drivers

Boot issues:
  Recovery mode from GRUB
  fsck from recovery

Use Lin64x Troubleshooting app for more help.
"""
        self.add_text(text)

    def open_cmd(self):
        path = self.project_root / "cmd_sudo" / "cmd_sudo.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 310
    root.geometry(f"+{x}+{y}")
    app = UbuntuApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
