# Lin64xwin64P

Hidden Windows processor information module.

- Not shown in the main Desktop Start menu
- Displayed only inside **Settings(Linux-windows)** under the "Lin64xwin64P" category
- Collects processor name, cores, architecture, and (on Windows) WMIC / PowerShell details

## Usage
Open Settings and select **Lin64xwin64P**.
