#!/usr/bin/env python3
"""
Settings(Linux-windows) - Lin64x System Tools
Unified settings and system tools for Linux and Windows hybrid environment.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import platform
import os
import sys
import subprocess
import socket
from pathlib import Path

# Import hidden processor module
try:
    from lin64xwin64p import format_processor_display
except ImportError:
    def format_processor_display():
        return "Lin64xwin64P module not found."

# Import account manager
try:
    from accounts import (
        get_current_info, swap_account, is_admin, get_current,
        set_password, has_password, forgot_password, get_account
    )
except ImportError:
    def get_current_info():
        return {"display": "User", "role": "standard"}
    def swap_account(password=None):
        return "user"
    def is_admin():
        return False
    def get_current():
        return "user"
    def set_password(a, p, r=""):
        return False
    def has_password(a):
        return False
    def forgot_password(a, r):
        return False
    def get_account(a):
        return {}

class SettingsLinuxWindows:
    def __init__(self, root):
        self.root = root
        self.root.title("Settings(Linux-windows)")
        self.root.geometry("950x650")
        self.root.configure(bg="#f3f3f3")

        self.is_linux = platform.system() == "Linux"
        self.is_windows = platform.system() == "Windows"
        self.project_root = Path(__file__).parent.parent

        self.create_ui()
        self.show_system()

    def create_ui(self):
        # Sidebar
        sidebar = tk.Frame(self.root, bg="#e6e6e6", width=230)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        tk.Label(sidebar, text="Settings", font=("Segoe UI", 16, "bold"),
                 bg="#e6e6e6", fg="#1a1a1a").pack(pady=15, padx=15, anchor="w")
        tk.Label(sidebar, text="Linux-Windows", font=("Segoe UI", 9),
                 bg="#e6e6e6", fg="#666").pack(padx=15, anchor="w")

        categories = [
            ("System", self.show_system),
            ("Accounts", self.show_accounts),
            ("lin(power)settings", self.show_power),
            ("Updates", self.show_updates),
            ("Administrator Setup", self.show_admin_setup),
            ("Lin64xwin64P", self.show_processor),
            ("CPU / GPU / RAM", self.show_processor),
            ("Network", self.show_network),
            ("Storage", self.show_storage),
            ("Processes", self.show_processes),
            ("Linux Tools", self.show_linux_tools),
            ("Windows Tools", self.show_windows_tools),
            ("Hybrid Tools", self.show_hybrid),
            ("About", self.show_about),
        ]
        for name, cmd in categories:
            btn = tk.Button(sidebar, text=name, font=("Segoe UI", 11),
                            bg="#e6e6e6", fg="#1a1a1a", relief="flat", anchor="w",
                            command=cmd)
            btn.pack(fill="x", padx=8, pady=2)

        # Content
        self.content = tk.Frame(self.root, bg="#ffffff")
        self.content.pack(side="right", fill="both", expand=True)

    def clear_content(self):
        for w in self.content.winfo_children():
            w.destroy()

    def add_title(self, title):
        tk.Label(self.content, text=title, font=("Segoe UI", 20, "bold"),
                 bg="#ffffff", fg="#1a1a1a").pack(pady=15, padx=25, anchor="w")

    def add_text(self, text):
        box = scrolledtext.ScrolledText(self.content, bg="#ffffff", fg="#333",
                                         font=("Consolas", 10), relief="flat", height=18)
        box.pack(fill="both", expand=True, padx=25, pady=10)
        box.insert("1.0", text)
        box.config(state="disabled")
        return box

    def show_system(self):
        self.clear_content()
        self.add_title("System")
        info = f"""Operating System : {platform.system()} {platform.release()}
Version          : {platform.version()}
Architecture     : {platform.machine()}
Processor        : {platform.processor() or 'Unknown'}
Python           : {sys.version.split()[0]}
Hostname         : {socket.gethostname()}
User             : {os.getlogin() if hasattr(os, 'getlogin') else 'N/A'}
Working Dir      : {os.getcwd()}
"""
        self.add_text(info)

    def show_processor(self):
        self.clear_content()
        self.add_title("Lin64xwin64P")
        text = format_processor_display()
        self.add_text(text)

    def show_accounts(self):
        self.clear_content()
        self.add_title("Accounts")
        info = get_current_info()
        current = get_current()
        text = f"""=== Lin64x Accounts ===

Current Account : {info.get('display', 'User')}
Role            : {info.get('role', 'standard')}
Account ID      : {current}
Password Set    : {"Yes" if has_password(current) else "No"}

Available accounts:
  • User          — Standard privileges
  • Administrator — Elevated privileges

Use Account Swap to switch (password required if set).
Use Create / Change Password to set a password.
Use Forgot Password if you cannot remember it.
"""
        self.add_text(text)

        btn_frame = tk.Frame(self.content, bg="#ffffff")
        btn_frame.pack(pady=8)
        tk.Button(btn_frame, text="Account Swap", command=self.do_swap,
                  bg="#0078d4", fg="white", relief="flat", padx=12).pack(side="left", padx=3)
        tk.Button(btn_frame, text="Create / Change Password", command=self.create_password,
                  bg="#107c10", fg="white", relief="flat", padx=12).pack(side="left", padx=3)
        tk.Button(btn_frame, text="Forgot Password", command=self.forgot_password_ui,
                  bg="#ff8c00", fg="white", relief="flat", padx=12).pack(side="left", padx=3)

        self.account_status = tk.Label(self.content, text="", bg="#ffffff", fg="#107c10",
                                        font=("Segoe UI", 10))
        self.account_status.pack(pady=4)

    def do_swap(self):
        from tkinter import simpledialog
        current = get_current()
        target = "admin" if current == "user" else "user"
        if has_password(target):
            pwd = simpledialog.askstring("Password", f"Enter password for {target}:", show="*")
            if pwd is None:
                return
            result = swap_account(pwd)
            if result is None:
                messagebox.showerror("Access Denied", "Incorrect password.")
                return
        else:
            result = swap_account()
        info = get_current_info()
        self.account_status.config(text=f"Swapped to: {info.get('display')} ({result})")
        self.show_accounts()

    def create_password(self):
        from tkinter import simpledialog
        account = simpledialog.askstring("Account", "Which account? (user or admin)", initialvalue=get_current())
        if account not in ("user", "admin"):
            messagebox.showwarning("Invalid", "Enter 'user' or 'admin'.")
            return
        new_pwd = simpledialog.askstring("New Password", f"New password for {account}:", show="*")
        if not new_pwd:
            return
        recovery = simpledialog.askstring("Recovery", "Recovery word (used for Forgot Password):") or ""
        if set_password(account, new_pwd, recovery):
            messagebox.showinfo("Success", f"Password set for {account}.")
        else:
            messagebox.showerror("Error", "Could not save password.")
        self.show_accounts()

    def forgot_password_ui(self):
        from tkinter import simpledialog
        account = simpledialog.askstring("Forgot Password", "Which account? (user or admin)")
        if account not in ("user", "admin"):
            return
        if not has_password(account):
            messagebox.showinfo("No Password", f"{account} has no password set.")
            return
        answer = simpledialog.askstring("Recovery", "Enter your recovery word:")
        if answer is None:
            return
        if forgot_password(account, answer):
            new_pwd = simpledialog.askstring("Reset", "Enter a new password:", show="*")
            if new_pwd and set_password(account, new_pwd, answer):
                messagebox.showinfo("Reset", f"Password reset for {account}.")
            else:
                messagebox.showerror("Error", "Could not reset password.")
        else:
            messagebox.showerror("Failed", "Recovery word does not match.")
        self.show_accounts()

    def show_updates(self):
        self.clear_content()
        self.add_title("Updates")
        text = """=== Lin64x Updates ===

Recent additions and changes:

• App Fixer — diagnose and repair Lin64x apps
• Malware Removal — ransomware / malware / virus guidance
• Docker app — container helper
• Ubuntu + Terminal + File Manager
• Bootloader — real first-stage bootloader (bootloader.asm)
• VMware mode — change or leave mode
• Salt + hash for account passwords
• lin(power)settings — Restart / Shutdown / Sleep
• Account system — User / Administrator with password + recovery
• Backup and Restore buttons on the taskbar
• Windows Command + Sudo — ipconfig, ping, whois, Explore
• Software Maker — Python, Tkinter, C++, Java
• web browser — Firefox style
• lin64xcamera, lin64xcalculator, Lin64xfile
• Home screen when Windows logo is pressed
• CPU / GPU / RAM / Storage in Settings

How to update:
1. Download the latest Lin64x.tar.gz
2. Extract over your current folder (or to a new folder)
3. Use Backup first if you want to keep settings
4. Restart the desktop shell

No automatic update checker is included.
Check the source or archive date for the newest version.
"""
        self.add_text(text)
        btn_frame = tk.Frame(self.content, bg="#ffffff")
        btn_frame.pack(pady=8)
        tk.Button(btn_frame, text="Download Latest Version", command=self.download_latest,
                  bg="#107c10", fg="white", relief="flat", padx=14).pack(side="left", padx=4)
        tk.Button(btn_frame, text="Open App Fixer", command=self.open_app_fixer,
                  bg="#0078d4", fg="white", relief="flat", padx=12).pack(side="left", padx=4)

    def download_latest(self):
        """Show how to get the latest Lin64x version."""
        messagebox.showinfo(
            "Download Latest",
            "To get the latest Lin64x:\n\n"
            "1. Use the Lin64x.tar.gz file you already have\n"
            "2. Or ask for a new archive\n\n"
            "There is no online download link configured."
        )

    def open_app_fixer(self):
        path = self.project_root / "app_fixer" / "app_fixer.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

    def show_power(self):
        self.clear_content()
        self.add_title("lin(power)settings")
        text = """=== Lin64x Power Options ===

Control system power from Lin64x.

--- Actions ---
• Restart   — Restart the computer
• Shutdown  — Shut down the computer
• Sleep     — Suspend the system (if supported)

--- Notes ---
These actions affect the whole computer.
Unsaved work in other programs may be lost.
Lin64x does not lock the system — you can always exit normally.

--- Platform Commands ---
Windows:
  shutdown /r /t 5     Restart
  shutdown /s /t 5     Shutdown
  rundll32.exe powrprof.dll,SetSuspendState 0,1,0   Sleep

Linux:
  systemctl reboot
  systemctl poweroff
  systemctl suspend
"""
        self.add_text(text)

        btn_frame = tk.Frame(self.content, bg="#ffffff")
        btn_frame.pack(pady=10)
        tk.Button(btn_frame, text="Restart", command=self.power_restart,
                  bg="#ff8c00", fg="white", relief="flat", padx=14).pack(side="left", padx=4)
        tk.Button(btn_frame, text="Shutdown", command=self.power_shutdown,
                  bg="#c42b1c", fg="white", relief="flat", padx=14).pack(side="left", padx=4)
        tk.Button(btn_frame, text="Sleep", command=self.power_sleep,
                  bg="#0078d4", fg="white", relief="flat", padx=14).pack(side="left", padx=4)

    def power_restart(self):
        self._power_action("restart")

    def power_shutdown(self):
        self._power_action("shutdown")

    def power_sleep(self):
        self._power_action("sleep")

    def _power_action(self, action):
        try:
            if self.is_windows:
                if action == "restart":
                    subprocess.Popen(["shutdown", "/r", "/t", "5"])
                elif action == "shutdown":
                    subprocess.Popen(["shutdown", "/s", "/t", "5"])
                elif action == "sleep":
                    subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
            elif self.is_linux:
                if action == "restart":
                    subprocess.Popen(["systemctl", "reboot"])
                elif action == "shutdown":
                    subprocess.Popen(["systemctl", "poweroff"])
                elif action == "sleep":
                    subprocess.Popen(["systemctl", "suspend"])
            else:
                messagebox.showinfo("Power", f"{action.title()} is not supported on this platform.")
                return
            messagebox.showinfo("Power", f"{action.title()} initiated.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not {action}: {e}")

    def show_admin_setup(self):
        self.clear_content()
        self.add_title("Administrator Setup")
        text = """=== Administrator Setup ===

This section helps you configure elevated (admin) access for Lin64x tools.

--- Windows ---
• Run Lin64x tools as Administrator:
  Right-click the app or shortcut → Run as administrator

• Enable built-in Administrator account (advanced):
  net user administrator /active:yes

• Check current privileges:
  whoami /groups
  (Look for High Mandatory Level or Administrators)

• UAC (User Account Control):
  Control Panel → User Accounts → Change User Account Control settings

--- Linux (sudo) ---
• Check if your user can use sudo:
  sudo -l

• Add user to sudo group (Debian/Ubuntu):
  sudo usermod -aG sudo $USER
  (Log out and back in)

• Add user to wheel group (Fedora/Arch):
  sudo usermod -aG wheel $USER

• Edit sudoers safely:
  sudo visudo

--- Lin64x Tools that need admin ---
• Sudo Commands
• Windows Command + Sudo
• Some Settings checks (disk, processes)
• terminate64xlin (killing system processes)

Tip: Use the Windows Command + Sudo tool for elevated commands.
"""
        self.add_text(text)
        btn_frame = tk.Frame(self.content, bg="#ffffff")
        btn_frame.pack(pady=6)
        tk.Button(btn_frame, text="Open Cmd + Sudo", command=self.open_cmd_sudo,
                  bg="#0078d4", fg="white", relief="flat").pack(side="left", padx=4)
        tk.Button(btn_frame, text="Open Sudo Commands", command=self.open_sudo,
                  bg="#c42b1c", fg="white", relief="flat").pack(side="left", padx=4)

    def open_cmd_sudo(self):
        path = self.project_root / "cmd_sudo" / "cmd_sudo.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

    def open_sudo(self):
        path = self.project_root / "sudo" / "sudo_commands.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

    def show_network(self):
        self.clear_content()
        self.add_title("Network")
        lines = ["=== Network Information ===\n"]
        try:
            hostname = socket.gethostname()
            lines.append(f"Hostname: {hostname}")
            try:
                ip = socket.gethostbyname(hostname)
                lines.append(f"Local IP: {ip}")
            except Exception:
                lines.append("Local IP: Could not resolve")
        except Exception as e:
            lines.append(f"Error: {e}")

        lines.append("\n--- Common Ports (localhost) ---")
        for port, name in [(22, "SSH"), (80, "HTTP"), (443, "HTTPS"), (3389, "RDP"), (8080, "Alt HTTP")]:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.3)
            result = sock.connect_ex(("127.0.0.1", port))
            status = "OPEN" if result == 0 else "closed"
            lines.append(f"  {port} ({name}): {status}")
            sock.close()

        self.add_text("\n".join(lines))

    def show_storage(self):
        self.clear_content()
        self.add_title("Storage")
        lines = ["=== Storage / Disk Info ===\n"]
        try:
            if self.is_linux:
                result = subprocess.check_output(["df", "-h"], text=True, timeout=10)
                lines.append(result)
            elif self.is_windows:
                result = subprocess.check_output(["wmic", "logicaldisk", "get", "size,freespace,caption"], text=True, timeout=10)
                lines.append(result)
            else:
                lines.append("Storage info not available on this platform.")
        except Exception as e:
            lines.append(f"Error: {e}")
        self.add_text("\n".join(lines))

    def show_processes(self):
        self.clear_content()
        self.add_title("Processes")
        lines = ["=== Running Processes (top 40) ===\n"]
        try:
            if self.is_linux:
                result = subprocess.check_output(["ps", "aux"], text=True, timeout=10)
                lines.extend(result.splitlines()[:45])
            elif self.is_windows:
                result = subprocess.check_output(["tasklist"], text=True, timeout=10)
                lines.extend(result.splitlines()[:40])
            else:
                lines.append("Not supported.")
        except Exception as e:
            lines.append(f"Error: {e}")
        self.add_text("\n".join(lines))

    def show_linux_tools(self):
        self.clear_content()
        self.add_title("Linux Tools")
        if not self.is_linux:
            self.add_text("Linux tools are only fully available when running on Linux.\n\nYou can still use hybrid tools from the other tabs.")
            return
        text = """Available Linux system tools (via terminal or hybrid apps):

• ufw / iptables     — Firewall
• systemctl          — Service management
• journalctl         — System logs
• ss / netstat       — Network sockets
• df / du            — Disk usage
• free               — Memory
• top / htop         — Process monitor
• apt / dnf / pacman — Package manager (distro dependent)

Tip: Use Linux4_(Cmd) for full command access.
"""
        self.add_text(text)
        btn_frame = tk.Frame(self.content, bg="#ffffff")
        btn_frame.pack(pady=5)
        tk.Button(btn_frame, text="Open Linux4_(Cmd)", command=self.open_cmd,
                  bg="#0078d4", fg="white", relief="flat").pack()

    def show_windows_tools(self):
        self.clear_content()
        self.add_title("Windows Tools")
        if not self.is_windows:
            self.add_text("Windows tools are only fully available when running on Windows.\n\nHybrid tools still work on Linux.")
            return
        text = """Available Windows system tools:

• tasklist / taskkill — Process management
• ipconfig            — Network config
• systeminfo          — System details
• wmic                — WMI queries
• msconfig            — System configuration
• control             — Control Panel
• powershell          — PowerShell

Tip: Use Linux4_(Cmd) or Win32x64(notepad) for related tasks.
"""
        self.add_text(text)

    def show_hybrid(self):
        self.clear_content()
        self.add_title("Hybrid Tools")
        text = """Lin64x Hybrid Tools

These work on both Linux and Windows:

• Desktop Shell          — os_apps/desktop.py
• Code Editor            — editor/lin64x_editor.py
• Security App           — security/lin64x_security.py
• Linux4_(Cmd)           — cmd/linux4_cmd.py
• Lin(python)            — python/lin_python.py
• python.lin32           — python/python_lin32.py
• Win32x64(notepad)      — notepad/win32x64_notepad.py
• SD Digital Save Card   — sd_card/digital_save.py
• OOBE Wizard            — oobe/oobe_wizard.py
• File Explorer          — os_apps/file_explorer.py
"""
        self.add_text(text)
        btn_frame = tk.Frame(self.content, bg="#ffffff")
        btn_frame.pack(pady=8)
        tk.Button(btn_frame, text="Launch Desktop", command=self.open_desktop,
                  bg="#107c10", fg="white", relief="flat", padx=10).pack(side="left", padx=5)
        tk.Button(btn_frame, text="Open Cmd", command=self.open_cmd,
                  bg="#0078d4", fg="white", relief="flat", padx=10).pack(side="left", padx=5)

    def show_about(self):
        self.clear_content()
        self.add_title("About")
        text = """Settings(Linux-windows)
Lin64x Hybrid System Tools

Version 1.0

Provides unified access to system information,
network, storage, processes, and platform-specific
tools for both Linux and Windows.

Part of the Lin64x hybrid software suite.
"""
        self.add_text(text)

    def open_cmd(self):
        path = self.project_root / "cmd" / "linux4_cmd.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

    def open_desktop(self):
        path = self.project_root / "os_apps" / "desktop.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 475
    y = (root.winfo_screenheight() // 2) - 325
    root.geometry(f"+{x}+{y}")
    app = SettingsLinuxWindows(root)
    root.mainloop()

if __name__ == "__main__":
    main()
