#!/usr/bin/env python3
"""
Lin64x Account Manager
Local accounts with passwords, create password, and forgot password.
"""

import json
import hashlib
import secrets
from pathlib import Path

ACCOUNTS_FILE = Path.home() / ".lin64x_accounts.json"

def hash_password(password, salt=None):
    """Hash a password with salt. Returns (hash, salt)."""
    if salt is None:
        salt = secrets.token_hex(16)
    h = hashlib.sha256((salt + password).encode("utf-8")).hexdigest()
    return h, salt

def verify_password(password, stored_hash, salt):
    """Verify a password against stored hash and salt."""
    if not stored_hash:
        return True  # no password set
    h, _ = hash_password(password, salt)
    return h == stored_hash

DEFAULT_ACCOUNTS = {
    "current": "user",
    "accounts": {
        "user": {
            "name": "User",
            "role": "standard",
            "display": "Standard User",
            "password": "",
            "salt": "",
            "recovery": ""
        },
        "admin": {
            "name": "Administrator",
            "role": "administrator",
            "display": "Administrator",
            "password": "",   # will be set on first load
            "salt": "",
            "recovery": "default"
        }
    }
}

def load_accounts():
    if ACCOUNTS_FILE.exists():
        try:
            with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                for key, defaults in DEFAULT_ACCOUNTS["accounts"].items():
                    if key not in data.get("accounts", {}):
                        data.setdefault("accounts", {})[key] = defaults.copy()
                    else:
                        for field in ("password", "salt", "recovery"):
                            if field not in data["accounts"][key]:
                                data["accounts"][key][field] = defaults.get(field, "")
                # Migrate plain-text admin password if present
                admin = data["accounts"].get("admin", {})
                if admin.get("password") == "admin" and not admin.get("salt"):
                    h, s = hash_password("admin")
                    admin["password"] = h
                    admin["salt"] = s
                    save_accounts(data)
                return data
        except Exception:
            pass
    # First run — hash default admin password
    data = json.loads(json.dumps(DEFAULT_ACCOUNTS))
    h, s = hash_password("admin")
    data["accounts"]["admin"]["password"] = h
    data["accounts"]["admin"]["salt"] = s
    save_accounts(data)
    return data

def save_accounts(data):
    try:
        with open(ACCOUNTS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception:
        return False

def get_current():
    data = load_accounts()
    return data.get("current", "user")

def get_current_info():
    data = load_accounts()
    current = data.get("current", "user")
    return data["accounts"].get(current, DEFAULT_ACCOUNTS["accounts"]["user"])

def get_account(account_id):
    data = load_accounts()
    return data["accounts"].get(account_id)

def has_password(account_id):
    acc = get_account(account_id)
    return bool(acc and acc.get("password"))

def set_password(account_id, new_password, recovery=""):
    data = load_accounts()
    if account_id not in data["accounts"]:
        return False
    h, s = hash_password(new_password)
    data["accounts"][account_id]["password"] = h
    data["accounts"][account_id]["salt"] = s
    if recovery:
        data["accounts"][account_id]["recovery"] = recovery
    return save_accounts(data)

def check_password(account_id, password):
    acc = get_account(account_id)
    if not acc:
        return False
    stored = acc.get("password", "")
    salt = acc.get("salt", "")
    if not stored:
        return True
    return verify_password(password, stored, salt)

def swap_account(password=None):
    """Swap between user and admin. Password required if the target has one."""
    data = load_accounts()
    current = data.get("current", "user")
    target = "admin" if current == "user" else "user"
    target_acc = data["accounts"].get(target, {})
    stored = target_acc.get("password", "")
    salt = target_acc.get("salt", "")
    if stored and not verify_password(password or "", stored, salt):
        return None
    data["current"] = target
    save_accounts(data)
    return data["current"]

def forgot_password(account_id, recovery_answer):
    """Reset password if recovery answer matches. Returns True if reset allowed."""
    acc = get_account(account_id)
    if not acc:
        return False
    stored_recovery = acc.get("recovery", "")
    if not stored_recovery:
        return False
    return recovery_answer.strip().lower() == stored_recovery.strip().lower()

def is_admin():
    return get_current() == "admin"
