# Settings(Linux-windows)

Unified system settings and tools for Linux and Windows.

## Features
- System information
- Network & port checks
- Storage / disk info
- Process list
- Linux-specific tools (on Linux)
- Windows-specific tools (on Windows)
- Quick access to hybrid Lin64x apps

## Run
```bash
python settings/settings_linux_windows.py
```
