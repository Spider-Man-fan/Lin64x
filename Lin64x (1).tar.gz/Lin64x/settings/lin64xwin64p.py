#!/usr/bin/env python3
"""
Lin64xwin64P - Windows Processor Information
Hidden processor details module. Displayed only inside Settings.
"""

import platform
import os
import subprocess

def get_processor_info():
    """Collect Windows (and fallback) processor information."""
    info = {
        "name": "Lin64xwin64P",
        "hidden": True,
        "platform": platform.system(),
        "machine": platform.machine(),
        "processor": platform.processor() or "Unknown",
        "architecture": platform.architecture()[0],
        "cpu_count": os.cpu_count() or "Unknown",
    }

    if platform.system() == "Windows":
        try:
            # Try wmic for more details
            result = subprocess.check_output(
                ["wmic", "cpu", "get", "Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed"],
                text=True, timeout=10, stderr=subprocess.DEVNULL
            )
            info["wmic_raw"] = result.strip()
        except Exception:
            info["wmic_raw"] = "WMIC not available"
        try:
            result = subprocess.check_output(
                ["powershell", "-NoProfile", "-Command",
                 "Get-CimInstance Win32_Processor | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed | Format-List"],
                text=True, timeout=15, stderr=subprocess.DEVNULL
            )
            info["powershell"] = result.strip()
        except Exception:
            info["powershell"] = "PowerShell query failed"
    else:
        info["note"] = "Lin64xwin64P is designed for Windows. Limited info on this platform."
        try:
            if os.path.exists("/proc/cpuinfo"):
                with open("/proc/cpuinfo") as f:
                    lines = [l.strip() for l in f if l.startswith(("model name", "cpu cores", "siblings"))]
                info["linux_cpu"] = "\n".join(lines[:6])
        except Exception:
            pass

    return info

def get_gpu_info():
    """Collect GPU information (Windows preferred, Linux fallback)."""
    gpus = []
    system = platform.system()
    if system == "Windows":
        try:
            result = subprocess.check_output(
                ["wmic", "path", "win32_VideoController", "get", "Name,AdapterRAM,DriverVersion"],
                text=True, timeout=10, stderr=subprocess.DEVNULL
            )
            gpus.append(result.strip())
        except Exception:
            pass
        try:
            result = subprocess.check_output(
                ["powershell", "-NoProfile", "-Command",
                 "Get-CimInstance Win32_VideoController | Select-Object Name, AdapterRAM, DriverVersion | Format-List"],
                text=True, timeout=15, stderr=subprocess.DEVNULL
            )
            if result.strip():
                gpus.append(result.strip())
        except Exception:
            pass
    elif system == "Linux":
        try:
            result = subprocess.check_output(["lspci"], text=True, timeout=10, stderr=subprocess.DEVNULL)
            for line in result.splitlines():
                if "VGA" in line or "3D" in line or "Display" in line:
                    gpus.append(line.strip())
        except Exception:
            pass
        try:
            if shutil_which("nvidia-smi"):
                result = subprocess.check_output(["nvidia-smi", "-L"], text=True, timeout=10)
                gpus.append(result.strip())
        except Exception:
            pass
    return gpus if gpus else ["GPU information not available"]

def shutil_which(cmd):
    import shutil
    return shutil.which(cmd)

def get_ram_info():
    """Collect RAM / memory information."""
    lines = []
    system = platform.system()
    if system == "Windows":
        try:
            result = subprocess.check_output(
                ["wmic", "OS", "get", "TotalVisibleMemorySize,FreePhysicalMemory"],
                text=True, timeout=10, stderr=subprocess.DEVNULL
            )
            lines.append(result.strip())
        except Exception:
            pass
        try:
            result = subprocess.check_output(
                ["powershell", "-NoProfile", "-Command",
                 "$os = Get-CimInstance Win32_OperatingSystem; "
                 "'Total RAM (GB): {0:N2}' -f ($os.TotalVisibleMemorySize/1MB); "
                 "'Free RAM (GB): {0:N2}' -f ($os.FreePhysicalMemory/1MB)"],
                text=True, timeout=15, stderr=subprocess.DEVNULL
            )
            if result.strip():
                lines.append(result.strip())
        except Exception:
            pass
    elif system == "Linux":
        try:
            with open("/proc/meminfo") as f:
                mem = {}
                for line in f:
                    if line.startswith(("MemTotal", "MemFree", "MemAvailable", "Buffers", "Cached")):
                        key, val = line.split(":", 1)
                        mem[key.strip()] = val.strip()
                lines.append("\n".join(f"{k}: {v}" for k, v in mem.items()))
        except Exception:
            lines.append("Could not read /proc/meminfo")
    else:
        lines.append("RAM info not available on this platform")
    return lines if lines else ["RAM information not available"]

def get_storage_info():
    """Collect storage / disk information."""
    lines = []
    system = platform.system()
    if system == "Windows":
        try:
            result = subprocess.check_output(
                ["wmic", "logicaldisk", "get", "Caption,Size,FreeSpace,FileSystem"],
                text=True, timeout=10, stderr=subprocess.DEVNULL
            )
            lines.append(result.strip())
        except Exception:
            pass
        try:
            result = subprocess.check_output(
                ["powershell", "-NoProfile", "-Command",
                 "Get-PSDrive -PSProvider FileSystem | Select-Object Name, Used, Free | Format-Table -AutoSize"],
                text=True, timeout=15, stderr=subprocess.DEVNULL
            )
            if result.strip():
                lines.append(result.strip())
        except Exception:
            pass
    elif system == "Linux":
        try:
            result = subprocess.check_output(["df", "-h"], text=True, timeout=10)
            lines.append(result.strip())
        except Exception:
            lines.append("df command failed")
        try:
            result = subprocess.check_output(["lsblk", "-o", "NAME,SIZE,TYPE,MOUNTPOINT"], text=True, timeout=10)
            lines.append(result.strip())
        except Exception:
            pass
    else:
        lines.append("Storage info not available on this platform")
    return lines if lines else ["Storage information not available"]

def format_processor_display():
    """Return a formatted string for display in Settings (CPU + GPU + RAM + Storage)."""
    data = get_processor_info()
    lines = [
        "=== CPU / Processor (Lin64xwin64P) ===",
        f"Platform   : {data.get('platform')}",
        f"Machine    : {data.get('machine')}",
        f"Processor  : {data.get('processor')}",
        f"Arch       : {data.get('architecture')}",
        f"CPU Count  : {data.get('cpu_count')}",
        "",
    ]
    if "powershell" in data and "failed" not in str(data.get("powershell", "")).lower():
        lines.append("--- CPU Details (PowerShell) ---")
        lines.append(data["powershell"])
        lines.append("")
    elif "wmic_raw" in data and data["wmic_raw"] != "WMIC not available":
        lines.append("--- CPU Details (WMIC) ---")
        lines.append(data["wmic_raw"])
        lines.append("")
    if "linux_cpu" in data:
        lines.append("--- CPU Info (Linux) ---")
        lines.append(data["linux_cpu"])
        lines.append("")

    lines.append("=== GPU / Graphics ===")
    for gpu in get_gpu_info():
        lines.append(gpu)
    lines.append("")

    lines.append("=== RAM / Memory ===")
    for ram in get_ram_info():
        lines.append(ram)
    lines.append("")

    lines.append("=== Storage / Disks ===")
    for storage in get_storage_info():
        lines.append(storage)
    lines.append("")

    lines.append("Note: Hardware info is shown inside Settings.")
    return "\n".join(lines)

if __name__ == "__main__":
    print(format_processor_display())
