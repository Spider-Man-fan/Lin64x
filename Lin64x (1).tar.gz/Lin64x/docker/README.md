# Docker — Lin64x

Helper for Docker containers and images.

## Features
- Check Docker status
- List images and containers
- Pull images
- Run containers
- Command reference

## Requirement
Docker must be installed and in PATH.

## Run
```bash
python docker/docker.py
```
