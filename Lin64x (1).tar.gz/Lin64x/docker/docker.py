#!/usr/bin/env python3
"""
Lin64x Docker App
Helper for Docker commands and container management.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox, simpledialog
import subprocess
import shutil
import threading
import sys
from pathlib import Path

class DockerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Docker — Lin64x")
        self.root.geometry("920x640")
        self.root.configure(bg="#0d1117")

        self.has_docker = shutil.which("docker") is not None
        self.project_root = Path(__file__).parent.parent

        self.create_ui()
        self.show_status()

    def create_ui(self):
        header = tk.Frame(self.root, bg="#2496ed", height=50)
        header.pack(fill="x")
        tk.Label(header, text="Docker", font=("Segoe UI", 18, "bold"),
                 fg="white", bg="#2496ed").pack(side="left", padx=15, pady=10)
        status = "Installed" if self.has_docker else "Not found"
        tk.Label(header, text=status, font=("Segoe UI", 10),
                 fg="#e0f0ff", bg="#2496ed").pack(side="left")

        toolbar = tk.Frame(self.root, bg="#0d1117")
        toolbar.pack(fill="x", padx=8, pady=6)
        buttons = [
            ("Status", self.show_status),
            ("Images", self.show_images),
            ("Containers", self.show_containers),
            ("Run", self.run_container),
            ("Pull", self.pull_image),
            ("Help", self.show_help),
        ]
        for text, cmd in buttons:
            tk.Button(toolbar, text=text, command=cmd, bg="#21262d", fg="white",
                      relief="flat", padx=10).pack(side="left", padx=3)

        self.output = scrolledtext.ScrolledText(self.root, bg="#0d1117", fg="#c9d1d9",
                                                 font=("Consolas", 10), relief="flat")
        self.output.pack(fill="both", expand=True, padx=8, pady=4)
        self.output.tag_config("ok", foreground="#3fb950")
        self.output.tag_config("err", foreground="#f85149")
        self.output.tag_config("info", foreground="#58a6ff")

        self.status = tk.Label(self.root, text="Ready", bg="#2496ed", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def run_docker(self, args, callback=None):
        if not self.has_docker:
            self.output.insert("end", "Docker is not installed or not in PATH.\n", "err")
            self.output.insert("end", "Install from https://docs.docker.com/get-docker/\n", "info")
            return
        def worker():
            try:
                result = subprocess.run(["docker"] + args, capture_output=True, text=True, timeout=120)
                out = result.stdout + result.stderr
                tag = "ok" if result.returncode == 0 else "err"
                self.root.after(0, lambda: self.append(out or "(no output)\n", tag))
            except Exception as e:
                self.root.after(0, lambda: self.append(f"Error: {e}\n", "err"))
            if callback:
                self.root.after(0, callback)
        threading.Thread(target=worker, daemon=True).start()

    def append(self, text, tag=None):
        self.output.insert("end", text, tag)
        self.output.see("end")

    def show_status(self):
        self.output.delete("1.0", "end")
        self.output.insert("end", "=== Docker Status ===\n", "info")
        if not self.has_docker:
            self.output.insert("end", "Docker not found.\n", "err")
            return
        self.run_docker(["version"])
        self.run_docker(["info"])

    def show_images(self):
        self.output.delete("1.0", "end")
        self.output.insert("end", "=== Docker Images ===\n", "info")
        self.run_docker(["images"])

    def show_containers(self):
        self.output.delete("1.0", "end")
        self.output.insert("end", "=== Containers ===\n", "info")
        self.run_docker(["ps", "-a"])

    def run_container(self):
        image = simpledialog.askstring("Run", "Image name (e.g. ubuntu, nginx):")
        if not image:
            return
        self.output.insert("end", f"\nRunning {image}...\n", "info")
        self.run_docker(["run", "--rm", "-it", image, "echo", "Hello from Lin64x Docker"])

    def pull_image(self):
        image = simpledialog.askstring("Pull", "Image to pull (e.g. ubuntu:latest):")
        if not image:
            return
        self.output.insert("end", f"\nPulling {image}...\n", "info")
        self.run_docker(["pull", image])

    def show_help(self):
        self.output.delete("1.0", "end")
        text = """=== Docker Help ===

Common commands:
  docker version
  docker info
  docker images
  docker ps -a
  docker pull ubuntu
  docker run -it ubuntu bash
  docker stop <id>
  docker rm <id>
  docker rmi <image>

This app provides buttons for Status, Images, Containers, Run, and Pull.
Docker must be installed and running (Docker Desktop on Windows/Mac, docker service on Linux).
"""
        self.output.insert("end", text, "info")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 460
    y = (root.winfo_screenheight() // 2) - 320
    root.geometry(f"+{x}+{y}")
    app = DockerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
