#!/usr/bin/env python3
"""
Lin64x Kali Linux App
Helper and reference for Kali Linux tools and penetration testing workflows.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox
import platform
import subprocess
import sys
import shutil
from pathlib import Path

class KaliApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Kali Linux")
        self.root.geometry("920x640")
        self.root.configure(bg="#0d0d0d")

        self.is_linux = platform.system() == "Linux"
        self.project_root = Path(__file__).parent.parent

        self.create_ui()
        self.show_overview()

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#1a1a1a", height=55)
        header.pack(fill="x")
        tk.Label(header, text="Kali Linux", font=("Segoe UI", 16, "bold"),
                 fg="#00ff00", bg="#1a1a1a").pack(side="left", padx=15, pady=12)
        tk.Label(header, text="Lin64x Tools Reference", font=("Segoe UI", 10),
                 fg="#888", bg="#1a1a1a").pack(side="left")

        # Sidebar
        sidebar = tk.Frame(self.root, bg="#111111", width=200)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        sections = [
            ("Overview", self.show_overview),
            ("Information Gathering", self.show_info_gathering),
            ("Vulnerability Analysis", self.show_vuln),
            ("Web Application", self.show_web),
            ("Password Attacks", self.show_password),
            ("Wireless", self.show_wireless),
            ("Exploitation", self.show_exploit),
            ("Forensics", self.show_forensics),
            ("Quick Commands", self.show_commands),
        ]
        for name, cmd in sections:
            btn = tk.Button(sidebar, text=name, font=("Segoe UI", 9),
                            bg="#111111", fg="#00ff00", relief="flat", anchor="w",
                            command=cmd)
            btn.pack(fill="x", padx=4, pady=1)

        # Content
        self.content = tk.Frame(self.root, bg="#0d0d0d")
        self.content.pack(side="right", fill="both", expand=True)

    def clear(self):
        for w in self.content.winfo_children():
            w.destroy()

    def add_title(self, title):
        tk.Label(self.content, text=title, font=("Segoe UI", 16, "bold"),
                 bg="#0d0d0d", fg="#00ff00").pack(pady=10, padx=15, anchor="w")

    def add_text(self, text):
        box = scrolledtext.ScrolledText(self.content, bg="#0d0d0d", fg="#cccccc",
                                         font=("Consolas", 10), relief="flat")
        box.pack(fill="both", expand=True, padx=15, pady=5)
        box.insert("1.0", text)
        box.config(state="disabled")

    def show_overview(self):
        self.clear()
        self.add_title("Kali Linux Overview")
        text = """Kali Linux is a Debian-based distribution focused on penetration testing and security auditing.

This Lin64x app provides a quick reference to common Kali tools and categories.

Popular tools included in Kali:
• nmap          — Network scanner
• metasploit    — Exploitation framework
• burpsuite     — Web proxy
• aircrack-ng   — Wireless auditing
• john          — Password cracker
• wireshark     — Packet analyzer
• sqlmap        — SQL injection tool
• hydra         — Online password attacks

Note: Use these tools only on systems you own or have explicit permission to test.
Unauthorized access is illegal.

On non-Kali systems some tools may need to be installed separately.
"""
        self.add_text(text)

    def show_info_gathering(self):
        self.clear()
        self.add_title("Information Gathering")
        text = """Common information gathering tools:

nmap -sV -sC target.com          # Service/version detection
nmap -A target.com               # Aggressive scan
whois target.com
dig target.com
theharvester -d target.com -b all
recon-ng
maltego

DNS enumeration:
dnsrecon -d target.com
fierce --domain target.com
"""
        self.add_text(text)

    def show_vuln(self):
        self.clear()
        self.add_title("Vulnerability Analysis")
        text = """Vulnerability scanning tools:

nikto -h http://target.com
openvas
nessus (commercial)
lynis (system auditing)
wapiti -u http://target.com

Web vulnerability:
wpscan --url http://target.com
joomscan
"""
        self.add_text(text)

    def show_web(self):
        self.clear()
        self.add_title("Web Application")
        text = """Web application testing:

burpsuite
sqlmap -u "http://target.com/page?id=1" --dbs
dirb http://target.com
gobuster dir -u http://target.com -w /usr/share/wordlists/dirb/common.txt
wfuzz
nikto -h target.com

Always obtain permission before testing.
"""
        self.add_text(text)

    def show_password(self):
        self.clear()
        self.add_title("Password Attacks")
        text = """Password attack tools:

john --wordlist=rockyou.txt hash.txt
hashcat -m 0 hash.txt rockyou.txt
hydra -l admin -P rockyou.txt ssh://target.com
medusa
crunch (wordlist generator)

Use only on systems you are authorized to test.
"""
        self.add_text(text)

    def show_wireless(self):
        self.clear()
        self.add_title("Wireless Attacks")
        text = """Wireless auditing (requires compatible hardware):

airmon-ng start wlan0
airodump-ng wlan0mon
aireplay-ng
aircrack-ng capture.cap
wifite
reaver
bully

Only test networks you own.
"""
        self.add_text(text)

    def show_exploit(self):
        self.clear()
        self.add_title("Exploitation")
        text = """Exploitation frameworks and tools:

msfconsole
searchsploit apache
metasploit
exploitdb
beef-xss
set (Social Engineering Toolkit)

Always follow responsible disclosure and legal guidelines.
"""
        self.add_text(text)

    def show_forensics(self):
        self.clear()
        self.add_title("Forensics")
        text = """Digital forensics tools:

autopsy
volatility
binwalk
foremost
sleuthkit
wireshark
tcpdump

Use for authorized investigations only.
"""
        self.add_text(text)

    def show_commands(self):
        self.clear()
        self.add_title("Quick Commands")
        text = """Useful one-liners (Kali / Debian-based):

# Update Kali
sudo apt update && sudo apt full-upgrade -y

# Search for a tool
apt search nmap

# Install a tool
sudo apt install nmap

# Check if running as root
whoami

# List listening ports
ss -tuln

# Start Metasploit
msfconsole

Use Lin64x Sudo Commands or Linux4_(Cmd) to run elevated commands.
"""
        self.add_text(text)
        btn = tk.Button(self.content, text="Open Sudo Commands", command=self.open_sudo,
                        bg="#00aa00", fg="black", relief="flat")
        btn.pack(pady=5)

    def open_sudo(self):
        path = self.project_root / "sudo" / "sudo_commands.py"
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 460
    y = (root.winfo_screenheight() // 2) - 320
    root.geometry(f"+{x}+{y}")
    app = KaliApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
