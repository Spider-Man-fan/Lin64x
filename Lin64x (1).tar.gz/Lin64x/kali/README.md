# Lin64x Kali Linux App

Reference and helper for Kali Linux tools and categories.

## Categories
- Information Gathering
- Vulnerability Analysis
- Web Application
- Password Attacks
- Wireless
- Exploitation
- Forensics
- Quick Commands

**Important:** Use penetration testing tools only on systems you own or have explicit written permission to test. Unauthorized access is illegal.

## Run
```bash
python kali/lin64x_kali.py
```
