# win64store

Lin64x Download Store.

## Features
- Catalog of all Lin64x apps
- Filter by category
- Launch apps directly
- View app info and status
- Store-style header

## Run
```bash
python win64store/win64store.py
```
