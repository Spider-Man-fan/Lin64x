#!/usr/bin/env python3
"""
win64store - Lin64x Download Store
Catalog of Lin64x apps with launch / info actions.
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import subprocess
import sys
from pathlib import Path

class Win64Store:
    def __init__(self, root):
        self.root = root
        self.root.title("win64store")
        self.root.geometry("860x620")
        self.root.configure(bg="#1e1e1e")

        self.project_root = Path(__file__).parent.parent
        self.apps = self.build_catalog()

        self.create_ui()
        self.refresh_list()

    def build_catalog(self):
        return [
            {"name": "Software Maker", "desc": "Write & test Python, C++, Java, Tkinter", "path": "software_maker/lin64x_software_maker.py", "category": "Development"},
            {"name": "web", "desc": "Firefox-style browser", "path": "web/web.py", "category": "Internet"},
            {"name": "ai chaticon", "desc": "AI chat helper", "path": "ai_chaticon/ai_chaticon.py", "category": "Tools"},
            {"name": "configlin", "desc": "Lin64x configuration", "path": "config/configlin.py", "category": "System"},
            {"name": "Layout Performance", "desc": "App layout & performance", "path": "layout/layout_performance.py", "category": "System"},
            {"name": "Settings(Linux-windows)", "desc": "System settings & Lin64xwin64P", "path": "settings/settings_linux_windows.py", "category": "System"},
            {"name": "Security", "desc": "Linux-style security monitor", "path": "security/lin64x_security.py", "category": "Security"},
            {"name": "Sudo Commands", "desc": "Elevated command runner", "path": "sudo/sudo_commands.py", "category": "System"},
            {"name": "Linux4_(Cmd)", "desc": "Hybrid command prompt", "path": "cmd/linux4_cmd.py", "category": "Tools"},
            {"name": "win64x(PowerShell)", "desc": "PowerShell console", "path": "powershell/win64x_powershell.py", "category": "Tools"},
            {"name": "Troubleshooting", "desc": "Linux problem fixer", "path": "troubleshooting/lin64x_troubleshooting.py", "category": "System"},
            {"name": "VMware", "desc": "Virtual machine helper", "path": "vmware/lin64x_vmware.py", "category": "Tools"},
            {"name": "Kali Linux", "desc": "Security tools reference", "path": "kali/lin64x_kali.py", "category": "Security"},
            {"name": "Win32x64(notepad)", "desc": "Simple notepad", "path": "notepad/win32x64_notepad.py", "category": "Tools"},
            {"name": "Code Editor", "desc": "Lightweight code editor", "path": "editor/lin64x_editor.py", "category": "Development"},
            {"name": "SD Save Card", "desc": "Digital save manager", "path": "sd_card/digital_save.py", "category": "Tools"},
            {"name": "OOBE Wizard", "desc": "Windows 11-style setup", "path": "oobe/oobe_wizard.py", "category": "System"},
            {"name": "Desktop Shell", "desc": "Main desktop with taskbar", "path": "os_apps/desktop.py", "category": "System"},
        ]

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#0078d4", height=56)
        header.pack(fill="x")
        tk.Label(header, text="win64store", font=("Segoe UI", 18, "bold"),
                 fg="white", bg="#0078d4").pack(side="left", padx=16, pady=12)
        tk.Label(header, text="Lin64x Download Store", font=("Segoe UI", 10),
                 fg="#e0e0e0", bg="#0078d4").pack(side="left")

        # Search / filter
        filter_frame = tk.Frame(self.root, bg="#1e1e1e")
        filter_frame.pack(fill="x", padx=10, pady=6)
        tk.Label(filter_frame, text="Category:", bg="#1e1e1e", fg="#cccccc").pack(side="left")
        self.cat_var = tk.StringVar(value="All")
        cats = ["All"] + sorted(set(a["category"] for a in self.apps))
        ttk.Combobox(filter_frame, textvariable=self.cat_var, values=cats, state="readonly", width=16).pack(side="left", padx=6)
        tk.Button(filter_frame, text="Filter", command=self.refresh_list, bg="#3c3c3c", fg="white",
                  relief="flat").pack(side="left", padx=4)

        # List
        list_frame = tk.Frame(self.root, bg="#1e1e1e")
        list_frame.pack(fill="both", expand=True, padx=10, pady=4)

        self.tree = ttk.Treeview(list_frame, columns=("category", "desc"), show="tree headings", height=16)
        self.tree.heading("#0", text="App")
        self.tree.heading("category", text="Category")
        self.tree.heading("desc", text="Description")
        self.tree.column("#0", width=200)
        self.tree.column("category", width=100)
        self.tree.column("desc", width=400)
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")

        # Details + actions
        bottom = tk.Frame(self.root, bg="#252526", height=100)
        bottom.pack(fill="x", side="bottom")
        bottom.pack_propagate(False)

        self.detail = tk.Label(bottom, text="Select an app", bg="#252526", fg="#cccccc",
                               font=("Segoe UI", 10), anchor="w", justify="left")
        self.detail.pack(fill="x", padx=12, pady=6)

        btn_frame = tk.Frame(bottom, bg="#252526")
        btn_frame.pack(fill="x", padx=12)
        tk.Button(btn_frame, text="Launch", command=self.launch_selected, bg="#107c10", fg="white",
                  relief="flat", padx=16).pack(side="left", padx=4)
        tk.Button(btn_frame, text="Info", command=self.show_info, bg="#0078d4", fg="white",
                  relief="flat", padx=12).pack(side="left", padx=4)

        self.status = tk.Label(self.root, text="Ready", bg="#0078d4", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def refresh_list(self):
        self.tree.delete(*self.tree.get_children())
        cat = self.cat_var.get()
        for app in self.apps:
            if cat == "All" or app["category"] == cat:
                self.tree.insert("", "end", text=app["name"],
                                 values=(app["category"], app["desc"]),
                                 tags=(app["path"],))
        self.status.config(text=f"{len(self.tree.get_children())} apps shown")

    def on_select(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        item = self.tree.item(sel[0])
        name = item["text"]
        desc = item["values"][1]
        path = item["tags"][0]
        full = self.project_root / path
        exists = "Installed" if full.exists() else "Missing"
        self.detail.config(text=f"{name}\n{desc}\nStatus: {exists}")

    def launch_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("win64store", "Select an app first.")
            return
        path = self.tree.item(sel[0])["tags"][0]
        full = self.project_root / path
        if not full.exists():
            messagebox.showwarning("Missing", f"App not found:\n{full}")
            return
        try:
            subprocess.Popen([sys.executable, str(full)])
            self.status.config(text=f"Launched {self.tree.item(sel[0])['text']}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def show_info(self):
        sel = self.tree.selection()
        if not sel:
            return
        item = self.tree.item(sel[0])
        path = item["tags"][0]
        full = self.project_root / path
        msg = f"Name: {item['text']}\nCategory: {item['values'][0]}\nDescription: {item['values'][1]}\nPath: {full}\nExists: {full.exists()}"
        messagebox.showinfo("App Info", msg)

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 430
    y = (root.winfo_screenheight() // 2) - 310
    root.geometry(f"+{x}+{y}")
    app = Win64Store(root)
    root.mainloop()

if __name__ == "__main__":
    main()
