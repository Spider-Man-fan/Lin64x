#!/usr/bin/env python3
"""
Lin64x Toolbox
Remove unknown or unwanted files.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox, filedialog, ttk
import os
import shutil
from pathlib import Path

class Toolbox:
    def __init__(self, root):
        self.root = root
        self.root.title("Toolbox — Remove Unknown Files")
        self.root.geometry("860x600")
        self.root.configure(bg="#1e1e1e")

        self.scan_path = Path.home()
        self.unknown = []

        self.create_ui()

    def create_ui(self):
        header = tk.Frame(self.root, bg="#5c2d91", height=50)
        header.pack(fill="x")
        tk.Label(header, text="Toolbox", font=("Segoe UI", 16, "bold"),
                 fg="white", bg="#5c2d91").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="Remove Unknown Files", font=("Segoe UI", 10),
                 fg="#e0d0f0", bg="#5c2d91").pack(side="left")

        toolbar = tk.Frame(self.root, bg="#1e1e1e")
        toolbar.pack(fill="x", padx=8, pady=6)
        tk.Button(toolbar, text="Choose Folder", command=self.choose_folder, bg="#3c3c3c", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Scan", command=self.scan, bg="#0078d4", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Remove Selected", command=self.remove_selected, bg="#c42b1c", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="Remove All Listed", command=self.remove_all, bg="#8b0000", fg="white",
                  relief="flat").pack(side="left", padx=4)

        self.path_label = tk.Label(self.root, text=f"Folder: {self.scan_path}", bg="#252526",
                                    fg="#cccccc", anchor="w")
        self.path_label.pack(fill="x")

        # Progress bar
        self.progress = ttk.Progressbar(self.root, mode="determinate", length=400)
        self.progress.pack(fill="x", padx=8, pady=4)

        # List
        list_frame = tk.Frame(self.root, bg="#1e1e1e")
        list_frame.pack(fill="both", expand=True, padx=8, pady=4)

        self.tree = ttk.Treeview(list_frame, columns=("size", "type"), show="tree headings")
        self.tree.heading("#0", text="File")
        self.tree.heading("size", text="Size")
        self.tree.heading("type", text="Type")
        self.tree.column("#0", width=400)
        self.tree.pack(side="left", fill="both", expand=True)

        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")

        self.log = scrolledtext.ScrolledText(self.root, height=6, bg="#252526", fg="#d4d4d4",
                                              font=("Consolas", 9), relief="flat")
        self.log.pack(fill="x", padx=8, pady=4)
        self.log.tag_config("ok", foreground="#4ec9b0")
        self.log.tag_config("err", foreground="#f44747")

        self.status = tk.Label(self.root, text="Ready", bg="#5c2d91", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def choose_folder(self):
        path = filedialog.askdirectory(title="Select folder to scan", initialdir=str(self.scan_path))
        if path:
            self.scan_path = Path(path)
            self.path_label.config(text=f"Folder: {self.scan_path}")

    def is_unknown(self, path):
        """Flag files that look unknown or temporary."""
        name = path.name.lower()
        ext = path.suffix.lower()
        unknown_exts = {".tmp", ".temp", ".bak", ".old", ".log", ".cache", ".crdownload", ".part"}
        unknown_names = {"thumbs.db", "desktop.ini", ".ds_store"}
        if ext in unknown_exts or name in unknown_names:
            return True
        if name.startswith("~") or name.endswith("~"):
            return True
        if name.startswith(".") and ext in {".swp", ".swo"}:
            return True
        return False

    def scan(self):
        self.tree.delete(*self.tree.get_children())
        self.unknown.clear()
        self.progress["value"] = 0
        self.log.insert("end", f"Scanning {self.scan_path}...\n")
        # Count files first for progress
        try:
            all_files = [p for p in self.scan_path.rglob("*") if p.is_file()]
        except Exception as e:
            self.log.insert("end", f"Error: {e}\n", "err")
            return
        total = len(all_files) or 1
        count = 0
        for i, p in enumerate(all_files):
            if self.is_unknown(p):
                try:
                    size = p.stat().st_size
                    self.tree.insert("", "end", text=str(p.relative_to(self.scan_path)),
                                     values=(f"{size:,} B", p.suffix or "file"),
                                     tags=(str(p),))
                    self.unknown.append(p)
                    count += 1
                except Exception:
                    pass
            if i % 20 == 0 or i == total - 1:
                self.progress["value"] = (i + 1) / total * 100
                self.root.update_idletasks()
        self.log.insert("end", f"Found {count} unknown/temp files.\n", "ok")
        self.status.config(text=f"{count} files found")
        self.progress["value"] = 100

    def remove_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Toolbox", "Select files to remove.")
            return
        if not messagebox.askyesno("Confirm", f"Remove {len(sel)} selected file(s)?"):
            return
        removed = 0
        for item in sel:
            path = Path(self.tree.item(item)["tags"][0])
            try:
                path.unlink()
                self.tree.delete(item)
                removed += 1
            except Exception as e:
                self.log.insert("end", f"Failed: {path.name} — {e}\n", "err")
        self.log.insert("end", f"Removed {removed} file(s).\n", "ok")
        self.status.config(text=f"Removed {removed}")

    def remove_all(self):
        if not self.unknown:
            messagebox.showinfo("Toolbox", "Nothing to remove. Scan first.")
            return
        if not messagebox.askyesno("Confirm", f"Remove all {len(self.unknown)} listed files?"):
            return
        removed = 0
        for p in list(self.unknown):
            try:
                p.unlink()
                removed += 1
            except Exception:
                pass
        self.unknown.clear()
        self.tree.delete(*self.tree.get_children())
        self.log.insert("end", f"Removed {removed} file(s).\n", "ok")
        self.status.config(text=f"Removed {removed}")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 430
    y = (root.winfo_screenheight() // 2) - 300
    root.geometry(f"+{x}+{y}")
    app = Toolbox(root)
    root.mainloop()

if __name__ == "__main__":
    main()
