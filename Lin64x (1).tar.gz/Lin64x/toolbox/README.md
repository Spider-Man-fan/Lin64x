# Toolbox

Remove unknown or temporary files.

## Features
- Choose folder to scan
- Scan for unknown/temp files (`.tmp`, `.bak`, `.log`, `Thumbs.db`, etc.)
- Remove selected files
- Remove all listed files

## Run
```bash
python toolbox/toolbox.py
```
