# Lin64x Kernel Component

This directory contains educational stubs for a minimal kernel.

## Building (requires cross-compiler)

```bash
# Install cross-compiler (example on Ubuntu)
sudo apt install gcc-x86-64-linux-gnu

# Or use a proper toolchain like x86_64-elf-gcc

# Compile
x86_64-linux-gnu-gcc -ffreestanding -c minimal_kernel.c -o kernel.o

# Link (example)
x86_64-linux-gnu-ld -T linker.ld -o kernel.bin kernel.o
```

## Notes
- For real dual-boot, integrate with mainline Linux kernel.
- Test in QEMU: `qemu-system-x86_64 -kernel kernel.bin`
- Full hybrid OS development is complex; this is a starting point.

See bootloader/ for related configs.
