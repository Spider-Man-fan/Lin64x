// Lin64x Minimal Kernel Stub
// Educational freestanding C example for hybrid OS experiments.
// Compile with: x86_64-elf-gcc -ffreestanding -c minimal_kernel.c -o kernel.o
// This is NOT a bootable production kernel. Use with QEMU for testing.

#include <stdint.h>

// VGA text mode buffer (for simple output)
#define VGA_MEMORY 0xB8000
#define VGA_WIDTH 80
#define VGA_HEIGHT 25

static uint16_t* vga_buffer = (uint16_t*)VGA_MEMORY;
static int cursor_x = 0;
static int cursor_y = 0;

void clear_screen() {
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        vga_buffer[i] = (uint16_t)(' ' | (0x07 << 8));
    }
    cursor_x = 0;
    cursor_y = 0;
}

void put_char(char c) {
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
        return;
    }
    if (cursor_x >= VGA_WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }
    if (cursor_y >= VGA_HEIGHT) {
        // Simple scroll would go here
        cursor_y = VGA_HEIGHT - 1;
    }
    vga_buffer[cursor_y * VGA_WIDTH + cursor_x] = (uint16_t)(c | (0x0F << 8));
    cursor_x++;
}

void print_string(const char* str) {
    while (*str) {
        put_char(*str++);
    }
}

// Kernel entry point (called by bootloader)
void kernel_main(void) {
    clear_screen();
    print_string("Lin64x Kernel Stub Loaded!\n");
    print_string("Hybrid Linux/Windows Foundation\n");
    print_string("Educational use only.\n");
    
    // Halt
    while (1) {
        asm volatile ("hlt");
    }
}
