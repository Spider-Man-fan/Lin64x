# Additional Documentation

## Architecture Overview

Lin64x is structured as a suite of interoperable tools rather than a single monolithic OS:

1. **Installer** - Sets up the environment on host OS.
2. **OOBE** - Provides a familiar Windows 11-like first-run experience.
3. **Code Editor** - Primary development tool, optimized for Linux workflows but cross-platform.
4. **SD Digital Save** - Persistence layer for configs, saves, and hybrid data.
5. **Kernel / Bootloader** - Low-level foundations for advanced users building custom dual-boot or hybrid systems.

## Extending the Project

- Replace Tkinter with PyQt or Electron for richer UI.
- Add real Windows integration via WSL or Wine helpers.
- Implement actual SD card imaging with `dd` or Python libraries.
- Contribute real kernel modules or bootloader patches.

## GitHub Setup

1. Create a new repository on GitHub named `Lin64x`.
2. Upload these files (or `git init` and push).
3. Add topics: `linux`, `windows`, `dual-boot`, `hybrid`, `python`, `osdev`.
4. Enable Issues and Discussions for community contributions.
