#!/usr/bin/env python3
"""
Lin64x Windows 11-style OOBE Wizard (Upgraded)
Enhanced multi-step setup with more options, progress, and hybrid configuration.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import platform
import json
from pathlib import Path
from datetime import datetime

class OOBEWizard:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Setup")
        self.root.geometry("900x650")
        self.root.configure(bg="#0c0c0c")
        self.root.resizable(False, False)

        self.step = 0
        self.steps = [
            self.step_welcome,
            self.step_language,
            self.step_region,
            self.step_keyboard,
            self.step_privacy,
            self.step_network,
            self.step_hybrid,
            self.step_account,
            self.step_finish
        ]
        self.data = {
            "started": datetime.now().isoformat(),
            "os": platform.system()
        }

        # Progress bar area
        self.progress_frame = tk.Frame(root, bg="#0c0c0c", height=30)
        self.progress_frame.pack(fill="x", side="top")
        self.progress = ttk.Progressbar(self.progress_frame, length=800, mode="determinate")
        self.progress.pack(pady=8)

        self.container = tk.Frame(root, bg="#0c0c0c")
        self.container.pack(fill="both", expand=True, padx=50, pady=20)

        # Navigation
        self.nav_frame = tk.Frame(root, bg="#0c0c0c")
        self.nav_frame.pack(fill="x", side="bottom", pady=10)
        self.back_btn = tk.Button(self.nav_frame, text="Back", command=self.prev_step,
                                  bg="#3c3c3c", fg="white", relief="flat", state="disabled", padx=20)
        self.back_btn.pack(side="left", padx=40)
        self.next_btn = tk.Button(self.nav_frame, text="Next", command=self.next_step,
                                  bg="#0078d4", fg="white", relief="flat", padx=25)
        self.next_btn.pack(side="right", padx=40)

        self.show_step()

    def clear_container(self):
        for w in self.container.winfo_children():
            w.destroy()

    def update_progress(self):
        pct = int((self.step / (len(self.steps) - 1)) * 100)
        self.progress["value"] = pct
        self.back_btn.config(state="normal" if self.step > 0 else "disabled")
        if self.step == len(self.steps) - 1:
            self.next_btn.config(text="Finish")
        else:
            self.next_btn.config(text="Next")

    def show_step(self):
        self.clear_container()
        self.update_progress()
        if 0 <= self.step < len(self.steps):
            self.steps[self.step]()

    def next_step(self):
        self.collect_data()
        if self.step < len(self.steps) - 1:
            self.step += 1
            self.show_step()
        else:
            self.finish()

    def prev_step(self):
        if self.step > 0:
            self.step -= 1
            self.show_step()

    def collect_data(self):
        # Collect current step data if variables exist
        for attr in dir(self):
            if attr.endswith("_var"):
                try:
                    self.data[attr[:-4]] = getattr(self, attr).get()
                except Exception:
                    pass

    def step_welcome(self):
        tk.Label(self.container, text="Welcome to Lin64x", font=("Segoe UI", 32, "bold"),
                 fg="white", bg="#0c0c0c").pack(pady=30)
        tk.Label(self.container, text="Let's set up your hybrid Linux + Windows experience",
                 font=("Segoe UI", 14), fg="#a0a0a0", bg="#0c0c0c").pack(pady=10)
        tk.Label(self.container, text=f"Detected: {platform.system()} {platform.release()}",
                 font=("Segoe UI", 11), fg="#666", bg="#0c0c0c").pack(pady=20)

    def step_language(self):
        tk.Label(self.container, text="Choose your language", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#0c0c0c").pack(pady=20)
        languages = ["English (United States)", "English (United Kingdom)", "Español", "Français", "Deutsch", "中文 (简体)", "日本語"]
        self.language_var = tk.StringVar(value=languages[0])
        for lang in languages:
            ttk.Radiobutton(self.container, text=lang, variable=self.language_var, value=lang).pack(anchor="w", padx=40, pady=3)

    def step_region(self):
        tk.Label(self.container, text="Select your region", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#0c0c0c").pack(pady=20)
        regions = ["United States", "United Kingdom", "Canada", "Germany", "France", "Japan", "Australia", "Other"]
        self.region_var = tk.StringVar(value=regions[0])
        combo = ttk.Combobox(self.container, textvariable=self.region_var, values=regions, width=40, state="readonly")
        combo.pack(pady=20)

    def step_keyboard(self):
        tk.Label(self.container, text="Keyboard layout", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#0c0c0c").pack(pady=20)
        layouts = ["US", "UK", "German", "French", "Spanish", "Japanese"]
        self.keyboard_var = tk.StringVar(value="US")
        for layout in layouts:
            ttk.Radiobutton(self.container, text=layout, variable=self.keyboard_var, value=layout).pack(anchor="w", padx=40, pady=3)

    def step_privacy(self):
        tk.Label(self.container, text="Privacy settings", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#0c0c0c").pack(pady=20)
        self.diag_var = tk.BooleanVar(value=True)
        self.location_var = tk.BooleanVar(value=False)
        self.ads_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(self.container, text="Send optional diagnostic data", variable=self.diag_var).pack(anchor="w", padx=40, pady=5)
        ttk.Checkbutton(self.container, text="Allow location access for hybrid features", variable=self.location_var).pack(anchor="w", padx=40, pady=5)
        ttk.Checkbutton(self.container, text="Personalized recommendations", variable=self.ads_var).pack(anchor="w", padx=40, pady=5)

    def step_network(self):
        tk.Label(self.container, text="Network", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#0c0c0c").pack(pady=20)
        tk.Label(self.container, text="Connect to a network (optional for this setup)",
                 fg="#aaa", bg="#0c0c0c").pack(pady=10)
        self.network_var = tk.StringVar(value="Skip for now")
        ttk.Radiobutton(self.container, text="Skip for now", variable=self.network_var, value="Skip for now").pack(anchor="w", padx=40, pady=5)
        ttk.Radiobutton(self.container, text="I am connected", variable=self.network_var, value="Connected").pack(anchor="w", padx=40, pady=5)

    def step_hybrid(self):
        tk.Label(self.container, text="Hybrid Configuration", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#0c0c0c").pack(pady=20)
        tk.Label(self.container, text="Lin64x will configure shared tools and dual-boot helpers.",
                 fg="#aaa", bg="#0c0c0c", wraplength=600).pack(pady=10)
        self.dualboot_var = tk.BooleanVar(value=True)
        self.shared_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self.container, text="Enable dual-boot helpers", variable=self.dualboot_var).pack(anchor="w", padx=40, pady=5)
        ttk.Checkbutton(self.container, text="Share data between Linux and Windows", variable=self.shared_var).pack(anchor="w", padx=40, pady=5)

    def step_account(self):
        tk.Label(self.container, text="Create a local account", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#0c0c0c").pack(pady=20)
        tk.Label(self.container, text="Username", fg="#ccc", bg="#0c0c0c").pack(anchor="w", padx=40)
        self.username_var = tk.StringVar(value="lin64x")
        ttk.Entry(self.container, textvariable=self.username_var, width=40).pack(pady=5, padx=40, anchor="w")
        tk.Label(self.container, text="(Demo only — not a real system account)", fg="#666", bg="#0c0c0c").pack(anchor="w", padx=40)

    def step_finish(self):
        tk.Label(self.container, text="You're all set!", font=("Segoe UI", 32, "bold"),
                 fg="white", bg="#0c0c0c").pack(pady=40)
        tk.Label(self.container, text="Lin64x hybrid tools are ready to use.",
                 font=("Segoe UI", 14), fg="#aaa", bg="#0c0c0c").pack(pady=10)
        tk.Label(self.container, text="Launch the Desktop shell or individual apps next.",
                 fg="#888", bg="#0c0c0c").pack(pady=5)

    def finish(self):
        self.collect_data()
        self.data["completed"] = datetime.now().isoformat()
        # Save setup profile
        profile = Path.home() / ".lin64x_setup.json"
        try:
            with open(profile, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
            print(f"Setup profile saved to {profile}")
        except Exception as e:
            print(f"Could not save profile: {e}")
        messagebox.showinfo("Setup Complete", "Lin64x setup finished.\nYou can now use the hybrid tools.")
        self.root.quit()

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 325
    root.geometry(f"+{x}+{y}")
    app = OOBEWizard(root)
    root.mainloop()

if __name__ == "__main__":
    main()
