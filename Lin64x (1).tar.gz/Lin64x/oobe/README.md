# OOBE Wizard (Upgraded)

Enhanced Windows 11-style Out-of-Box Experience.

## New Features
- Progress bar
- Back / Next navigation
- More steps: keyboard, network, account
- Privacy options
- Hybrid configuration
- Saves setup profile to `~/.lin64x_setup.json`

## Run
```bash
python oobe/oobe_wizard.py
```
