#!/usr/bin/env python3
"""
Lin64xfile - Lin64x File Explorer
Browse, open, and manage files and folders.
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import os
import shutil
import subprocess
import platform
from pathlib import Path

class Lin64xFile:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64xfile")
        self.root.geometry("900x600")
        self.root.configure(bg="#1e1e1e")

        self.current_path = Path.home()
        self.create_ui()
        self.refresh()

    def create_ui(self):
        # Toolbar
        toolbar = tk.Frame(self.root, bg="#252526", height=42)
        toolbar.pack(fill="x")
        toolbar.pack_propagate(False)

        tk.Button(toolbar, text="↑", command=self.go_up, bg="#3c3c3c", fg="white",
                  relief="flat", width=3).pack(side="left", padx=2, pady=6)
        tk.Button(toolbar, text="Home", command=self.go_home, bg="#3c3c3c", fg="white",
                  relief="flat").pack(side="left", padx=2)
        tk.Button(toolbar, text="Refresh", command=self.refresh, bg="#3c3c3c", fg="white",
                  relief="flat").pack(side="left", padx=2)

        self.path_var = tk.StringVar()
        path_entry = tk.Entry(toolbar, textvariable=self.path_var, bg="#3c3c3c", fg="white",
                              insertbackground="white", relief="flat", font=("Segoe UI", 10))
        path_entry.pack(side="left", fill="x", expand=True, padx=6, ipady=3)
        path_entry.bind("<Return>", lambda e: self.go_to_path())

        tk.Button(toolbar, text="Go", command=self.go_to_path, bg="#0078d4", fg="white",
                  relief="flat").pack(side="left", padx=4)

        # File list
        list_frame = tk.Frame(self.root, bg="#1e1e1e")
        list_frame.pack(fill="both", expand=True, padx=6, pady=4)

        self.tree = ttk.Treeview(list_frame, columns=("size", "type", "modified"), show="tree headings")
        self.tree.heading("#0", text="Name")
        self.tree.heading("size", text="Size")
        self.tree.heading("type", text="Type")
        self.tree.heading("modified", text="Modified")
        self.tree.column("#0", width=320)
        self.tree.column("size", width=100)
        self.tree.column("type", width=80)
        self.tree.column("modified", width=160)
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<Double-1>", self.on_double_click)

        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")

        # Bottom actions
        actions = tk.Frame(self.root, bg="#252526")
        actions.pack(fill="x", side="bottom")
        tk.Button(actions, text="New Folder", command=self.new_folder, bg="#3c3c3c", fg="white",
                  relief="flat").pack(side="left", padx=4, pady=4)
        tk.Button(actions, text="Delete", command=self.delete_selected, bg="#c42b1c", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(actions, text="Open", command=self.open_selected, bg="#107c10", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(actions, text="Copy Path", command=self.copy_path, bg="#3c3c3c", fg="white",
                  relief="flat").pack(side="left", padx=4)

        self.status = tk.Label(self.root, text="Ready", bg="#0078d4", fg="white", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        self.path_var.set(str(self.current_path))
        try:
            entries = sorted(self.current_path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            for entry in entries:
                try:
                    if entry.is_dir():
                        size = ""
                        typ = "Folder"
                    else:
                        size = f"{entry.stat().st_size:,} B"
                        typ = "File"
                    mtime = entry.stat().st_mtime
                    from datetime import datetime
                    modified = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")
                    self.tree.insert("", "end", text=entry.name, values=(size, typ, modified),
                                     tags=("dir" if entry.is_dir() else "file",))
                except Exception:
                    continue
            self.status.config(text=f"{len(entries)} items | {self.current_path}")
        except PermissionError:
            self.status.config(text="Permission denied")
            messagebox.showwarning("Access", "Permission denied for this folder.")
        except Exception as e:
            self.status.config(text=str(e))

    def go_up(self):
        if self.current_path.parent != self.current_path:
            self.current_path = self.current_path.parent
            self.refresh()

    def go_home(self):
        self.current_path = Path.home()
        self.refresh()

    def go_to_path(self):
        path = Path(self.path_var.get())
        if path.exists() and path.is_dir():
            self.current_path = path
            self.refresh()
        else:
            messagebox.showwarning("Invalid", "Path does not exist or is not a folder.")

    def on_double_click(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        name = self.tree.item(sel[0])["text"]
        path = self.current_path / name
        if path.is_dir():
            self.current_path = path
            self.refresh()
        else:
            self.open_file(path)

    def open_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        name = self.tree.item(sel[0])["text"]
        path = self.current_path / name
        if path.is_dir():
            self.current_path = path
            self.refresh()
        else:
            self.open_file(path)

    def open_file(self, path):
        try:
            if platform.system() == "Windows":
                os.startfile(path)
            elif platform.system() == "Darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as e:
            messagebox.showerror("Open", str(e))

    def new_folder(self):
        name = simpledialog.askstring("New Folder", "Folder name:")
        if name:
            try:
                (self.current_path / name).mkdir()
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        name = self.tree.item(sel[0])["text"]
        path = self.current_path / name
        if not messagebox.askyesno("Delete", f"Delete '{name}'?"):
            return
        try:
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
            self.refresh()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def copy_path(self):
        sel = self.tree.selection()
        if sel:
            name = self.tree.item(sel[0])["text"]
            path = str(self.current_path / name)
        else:
            path = str(self.current_path)
        self.root.clipboard_clear()
        self.root.clipboard_append(path)
        self.status.config(text=f"Copied: {path}")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 300
    root.geometry(f"+{x}+{y}")
    app = Lin64xFile(root)
    root.mainloop()

if __name__ == "__main__":
    main()
