# Lin64xfile

Lin64x File Explorer.

## Features
- Browse folders
- Up / Home / Go to path
- Double-click to open folders or files
- New folder
- Delete (with confirmation)
- Copy path
- Shows size, type, and modified date

## Run
```bash
python lin64xfile/lin64xfile.py
```
