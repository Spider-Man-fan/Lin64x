# Lin64x Icon

Bird icon for the Lin64x hybrid suite.

## Usage
- `icon.svg` — Scalable vector icon
- Use in desktop entries, about screens, or as the project logo

The icon is a simple stylized bird representing the hybrid / free nature of the project.
