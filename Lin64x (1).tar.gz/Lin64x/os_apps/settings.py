#!/usr/bin/env python3
"""
Lin64x Settings App (Windows 11 style)
System settings panel for hybrid environment.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import platform
import os

class SettingsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Settings")
        self.root.geometry("900x600")
        self.root.configure(bg="#f3f3f3")

        # Sidebar
        sidebar = tk.Frame(self.root, bg="#e6e6e6", width=220)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        tk.Label(sidebar, text="Settings", font=("Segoe UI", 16, "bold"),
                 bg="#e6e6e6", fg="#1a1a1a").pack(pady=20, padx=15, anchor="w")

        categories = ["System", "Personalization", "Apps", "Privacy", "About"]
        for cat in categories:
            btn = tk.Button(sidebar, text=cat, font=("Segoe UI", 11),
                            bg="#e6e6e6", fg="#1a1a1a", relief="flat", anchor="w",
                            command=lambda c=cat: self.show_category(c))
            btn.pack(fill="x", padx=10, pady=4)

        # Content area
        self.content = tk.Frame(self.root, bg="#ffffff")
        self.content.pack(side="right", fill="both", expand=True)

        self.show_category("System")

    def clear_content(self):
        for w in self.content.winfo_children():
            w.destroy()

    def show_category(self, name):
        self.clear_content()
        tk.Label(self.content, text=name, font=("Segoe UI", 22, "bold"),
                 bg="#ffffff", fg="#1a1a1a").pack(pady=20, padx=30, anchor="w")

        if name == "System":
            self.system_page()
        elif name == "Personalization":
            self.personalization_page()
        elif name == "Apps":
            self.apps_page()
        elif name == "Privacy":
            self.privacy_page()
        elif name == "About":
            self.about_page()

    def system_page(self):
        info = f"""
Operating System: {platform.system()} {platform.release()}
Architecture: {platform.machine()}
Processor: {platform.processor() or 'Unknown'}
Python: {platform.python_version()}
        """.strip()
        tk.Label(self.content, text=info, font=("Segoe UI", 11),
                 bg="#ffffff", justify="left").pack(padx=30, pady=10, anchor="w")

    def personalization_page(self):
        tk.Label(self.content, text="Theme", font=("Segoe UI", 14, "bold"),
                 bg="#ffffff").pack(padx=30, pady=10, anchor="w")
        theme_var = tk.StringVar(value="Dark")
        for t in ["Dark", "Light", "System"]:
            ttk.Radiobutton(self.content, text=t, variable=theme_var, value=t).pack(anchor="w", padx=40)

    def apps_page(self):
        tk.Label(self.content, text="Installed Lin64x Apps", font=("Segoe UI", 14, "bold"),
                 bg="#ffffff").pack(padx=30, pady=10, anchor="w")
        apps = ["Code Editor", "Security", "File Explorer", "Desktop Shell", "OOBE Wizard", "SD Save Card"]
        for app in apps:
            tk.Label(self.content, text=f"• {app}", font=("Segoe UI", 11),
                     bg="#ffffff").pack(anchor="w", padx=40, pady=2)

    def privacy_page(self):
        tk.Label(self.content, text="Privacy options", font=("Segoe UI", 14, "bold"),
                 bg="#ffffff").pack(padx=30, pady=10, anchor="w")
        ttk.Checkbutton(self.content, text="Send optional diagnostic data").pack(anchor="w", padx=40, pady=5)
        ttk.Checkbutton(self.content, text="Allow location access").pack(anchor="w", padx=40, pady=5)

    def about_page(self):
        about = """Lin64x Hybrid OS Suite
Version 1.0

A Linux + Windows hybrid software collection
with custom apps inspired by Windows 11.
        """
        tk.Label(self.content, text=about, font=("Segoe UI", 11),
                 bg="#ffffff", justify="left").pack(padx=30, pady=20, anchor="w")

def main():
    root = tk.Tk()
    app = SettingsApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
