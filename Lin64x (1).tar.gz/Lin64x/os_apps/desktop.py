#!/usr/bin/env python3
"""
Lin64x Windows 11-style Desktop Shell
Simple hybrid desktop with taskbar, Start menu, and app launcher.
"""

import tkinter as tk
from tkinter import messagebox
import subprocess
import sys
import os
from pathlib import Path

class Win11Desktop:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Desktop")
        self.root.attributes("-fullscreen", True)
        self.root.configure(bg="#0c0c0c")
        
        self.project_root = Path(__file__).parent.parent
        self.start_open = False
        
        self.create_wallpaper_area()
        self.create_taskbar()
        self.create_start_menu()

    def create_wallpaper_area(self):
        self.desktop = tk.Frame(self.root, bg="#0c0c0c")
        self.desktop.pack(fill="both", expand=True)
        
        # Centered welcome
        tk.Label(self.desktop, text="Lin64x", font=("Segoe UI", 48, "bold"),
                 fg="#ffffff", bg="#0c0c0c").place(relx=0.5, rely=0.4, anchor="center")
        tk.Label(self.desktop, text="Hybrid Linux + Windows Experience", font=("Segoe UI", 16),
                 fg="#a0a0a0", bg="#0c0c0c").place(relx=0.5, rely=0.48, anchor="center")

    def create_taskbar(self):
        self.taskbar = tk.Frame(self.root, bg="#1f1f1f", height=48)
        self.taskbar.pack(side="bottom", fill="x")
        self.taskbar.pack_propagate(False)

        # Start button
        self.start_btn = tk.Button(self.taskbar, text="⊞", font=("Segoe UI", 16),
                                   bg="#1f1f1f", fg="white", relief="flat",
                                   command=self.toggle_start, width=3)
        self.start_btn.pack(side="left", padx=4, pady=4)

        # Quick launch buttons
        apps = [
            ("Editor", "editor/lin64x_editor.py"),
            ("Software Maker", "software_maker/lin64x_software_maker.py"),
            ("ai chaticon", "ai_chaticon/ai_chaticon.py"),
            ("web", "web/web.py"),
            ("Lin64xfile", "lin64xfile/lin64xfile.py"),
            ("lin64xcamera", "lin64xcamera/lin64xcamera.py"),
            ("lin64xcalculator", "lin64xcalculator/lin64xcalculator.py"),
            ("Layout", "layout/layout_performance.py"),
            ("configlin", "config/configlin.py"),
            ("win64store", "win64store/win64store.py"),
            ("terminate64xlin", "terminate/terminate64xlin.py"),
            ("Visual Studio", "visualstudio/visualstudio.py"),
            ("Security", "security/lin64x_security.py"),
            ("Malware Removal", "malware_removal/malware_removal.py"),
            ("App Fixer", "app_fixer/app_fixer.py"),
            ("Toolbox", "toolbox/toolbox.py"),
            ("Installer", "installer/roblox_installer.py"),
            ("Settings", "settings/settings_linux_windows.py"),
            ("Cmd", "cmd/linux4_cmd.py"),
            ("Cmd+Sudo", "cmd_sudo/cmd_sudo.py"),
            ("PowerShell", "powershell/win64x_powershell.py"),
            ("Sudo", "sudo/sudo_commands.py"),
            ("Troubleshoot", "troubleshooting/lin64x_troubleshooting.py"),
            ("VMware", "vmware/lin64x_vmware.py"),
            ("Kali", "kali/lin64x_kali.py"),
            ("Ubuntu", "ubuntu/ubuntu.py"),
            ("Ubuntu Terminal", "ubuntu/terminal/ubuntu_terminal.py"),
            ("Ubuntu Files", "ubuntu/files/ubuntu_files.py"),
            ("Docker", "docker/docker.py"),
            ("Lin(python)", "python/lin_python.py"),
            ("Notepad", "notepad/win32x64_notepad.py"),
        ]
        for name, script in apps:
            btn = tk.Button(self.taskbar, text=name, font=("Segoe UI", 9),
                            bg="#1f1f1f", fg="white", relief="flat",
                            command=lambda s=script: self.launch(s))
            btn.pack(side="left", padx=2, pady=8)

        # Clock / tray
        self.clock = tk.Label(self.taskbar, text="", font=("Segoe UI", 9),
                              bg="#1f1f1f", fg="white")
        self.clock.pack(side="right", padx=12)
        self.update_clock()

        # Account swap button
        try:
            import sys
            sys.path.insert(0, str(self.project_root / "settings"))
            from accounts import get_current_info, swap_account
            self._get_account = get_current_info
            self._swap_account = swap_account
        except Exception:
            self._get_account = lambda: {"display": "User"}
            self._swap_account = lambda: "user"

        self.account_btn = tk.Button(self.taskbar, text="User", font=("Segoe UI", 9),
                                     bg="#1f1f1f", fg="#58a6ff", relief="flat",
                                     command=self.swap_account_desktop)
        self.account_btn.pack(side="right", padx=4)
        self.refresh_account_label()

        # Backup and Restore buttons
        tk.Button(self.taskbar, text="Restore", font=("Segoe UI", 9),
                  bg="#1f1f1f", fg="#ffcc00", relief="flat",
                  command=self.do_restore).pack(side="right", padx=2)
        tk.Button(self.taskbar, text="Backup", font=("Segoe UI", 9),
                  bg="#1f1f1f", fg="#4ec9b0", relief="flat",
                  command=self.do_backup).pack(side="right", padx=2)

    def create_start_menu(self):
        # Home screen that opens when Windows logo is pressed
        self.start_menu = tk.Frame(self.root, bg="#202020", width=520, height=620)
        self.start_menu.place(x=12, y=self.root.winfo_screenheight() - 680)
        self.start_menu.place_forget()

        # Header
        header = tk.Frame(self.start_menu, bg="#202020")
        header.pack(fill="x", pady=(12, 4))
        tk.Label(header, text="Home", font=("Segoe UI", 20, "bold"),
                 fg="white", bg="#202020").pack(side="left", padx=16)
        tk.Label(header, text="Lin64x", font=("Segoe UI", 11),
                 fg="#888", bg="#202020").pack(side="left")

        # Search bar
        search_frame = tk.Frame(self.start_menu, bg="#2d2d2d")
        search_frame.pack(fill="x", padx=16, pady=8)
        self.search_var = tk.StringVar()
        search_entry = tk.Entry(search_frame, textvariable=self.search_var, bg="#2d2d2d",
                                fg="white", insertbackground="white", relief="flat",
                                font=("Segoe UI", 11))
        search_entry.pack(fill="x", padx=8, ipady=6)
        search_entry.insert(0, "Search apps...")
        search_entry.bind("<FocusIn>", lambda e: search_entry.delete(0, "end") if search_entry.get() == "Search apps..." else None)
        search_entry.bind("<KeyRelease>", self.filter_apps)

        # Pinned apps label
        tk.Label(self.start_menu, text="Pinned", font=("Segoe UI", 11, "bold"),
                 fg="#cccccc", bg="#202020").pack(anchor="w", padx=16, pady=(8, 4))

        # Scrollable app area
        canvas_frame = tk.Frame(self.start_menu, bg="#202020")
        canvas_frame.pack(fill="both", expand=True, padx=8)

        self.app_canvas = tk.Canvas(canvas_frame, bg="#202020", highlightthickness=0)
        scrollbar = tk.Scrollbar(canvas_frame, orient="vertical", command=self.app_canvas.yview)
        self.app_inner = tk.Frame(self.app_canvas, bg="#202020")

        self.app_inner.bind("<Configure>", lambda e: self.app_canvas.configure(scrollregion=self.app_canvas.bbox("all")))
        self.app_canvas.create_window((0, 0), window=self.app_inner, anchor="nw")
        self.app_canvas.configure(yscrollcommand=scrollbar.set)

        self.app_canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.all_apps = [
            ("Code Editor", "editor/lin64x_editor.py"),
            ("Software Maker", "software_maker/lin64x_software_maker.py"),
            ("ai chaticon", "ai_chaticon/ai_chaticon.py"),
            ("web", "web/web.py"),
            ("Lin64xfile", "lin64xfile/lin64xfile.py"),
            ("lin64xcamera", "lin64xcamera/lin64xcamera.py"),
            ("lin64xcalculator", "lin64xcalculator/lin64xcalculator.py"),
            ("Layout Performance", "layout/layout_performance.py"),
            ("configlin", "config/configlin.py"),
            ("win64store", "win64store/win64store.py"),
            ("terminate64xlin", "terminate/terminate64xlin.py"),
            ("Visual Studio", "visualstudio/visualstudio.py"),
            ("Security", "security/lin64x_security.py"),
            ("Malware Removal", "malware_removal/malware_removal.py"),
            ("App Fixer", "app_fixer/app_fixer.py"),
            ("Toolbox", "toolbox/toolbox.py"),
            ("Installer", "installer/roblox_installer.py"),
            ("Settings(Linux-windows)", "settings/settings_linux_windows.py"),
            ("Linux4_(Cmd)", "cmd/linux4_cmd.py"),
            ("Windows Cmd + Sudo", "cmd_sudo/cmd_sudo.py"),
            ("win64x(PowerShell)", "powershell/win64x_powershell.py"),
            ("Sudo Commands", "sudo/sudo_commands.py"),
            ("Lin64x(troubleshooting)", "troubleshooting/lin64x_troubleshooting.py"),
            ("VMware", "vmware/lin64x_vmware.py"),
            ("Kali Linux", "kali/lin64x_kali.py"),
            ("Ubuntu", "ubuntu/ubuntu.py"),
            ("Ubuntu Terminal", "ubuntu/terminal/ubuntu_terminal.py"),
            ("Ubuntu Files", "ubuntu/files/ubuntu_files.py"),
            ("Docker", "docker/docker.py"),
            ("Lin(python)", "python/lin_python.py"),
            ("python.lin32", "python/python_lin32.py"),
            ("Win32x64(notepad)", "notepad/win32x64_notepad.py"),
            ("OOBE Wizard", "oobe/oobe_wizard.py"),
            ("SD Save Card", "sd_card/digital_save.py"),
        ]
        self.app_buttons = []
        self.populate_apps(self.all_apps)

        # Bottom bar
        bottom = tk.Frame(self.start_menu, bg="#202020")
        bottom.pack(fill="x", side="bottom", pady=8)
        tk.Button(bottom, text="Restart", font=("Segoe UI", 10),
                  bg="#ff8c00", fg="white", relief="flat",
                  command=self.restart_system).pack(side="left", padx=8)
        tk.Button(bottom, text="Shutdown", font=("Segoe UI", 10),
                  bg="#c42b1c", fg="white", relief="flat",
                  command=self.shutdown_system).pack(side="left", padx=4)
        tk.Button(bottom, text="Exit Desktop", font=("Segoe UI", 10),
                  bg="#3c3c3c", fg="white", relief="flat",
                  command=self.root.destroy).pack(side="right", padx=12)

    def populate_apps(self, apps):
        for btn in self.app_buttons:
            btn.destroy()
        self.app_buttons.clear()
        for name, script in apps:
            btn = tk.Button(self.app_inner, text=name, font=("Segoe UI", 11),
                            bg="#2d2d2d", fg="white", relief="flat", anchor="w",
                            command=lambda s=script: self.launch_and_close(s))
            btn.pack(fill="x", padx=8, pady=2)
            self.app_buttons.append(btn)

    def filter_apps(self, event=None):
        query = self.search_var.get().lower()
        if query in ("", "search apps..."):
            filtered = self.all_apps
        else:
            filtered = [(n, s) for n, s in self.all_apps if query in n.lower()]
        self.populate_apps(filtered)

    def toggle_start(self):
        if self.start_open:
            self.start_menu.place_forget()
            self.start_open = False
        else:
            # Position above taskbar
            screen_h = self.root.winfo_screenheight()
            self.start_menu.place(x=12, y=screen_h - 680)
            self.start_open = True
            self.search_var.set("")
            self.populate_apps(self.all_apps)

    def launch(self, script):
        path = self.project_root / script
        if path.exists():
            subprocess.Popen([sys.executable, str(path)])
        else:
            messagebox.showwarning("Not found", f"App not found: {script}")

    def launch_and_close(self, script):
        self.launch(script)
        self.toggle_start()

    def restart_system(self):
        if not messagebox.askyesno(
            "Restart",
            "This will restart your computer.\n\n"
            "Unsaved work may be lost.\n"
            "Lin64x will close normally — it does not lock your system.\n\n"
            "Continue?"
        ):
            return
        self._do_power_action("restart")

    def shutdown_system(self):
        if not messagebox.askyesno(
            "Shutdown",
            "This will shut down your computer.\n\n"
            "Unsaved work may be lost.\n"
            "Lin64x will close normally — it does not lock your system.\n\n"
            "Continue?"
        ):
            return
        self._do_power_action("shutdown")

    def _do_power_action(self, action):
        import platform
        system = platform.system()
        try:
            if system == "Windows":
                cmd = ["shutdown", "/r", "/t", "5"] if action == "restart" else ["shutdown", "/s", "/t", "5"]
                subprocess.Popen(cmd)
            elif system == "Linux":
                cmd = ["systemctl", "reboot"] if action == "restart" else ["systemctl", "poweroff"]
                subprocess.Popen(cmd)
            else:
                messagebox.showinfo("Power", f"{action.title()} is not supported on this platform.")
                return
            messagebox.showinfo("Power", f"{action.title()} initiated. You can still cancel from the system dialog if one appears.")
            self.root.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Could not {action}: {e}")

    def do_backup(self):
        """Backup Lin64x config and account files."""
        import shutil
        from datetime import datetime
        from pathlib import Path
        home = Path.home()
        backup_dir = home / "Lin64x_Backups"
        backup_dir.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = backup_dir / f"backup_{stamp}"
        dest.mkdir()
        backed = []
        for name in [".lin64x_accounts.json", ".lin64x_config.json", ".lin64x_web_bookmarks.json", ".lin64x_setup.json"]:
            src = home / name
            if src.exists():
                shutil.copy2(src, dest / name)
                backed.append(name)
        # Also copy SD card if present
        sd = Path("lin64x_sd_card.json")
        if sd.exists():
            shutil.copy2(sd, dest / "lin64x_sd_card.json")
            backed.append("lin64x_sd_card.json")
        if backed:
            messagebox.showinfo("Backup", f"Backup saved to:\n{dest}\n\nFiles: {', '.join(backed)}")
        else:
            messagebox.showinfo("Backup", f"Backup folder created:\n{dest}\n\nNo config files found to copy.")

    def do_restore(self):
        """Restore Lin64x config from a backup folder."""
        import shutil
        from pathlib import Path
        from tkinter import filedialog
        home = Path.home()
        backup_root = home / "Lin64x_Backups"
        initial = str(backup_root) if backup_root.exists() else str(home)
        folder = filedialog.askdirectory(title="Select backup folder to restore", initialdir=initial)
        if not folder:
            return
        src = Path(folder)
        restored = []
        for name in [".lin64x_accounts.json", ".lin64x_config.json", ".lin64x_web_bookmarks.json", ".lin64x_setup.json", "lin64x_sd_card.json"]:
            file = src / name
            if file.exists():
                dest = home / name if name.startswith(".") else Path(name)
                shutil.copy2(file, dest)
                restored.append(name)
        if restored:
            messagebox.showinfo("Restore", f"Restored:\n{', '.join(restored)}\n\nRestart Lin64x apps to apply changes.")
        else:
            messagebox.showwarning("Restore", "No Lin64x config files found in the selected folder.")

    def refresh_account_label(self):
        try:
            info = self._get_account()
            self.account_btn.config(text=info.get("display", "User"))
        except Exception:
            pass

    def swap_account_desktop(self):
        try:
            from tkinter import simpledialog
            # Determine target
            info = self._get_account()
            current_role = info.get("role", "standard")
            target = "admin" if current_role != "administrator" else "user"
            # Import has_password
            try:
                from accounts import has_password
                needs_pwd = has_password(target)
            except Exception:
                needs_pwd = (target == "admin")
            if needs_pwd:
                pwd = simpledialog.askstring("Password", f"Enter password for {target}:", show="*")
                if pwd is None:
                    return
                result = self._swap_account(pwd)
                if result is None:
                    messagebox.showerror("Access Denied", "Incorrect password.")
                    return
            else:
                self._swap_account()
            self.refresh_account_label()
        except Exception:
            pass

    def update_clock(self):
        from datetime import datetime
        self.clock.config(text=datetime.now().strftime("%H:%M  %b %d"))
        self.root.after(10000, self.update_clock)

def main():
    root = tk.Tk()
    app = Win11Desktop(root)
    root.mainloop()

if __name__ == "__main__":
    main()
