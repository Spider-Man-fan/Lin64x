#!/usr/bin/env python3
"""
Lin64x File Explorer (Windows 11 style)
Simple file browser with navigation and basic operations.
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import os
from pathlib import Path

class FileExplorer:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x File Explorer")
        self.root.geometry("900x600")
        self.root.configure(bg="#ffffff")

        self.current_path = Path.home()
        self.create_ui()
        self.refresh()

    def create_ui(self):
        # Toolbar
        toolbar = tk.Frame(self.root, bg="#f3f3f3", height=40)
        toolbar.pack(fill="x")
        toolbar.pack_propagate(False)

        tk.Button(toolbar, text="↑", command=self.go_up, relief="flat").pack(side="left", padx=4, pady=6)
        tk.Button(toolbar, text="Refresh", command=self.refresh, relief="flat").pack(side="left", padx=4)
        tk.Button(toolbar, text="New Folder", command=self.new_folder, relief="flat").pack(side="left", padx=4)

        self.path_var = tk.StringVar()
        path_entry = ttk.Entry(toolbar, textvariable=self.path_var, font=("Segoe UI", 10))
        path_entry.pack(side="left", fill="x", expand=True, padx=8, pady=6)
        path_entry.bind("<Return>", lambda e: self.navigate(self.path_var.get()))

        # File list
        self.tree = ttk.Treeview(self.root, columns=("size", "type"), show="tree headings")
        self.tree.heading("#0", text="Name")
        self.tree.heading("size", text="Size")
        self.tree.heading("type", text="Type")
        self.tree.column("#0", width=400)
        self.tree.column("size", width=100)
        self.tree.column("type", width=120)
        self.tree.pack(fill="both", expand=True, padx=5, pady=5)

        self.tree.bind("<Double-1>", self.on_double_click)

        # Status
        self.status = tk.Label(self.root, text="", bg="#f3f3f3", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        self.path_var.set(str(self.current_path))
        try:
            items = sorted(self.current_path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            for item in items:
                if item.name.startswith("."):
                    continue
                size = ""
                typ = "Folder" if item.is_dir() else "File"
                if item.is_file():
                    try:
                        size = f"{item.stat().st_size:,} B"
                    except Exception:
                        size = ""
                self.tree.insert("", "end", text=item.name, values=(size, typ), tags=(str(item),))
            self.status.config(text=f"{len(items)} items")
        except PermissionError:
            messagebox.showerror("Error", "Permission denied")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def go_up(self):
        if self.current_path.parent != self.current_path:
            self.current_path = self.current_path.parent
            self.refresh()

    def navigate(self, path_str):
        p = Path(path_str)
        if p.exists() and p.is_dir():
            self.current_path = p
            self.refresh()
        else:
            messagebox.showwarning("Invalid", "Path does not exist or is not a directory")

    def on_double_click(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        item = self.tree.item(sel[0])
        path = Path(item["tags"][0])
        if path.is_dir():
            self.current_path = path
            self.refresh()
        else:
            messagebox.showinfo("File", f"Selected: {path.name}\n(Open not implemented in this lite version)")

    def new_folder(self):
        name = simpledialog.askstring("New Folder", "Folder name:")
        if name:
            try:
                (self.current_path / name).mkdir()
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error", str(e))

def main():
    root = tk.Tk()
    app = FileExplorer(root)
    root.mainloop()

if __name__ == "__main__":
    main()
