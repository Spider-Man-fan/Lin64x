# Lin64x OS Apps (Windows 11 style)

Custom hybrid OS applications inspired by Windows 11.

## Apps
- `desktop.py` — Fullscreen desktop shell with taskbar and Start menu
- `settings.py` — Settings app (System, Personalization, Apps, Privacy, About)
- `file_explorer.py` — Simple File Explorer

## Run
```bash
python os_apps/desktop.py          # Launch desktop shell
python os_apps/settings.py         # Settings
python os_apps/file_explorer.py    # File Explorer
```

These apps launch other Lin64x tools and provide a Windows 11-like experience on both Linux and Windows.
