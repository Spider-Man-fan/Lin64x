#!/usr/bin/env python3
"""
web - Lin64x Main Browser
Simple browser interface that opens pages and manages bookmarks.
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import webbrowser
import json
from pathlib import Path

class WebBrowser:
    def __init__(self, root):
        self.root = root
        self.root.title("web — Firefox style")
        self.root.geometry("980x640")
        self.root.configure(bg="#1c1b22")  # Firefox dark background

        self.bookmarks_file = Path.home() / ".lin64x_web_bookmarks.json"
        self.bookmarks = self.load_bookmarks()

        self.create_ui()
        self.load_home()

    def load_bookmarks(self):
        if self.bookmarks_file.exists():
            try:
                with open(self.bookmarks_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return [
            {"name": "Lin64x GitHub", "url": "https://github.com"},
            {"name": "Python Docs", "url": "https://docs.python.org"},
            {"name": "Arch Wiki", "url": "https://wiki.archlinux.org"},
        ]

    def save_bookmarks(self):
        try:
            with open(self.bookmarks_file, "w", encoding="utf-8") as f:
                json.dump(self.bookmarks, f, indent=2)
        except Exception:
            pass

    def create_ui(self):
        # Firefox-style toolbar
        toolbar = tk.Frame(self.root, bg="#2b2a33", height=52)
        toolbar.pack(fill="x")
        toolbar.pack_propagate(False)

        # Navigation buttons (Firefox-like)
        nav_style = {"bg": "#2b2a33", "fg": "#fbfbfe", "relief": "flat", "font": ("Segoe UI", 12),
                     "activebackground": "#42414d", "activeforeground": "#ffffff", "width": 3}

        tk.Button(toolbar, text="←", command=self.go_back, **nav_style).pack(side="left", padx=(8, 1), pady=10)
        tk.Button(toolbar, text="→", command=self.go_forward, **nav_style).pack(side="left", padx=1, pady=10)
        tk.Button(toolbar, text="↻", command=self.reload, **nav_style).pack(side="left", padx=1, pady=10)
        tk.Button(toolbar, text="⌂", command=self.load_home, **nav_style).pack(side="left", padx=(1, 6), pady=10)

        # URL bar (Firefox style)
        url_frame = tk.Frame(toolbar, bg="#42414d", highlightbackground="#52525e", highlightthickness=1)
        url_frame.pack(side="left", fill="x", expand=True, padx=4, pady=10)

        self.url_var = tk.StringVar()
        self.url_entry = tk.Entry(url_frame, textvariable=self.url_var, bg="#42414d", fg="#fbfbfe",
                                  insertbackground="#fbfbfe", relief="flat", font=("Segoe UI", 11),
                                  borderwidth=0)
        self.url_entry.pack(fill="x", expand=True, padx=8, ipady=4)
        self.url_entry.bind("<Return>", lambda e: self.navigate())

        # Bookmark star (Firefox orange accent)
        tk.Button(toolbar, text="★", command=self.add_bookmark, bg="#2b2a33", fg="#ffb338",
                  relief="flat", font=("Segoe UI", 14), activebackground="#42414d",
                  width=3).pack(side="left", padx=(4, 8), pady=10)

        # Main area
        paned = tk.PanedWindow(self.root, orient="horizontal", bg="#1c1b22", sashwidth=4)
        paned.pack(fill="both", expand=True)

        # Bookmarks sidebar (Firefox style)
        sidebar = tk.Frame(paned, bg="#2b2a33", width=230)
        tk.Label(sidebar, text="Bookmarks", bg="#2b2a33", fg="#fbfbfe",
                 font=("Segoe UI", 12, "bold")).pack(pady=(12, 6), padx=10, anchor="w")
        self.bookmark_list = tk.Listbox(sidebar, bg="#2b2a33", fg="#fbfbfe",
                                         selectbackground="#0060df", selectforeground="#ffffff",
                                         relief="flat", font=("Segoe UI", 10),
                                         highlightthickness=0, borderwidth=0)
        self.bookmark_list.pack(fill="both", expand=True, padx=8, pady=4)
        self.bookmark_list.bind("<Double-1>", self.open_bookmark)
        self.refresh_bookmarks()
        paned.add(sidebar)

        # Content area
        content = tk.Frame(paned, bg="#1c1b22")
        self.info = tk.Text(content, bg="#1c1b22", fg="#fbfbfe", font=("Segoe UI", 12),
                            relief="flat", wrap="word", highlightthickness=0)
        self.info.pack(fill="both", expand=True, padx=24, pady=20)
        self.info.tag_config("title", font=("Segoe UI", 22, "bold"), foreground="#ffb338")
        self.info.tag_config("link", foreground="#00ddff")
        self.info.tag_config("subtitle", foreground="#b1b1b3")
        paned.add(content)

        # Status bar
        self.status = tk.Label(self.root, text="Ready", bg="#2b2a33", fg="#b1b1b3",
                               anchor="w", font=("Segoe UI", 9))
        self.status.pack(fill="x", side="bottom")

        self.history = []
        self.history_index = -1

    def refresh_bookmarks(self):
        self.bookmark_list.delete(0, "end")
        for bm in self.bookmarks:
            self.bookmark_list.insert("end", bm["name"])

    def load_home(self):
        self.info.delete("1.0", "end")
        self.info.insert("end", "web\n", "title")
        self.info.insert("end", "Firefox-style browser for Lin64x\n\n", "subtitle")
        self.info.insert("end", "Enter a URL in the address bar and press Enter,\n")
        self.info.insert("end", "or double-click a bookmark on the left.\n\n")
        self.info.insert("end", "Pages open in your system default browser.\n")
        self.info.insert("end", "Bookmarks are saved locally.\n")
        self.url_var.set("")
        self.status.config(text="Home — web")

    def navigate(self):
        url = self.url_var.get().strip()
        if not url:
            return
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        self.url_var.set(url)
        self.open_url(url)

    def open_url(self, url):
        try:
            webbrowser.open(url)
            self.history.append(url)
            self.history_index = len(self.history) - 1
            self.status.config(text=f"Opened: {url}")
            self.info.delete("1.0", "end")
            self.info.insert("end", "Opened in system browser\n", "title")
            self.info.insert("end", f"\n{url}\n", "link")
            self.info.insert("end", "\nThe page has been opened in your default web browser.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def open_bookmark(self, event=None):
        sel = self.bookmark_list.curselection()
        if not sel:
            return
        bm = self.bookmarks[sel[0]]
        self.url_var.set(bm["url"])
        self.open_url(bm["url"])

    def add_bookmark(self):
        url = self.url_var.get().strip()
        if not url:
            url = simpledialog.askstring("Bookmark", "URL:")
            if not url:
                return
        name = simpledialog.askstring("Bookmark", "Name:", initialvalue=url)
        if name:
            self.bookmarks.append({"name": name, "url": url})
            self.save_bookmarks()
            self.refresh_bookmarks()
            self.status.config(text=f"Bookmark added: {name}")

    def go_back(self):
        if self.history_index > 0:
            self.history_index -= 1
            url = self.history[self.history_index]
            self.url_var.set(url)
            self.status.config(text=f"Back: {url}")

    def go_forward(self):
        if self.history_index < len(self.history) - 1:
            self.history_index += 1
            url = self.history[self.history_index]
            self.url_var.set(url)
            self.status.config(text=f"Forward: {url}")

    def reload(self):
        if self.url_var.get():
            self.navigate()

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 300
    root.geometry(f"+{x}+{y}")
    app = WebBrowser(root)
    root.mainloop()

if __name__ == "__main__":
    main()
