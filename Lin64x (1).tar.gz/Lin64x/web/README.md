# web

Lin64x Main Browser.

## Features
- URL bar with Go
- Opens pages in the system default browser
- Bookmarks (saved locally)
- Home screen
- Back / Forward / Reload
- Add bookmark button

## Run
```bash
python web/web.py
```
