#!/usr/bin/env python3
"""
Lin64x Installer (Roblox-style)
Clean setup wizard with progress.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import platform
import shutil
import os
import sys
from pathlib import Path

class RobloxStyleInstaller:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Setup")
        self.root.geometry("520x420")
        self.root.configure(bg="#ffffff")
        self.root.resizable(False, False)

        self.install_path = Path.home() / "Lin64x"
        self.project_root = Path(__file__).parent.parent

        self.create_welcome()

    def clear(self):
        for w in self.root.winfo_children():
            w.destroy()

    def create_welcome(self):
        self.clear()
        # Header bar (Roblox-like red)
        header = tk.Frame(self.root, bg="#e2231a", height=70)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="Lin64x", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#e2231a").pack(pady=16)

        body = tk.Frame(self.root, bg="#ffffff")
        body.pack(fill="both", expand=True, padx=30, pady=20)

        tk.Label(body, text="Welcome to Lin64x Setup", font=("Segoe UI", 16, "bold"),
                 bg="#ffffff", fg="#1a1a1a").pack(anchor="w")
        tk.Label(body, text="This will install Lin64x on your computer.",
                 font=("Segoe UI", 10), bg="#ffffff", fg="#555").pack(anchor="w", pady=(4, 16))

        tk.Label(body, text="Install location:", font=("Segoe UI", 10),
                 bg="#ffffff", fg="#333").pack(anchor="w")
        path_frame = tk.Frame(body, bg="#ffffff")
        path_frame.pack(fill="x", pady=4)
        self.path_var = tk.StringVar(value=str(self.install_path))
        tk.Entry(path_frame, textvariable=self.path_var, font=("Segoe UI", 10),
                 relief="solid", bd=1).pack(side="left", fill="x", expand=True, ipady=4)
        tk.Button(path_frame, text="Browse", command=self.browse, bg="#f0f0f0",
                  relief="flat").pack(side="left", padx=6)

        tk.Label(body, text="Includes desktop shell, settings, tools, and apps.",
                 font=("Segoe UI", 9), bg="#ffffff", fg="#888").pack(anchor="w", pady=(12, 0))

        btn_frame = tk.Frame(self.root, bg="#ffffff")
        btn_frame.pack(side="bottom", fill="x", padx=30, pady=16)
        tk.Button(btn_frame, text="Install", command=self.start_install,
                  bg="#e2231a", fg="white", font=("Segoe UI", 12, "bold"),
                  relief="flat", padx=24, pady=6).pack(side="right")
        tk.Button(btn_frame, text="Cancel", command=self.root.destroy,
                  bg="#f0f0f0", font=("Segoe UI", 10),
                  relief="flat", padx=16, pady=6).pack(side="right", padx=8)

    def browse(self):
        path = filedialog.askdirectory(title="Select install folder")
        if path:
            self.path_var.set(str(Path(path) / "Lin64x"))

    def start_install(self):
        self.install_path = Path(self.path_var.get())
        self.clear()

        header = tk.Frame(self.root, bg="#e2231a", height=70)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="Installing Lin64x", font=("Segoe UI", 18, "bold"),
                 fg="white", bg="#e2231a").pack(pady=18)

        body = tk.Frame(self.root, bg="#ffffff")
        body.pack(fill="both", expand=True, padx=30, pady=30)

        self.status_label = tk.Label(body, text="Preparing...", font=("Segoe UI", 11),
                                      bg="#ffffff", fg="#333")
        self.status_label.pack(anchor="w", pady=(0, 10))

        self.progress = ttk.Progressbar(body, mode="determinate", length=440)
        self.progress.pack(fill="x", pady=8)

        self.percent = tk.Label(body, text="0%", font=("Segoe UI", 10),
                                 bg="#ffffff", fg="#888")
        self.percent.pack(anchor="e")

        self.root.after(300, self.do_install)

    def do_install(self):
        steps = [
            (10, "Creating folders..."),
            (30, "Copying files..."),
            (60, "Setting up desktop..."),
            (80, "Creating shortcuts..."),
            (100, "Finishing..."),
        ]
        try:
            self.install_path.mkdir(parents=True, exist_ok=True)
            self.update_progress(10, "Creating folders...")

            # Copy project files
            if self.project_root.exists():
                for item in self.project_root.iterdir():
                    if item.name.startswith("."):
                        continue
                    dest = self.install_path / item.name
                    if item.is_dir():
                        if dest.exists():
                            shutil.rmtree(dest)
                        shutil.copytree(item, dest)
                    else:
                        shutil.copy2(item, dest)
            self.update_progress(60, "Setting up desktop...")

            # Create a simple launcher script
            launcher = self.install_path / "Start Lin64x.py"
            launcher.write_text(
                "#!/usr/bin/env python3\n"
                "import subprocess, sys\n"
                "from pathlib import Path\n"
                "root = Path(__file__).parent\n"
                "subprocess.Popen([sys.executable, str(root / 'os_apps' / 'desktop.py')])\n"
            )
            self.update_progress(80, "Creating shortcuts...")

            # Desktop shortcut hint
            if platform.system() == "Windows":
                self.create_windows_shortcut()
            self.update_progress(100, "Done")

            self.root.after(400, self.show_done)
        except Exception as e:
            messagebox.showerror("Install Failed", str(e))
            self.create_welcome()

    def update_progress(self, value, text):
        self.progress["value"] = value
        self.percent.config(text=f"{value}%")
        self.status_label.config(text=text)
        self.root.update_idletasks()

    def create_windows_shortcut(self):
        try:
            desktop = Path.home() / "Desktop"
            if desktop.exists():
                bat = desktop / "Lin64x.bat"
                bat.write_text(f'@echo off\npython "{self.install_path / "Start Lin64x.py"}"\n')
        except Exception:
            pass

    def show_done(self):
        self.clear()
        header = tk.Frame(self.root, bg="#e2231a", height=70)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="Lin64x", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#e2231a").pack(pady=16)

        body = tk.Frame(self.root, bg="#ffffff")
        body.pack(fill="both", expand=True, padx=30, pady=30)
        tk.Label(body, text="Installation Complete", font=("Segoe UI", 16, "bold"),
                 bg="#ffffff", fg="#1a1a1a").pack(anchor="w")
        tk.Label(body, text=f"Installed to:\n{self.install_path}",
                 font=("Segoe UI", 10), bg="#ffffff", fg="#555", justify="left").pack(anchor="w", pady=8)

        btn_frame = tk.Frame(self.root, bg="#ffffff")
        btn_frame.pack(side="bottom", fill="x", padx=30, pady=16)
        tk.Button(btn_frame, text="Launch Lin64x", command=self.launch,
                  bg="#e2231a", fg="white", font=("Segoe UI", 12, "bold"),
                  relief="flat", padx=20, pady=6).pack(side="right")
        tk.Button(btn_frame, text="Close", command=self.root.destroy,
                  bg="#f0f0f0", font=("Segoe UI", 10),
                  relief="flat", padx=16, pady=6).pack(side="right", padx=8)

    def launch(self):
        import subprocess
        desktop = self.install_path / "os_apps" / "desktop.py"
        if desktop.exists():
            subprocess.Popen([sys.executable, str(desktop)])
        self.root.destroy()

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 260
    y = (root.winfo_screenheight() // 2) - 210
    root.geometry(f"+{x}+{y}")
    app = RobloxStyleInstaller(root)
    root.mainloop()

if __name__ == "__main__":
    main()
