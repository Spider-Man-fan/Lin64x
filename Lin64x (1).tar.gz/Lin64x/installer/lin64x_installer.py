#!/usr/bin/env python3
"""
Lin64x Python Installer
Cross-platform installer for hybrid Linux/Windows setup tools.
Detects OS, installs deps, configures dual-boot helpers.
"""

import os
import sys
import platform
import subprocess
import shutil
from pathlib import Path

class Lin64xInstaller:
    def __init__(self):
        self.os_type = platform.system()
        self.is_linux = self.os_type == "Linux"
        self.is_windows = self.os_type == "Windows"
        self.project_root = Path(__file__).parent.parent

    def check_python(self):
        print(f"[Lin64x] Python {sys.version}")
        if sys.version_info < (3, 8):
            print("Error: Python 3.8+ required")
            sys.exit(1)

    def install_dependencies(self):
        print("[Lin64x] Installing dependencies...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", 
                                   str(self.project_root / "requirements.txt"), "--quiet"])
            print("Dependencies installed successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Warning: pip install failed: {e}")
            print("Some features may require manual installation of tkinter.")

    def setup_dual_boot_helpers(self):
        if not self.is_linux:
            print("[Lin64x] Dual-boot GRUB helpers are for Linux hosts.")
            return
        print("[Lin64x] Setting up dual-boot configuration examples...")
        boot_dir = self.project_root / "bootloader"
        print(f"Example GRUB config available at: {boot_dir / 'grub.cfg.example'}")
        print("To apply: sudo cp bootloader/grub.cfg.example /etc/grub.d/40_custom")
        print("Then: sudo update-grub")

    def create_desktop_entries(self):
        if self.is_linux:
            desktop = Path.home() / ".local/share/applications/lin64x-editor.desktop"
            desktop.parent.mkdir(parents=True, exist_ok=True)
            content = f"""[Desktop Entry]
Name=Lin64x Code Editor
Exec=python3 {self.project_root / 'editor' / 'lin64x_editor.py'}
Type=Application
Categories=Development;
"""
            desktop.write_text(content)
            print(f"Created desktop entry: {desktop}")
        elif self.is_windows:
            print("[Lin64x] On Windows, you can create a shortcut manually to the editor script.")

    def run(self):
        print("=" * 50)
        print("  Lin64x Hybrid Installer")
        print("  Linux + Windows Integration Suite")
        print("=" * 50)
        self.check_python()
        print(f"Detected OS: {self.os_type}")
        self.install_dependencies()
        self.setup_dual_boot_helpers()
        self.create_desktop_entries()
        print("\n[Lin64x] Installation complete!")
        print("Next steps:")
        print("  - python oobe/oobe_wizard.py     # Launch OOBE")
        print("  - python editor/lin64x_editor.py # Code Editor")
        print("  - python security/lin64x_security.py # Security App")
        print("  - python malware_removal/malware_removal.py # Malware Removal")
        print("  - python app_fixer/app_fixer.py  # App Fixer")
        print("  - python toolbox/toolbox.py      # Toolbox")
        print("  - python installer/roblox_installer.py # Roblox-style Installer")
        print("  - python os_apps/desktop.py      # Windows 11-style Desktop")
        print("  - python cmd/linux4_cmd.py       # Linux4_(Cmd)")
        print("  - python cmd_sudo/cmd_sudo.py    # Windows Command + Sudo")
        print("  - python python/lin_python.py    # Lin(python)")
        print("  - python notepad/win32x64_notepad.py # Win32x64(notepad)")
        print("  - python settings/settings_linux_windows.py # Settings(Linux-windows)")
        print("  - python powershell/win64x_powershell.py # win64x(PowerShell)")
        print("  - python sudo/sudo_commands.py   # Sudo Commands")
        print("  - python troubleshooting/lin64x_troubleshooting.py # Troubleshooting")
        print("  - python vmware/lin64x_vmware.py  # VMware App")
        print("  - python kali/lin64x_kali.py     # Kali Linux App")
        print("  - python ubuntu/ubuntu.py        # Ubuntu App")
        print("  - python ubuntu/terminal/ubuntu_terminal.py # Ubuntu Terminal")
        print("  - python ubuntu/files/ubuntu_files.py # Ubuntu Files")
        print("  - python docker/docker.py        # Docker App")
        print("  - python software_maker/lin64x_software_maker.py # Software Maker")
        print("  - python ai_chaticon/ai_chaticon.py # ai chaticon")
        print("  - python web/web.py              # web browser")
        print("  - python layout/layout_performance.py # Layout Performance")
        print("  - python config/configlin.py     # configlin")
        print("  - python win64store/win64store.py # win64store")
        print("  - python terminate/terminate64xlin.py # terminate64xlin")
        print("  - python visualstudio/visualstudio.py # Visual Studio")
        print("  - python lin64xfile/lin64xfile.py # Lin64xfile")
        print("  - python lin64xcamera/lin64xcamera.py # lin64xcamera")
        print("  - python lin64xcalculator/lin64xcalculator.py # lin64xcalculator")
        print("  - python sd_card/digital_save.py # SD Save Card")

if __name__ == "__main__":
    installer = Lin64xInstaller()
    installer.run()
