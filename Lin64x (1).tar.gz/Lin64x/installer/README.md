# Roblox-style Installer

Clean setup wizard for Lin64x.

## Features
- Welcome screen with install location
- Progress bar during install
- Copies files to the chosen folder
- Creates a launcher
- Launch button when finished
- Red header style similar to Roblox

## Run
```bash
python installer/roblox_installer.py
```
