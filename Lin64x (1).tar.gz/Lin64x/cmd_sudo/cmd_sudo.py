#!/usr/bin/env python3
"""
Lin64x Windows Command + Sudo
Combined terminal that runs Windows commands and Linux sudo commands.
"""

import tkinter as tk
from tkinter import scrolledtext, messagebox, simpledialog, font as tkfont
import subprocess
import threading
import platform
import os
import sys
import shutil

class CmdSudo:
    def __init__(self, root):
        self.root = root
        self.root.title("Windows Command + Sudo")
        self.root.geometry("900x580")
        self.root.configure(bg="#0c0c0c")

        self.is_linux = platform.system() == "Linux"
        self.is_windows = platform.system() == "Windows"
        self.cwd = os.getcwd()
        self.mono = tkfont.Font(family="Consolas", size=11)

        self.create_ui()
        self.write_banner()

    def create_ui(self):
        # Output
        self.output = scrolledtext.ScrolledText(
            self.root, bg="#0c0c0c", fg="#cccccc", insertbackground="#ffffff",
            font=self.mono, relief="flat"
        )
        self.output.pack(fill="both", expand=True, padx=5, pady=5)
        self.output.tag_config("prompt", foreground="#00ff00")
        self.output.tag_config("sudo", foreground="#ff6b6b")
        self.output.tag_config("error", foreground="#ff4444")
        self.output.tag_config("info", foreground="#58a6ff")
        self.output.tag_config("success", foreground="#4ec9b0")

        # Input
        input_frame = tk.Frame(self.root, bg="#0c0c0c")
        input_frame.pack(fill="x", padx=5, pady=(0, 5))

        self.mode_var = tk.StringVar(value="cmd")
        tk.Radiobutton(input_frame, text="Windows Cmd", variable=self.mode_var, value="cmd",
                       bg="#0c0c0c", fg="#00ff00", selectcolor="#1a1a1a").pack(side="left")
        tk.Radiobutton(input_frame, text="Sudo", variable=self.mode_var, value="sudo",
                       bg="#0c0c0c", fg="#ff6b6b", selectcolor="#1a1a1a").pack(side="left", padx=8)

        self.entry = tk.Entry(input_frame, bg="#1a1a1a", fg="#ffffff", insertbackground="#ffffff",
                              font=self.mono, relief="flat")
        self.entry.pack(side="left", fill="x", expand=True, padx=6)
        self.entry.bind("<Return>", self.on_enter)
        self.entry.focus()

        tk.Button(input_frame, text="Run", command=self.on_enter, bg="#0078d4", fg="white",
                  relief="flat").pack(side="left")
        tk.Button(input_frame, text="ipconfig", command=self.run_ipconfig, bg="#107c10", fg="white",
                  relief="flat").pack(side="left", padx=4)
        tk.Button(input_frame, text="ping", command=self.run_ping, bg="#5c2d91", fg="white",
                  relief="flat").pack(side="left", padx=2)
        tk.Button(input_frame, text="whois", command=self.run_whois, bg="#0078d4", fg="white",
                  relief="flat").pack(side="left", padx=2)
        tk.Button(input_frame, text="Explore", command=self.explore_commands, bg="#ff8c00", fg="white",
                  relief="flat").pack(side="left", padx=2)

        # Status
        mode_text = "Linux" if self.is_linux else ("Windows" if self.is_windows else platform.system())
        self.status = tk.Label(self.root, text=f"Windows Command + Sudo | {mode_text}",
                               bg="#1f1f1f", fg="#888", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def write_banner(self):
        banner = """Windows Command + Sudo
Combined terminal for Lin64x

Modes:
  • Windows Cmd  — runs commands via cmd.exe (Windows) or shell (Linux)
  • Sudo         — runs elevated commands (Linux only)

Type a command and press Enter.
Type 'help' for tips, 'clear' to clear, 'exit' to close.
"""
        self.output.insert("end", banner, "info")
        self.output.see("end")

    def on_enter(self, event=None):
        cmd = self.entry.get().strip()
        self.entry.delete(0, "end")
        if not cmd:
            return

        mode = self.mode_var.get()
        prefix = "sudo" if mode == "sudo" else "cmd"
        tag = "sudo" if mode == "sudo" else "prompt"
        self.output.insert("end", f"\n[{prefix}]> {cmd}\n", tag)

        if cmd.lower() == "exit":
            self.root.destroy()
            return
        if cmd.lower() in ("clear", "cls"):
            self.output.delete("1.0", "end")
            self.write_banner()
            return
        if cmd.lower() == "help":
            self.show_help()
            return

        if mode == "sudo":
            self.run_sudo(cmd)
        else:
            self.run_cmd(cmd)

    def run_ipconfig(self):
        """Show the user's IP address (ipconfig / ifconfig)."""
        self.output.insert("end", "\n[ipconfig] Showing IP information...\n", "info")
        def worker():
            try:
                if self.is_windows:
                    result = subprocess.run(["ipconfig"], capture_output=True, text=True, timeout=15)
                else:
                    # Try ip first, then ifconfig
                    result = subprocess.run(["ip", "addr"], capture_output=True, text=True, timeout=10)
                    if result.returncode != 0:
                        result = subprocess.run(["ifconfig"], capture_output=True, text=True, timeout=10)
                output = result.stdout + result.stderr
                if not output.strip():
                    output = "No IP information returned.\n"
                self.root.after(0, lambda: self.append(output, "success"))
            except Exception as e:
                self.root.after(0, lambda: self.append(f"Error getting IP: {e}\n", "error"))
        threading.Thread(target=worker, daemon=True).start()

    def run_ping(self):
        """Ping a host (default 8.8.8.8)."""
        host = simpledialog.askstring("Ping", "Host or IP to ping:", initialvalue="8.8.8.8")
        if not host:
            return
        self.output.insert("end", f"\n[ping] Pinging {host}...\n", "info")
        def worker():
            try:
                if self.is_windows:
                    cmd = ["ping", "-n", "4", host]
                else:
                    cmd = ["ping", "-c", "4", host]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
                output = result.stdout + result.stderr
                if not output.strip():
                    output = f"No response from {host}\n"
                tag = "success" if result.returncode == 0 else "error"
                self.root.after(0, lambda: self.append(output, tag))
            except subprocess.TimeoutExpired:
                self.root.after(0, lambda: self.append("Ping timed out.\n", "error"))
            except Exception as e:
                self.root.after(0, lambda: self.append(f"Error: {e}\n", "error"))
        threading.Thread(target=worker, daemon=True).start()

    def run_whois(self):
        """Run a whois lookup on a domain."""
        domain = simpledialog.askstring("Whois", "Domain to look up:", initialvalue="example.com")
        if not domain:
            return
        self.output.insert("end", f"\n[whois] Looking up {domain}...\n", "info")
        def worker():
            try:
                # Prefer system whois if available
                if shutil.which("whois"):
                    result = subprocess.run(["whois", domain], capture_output=True, text=True, timeout=30)
                    output = result.stdout + result.stderr
                else:
                    output = ("whois command not found on this system.\n"
                              "Install it with:\n"
                              "  Linux: sudo apt install whois\n"
                              "  Windows: available in some packages or use online whois.\n")
                if not output.strip():
                    output = f"No whois data returned for {domain}\n"
                tag = "success" if "not found" not in output.lower() else "error"
                self.root.after(0, lambda: self.append(output, tag))
            except subprocess.TimeoutExpired:
                self.root.after(0, lambda: self.append("Whois timed out.\n", "error"))
            except Exception as e:
                self.root.after(0, lambda: self.append(f"Error: {e}\n", "error"))
        threading.Thread(target=worker, daemon=True).start()

    def explore_commands(self):
        """Show a reference of common Windows and sudo commands."""
        self.output.delete("1.0", "end")
        text = """=== Explore Commands ===

--- Windows Commands (Cmd mode) ---
  ipconfig          Show IP configuration
  ping host         Test connectivity
  systeminfo        Detailed system information
  tasklist          List running processes
  taskkill /IM name Kill a process
  dir               List directory contents
  cd path           Change directory
  echo text         Print text
  whoami            Current user
  netstat -an       Network connections
  chkdsk            Check disk
  sfc /scannow      System file checker (admin)

--- Sudo / Linux Commands (Sudo mode) ---
  apt update        Update package lists
  apt upgrade       Upgrade packages
  systemctl status  Service status
  systemctl restart name
  ufw status        Firewall status
  useradd / userdel Manage users
  chmod / chown     Permissions
  journalctl -xe    System logs
  df -h             Disk usage
  free -h           Memory usage
  ss -tuln          Listening ports

--- Quick Buttons ---
  ipconfig, ping, whois buttons are above.

Type any command in the box and press Enter.
Switch mode with the radio buttons.
"""
        self.output.insert("end", text, "info")
        self.output.see("end")
        self.status.config(text="Command reference shown")

    def show_help(self):
        help_text = """
Help:
  help     Show this message
  clear    Clear screen
  exit     Close window

Windows Cmd mode:
  dir, ipconfig, systeminfo, tasklist, echo, etc.

Sudo mode (Linux):
  Runs with elevated privileges. Dangerous commands require confirmation.
"""
        self.output.insert("end", help_text, "info")
        self.output.see("end")

    def run_cmd(self, cmd):
        def worker():
            try:
                if self.is_windows:
                    full = ["cmd", "/c", cmd]
                else:
                    full = ["bash", "-c", cmd]
                result = subprocess.run(full, cwd=self.cwd, capture_output=True, text=True, timeout=60)
                output = result.stdout + result.stderr
                if not output.strip():
                    output = f"[Exit code {result.returncode}]\n"
                tag = "success" if result.returncode == 0 else "error"
                self.root.after(0, lambda: self.append(output, tag))
            except Exception as e:
                self.root.after(0, lambda: self.append(f"Error: {e}\n", "error"))
        threading.Thread(target=worker, daemon=True).start()

    def run_sudo(self, cmd):
        if not self.is_linux:
            self.append("Sudo is only available on Linux.\n", "error")
            return

        # Safety check
        dangerous = any(x in cmd.lower() for x in ["rm -rf", "mkfs", "dd ", "shutdown", "reboot", "passwd"])
        if dangerous:
            if not messagebox.askyesno("Dangerous", f"This looks dangerous:\n\nsudo {cmd}\n\nRun it?"):
                self.append("Cancelled.\n", "info")
                return
        else:
            if not messagebox.askyesno("Confirm Sudo", f"Run with sudo?\n\n{cmd}"):
                self.append("Cancelled.\n", "info")
                return

        def worker():
            try:
                result = subprocess.run(f"sudo {cmd}", shell=True, cwd=self.cwd,
                                        capture_output=True, text=True, timeout=120)
                output = result.stdout + result.stderr
                if not output.strip():
                    output = f"[Exit code {result.returncode}]\n"
                tag = "success" if result.returncode == 0 else "error"
                self.root.after(0, lambda: self.append(output, tag))
            except Exception as e:
                self.root.after(0, lambda: self.append(f"Error: {e}\n", "error"))
        threading.Thread(target=worker, daemon=True).start()

    def append(self, text, tag=None):
        self.output.insert("end", text, tag)
        self.output.see("end")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 290
    root.geometry(f"+{x}+{y}")
    app = CmdSudo(root)
    root.mainloop()

if __name__ == "__main__":
    main()
