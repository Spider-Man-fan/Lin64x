# Windows Command + Sudo

Combined terminal for Lin64x.

## Modes
- **Windows Cmd** — runs commands via `cmd.exe` (Windows) or shell (Linux)
- **Sudo** — runs elevated commands (Linux only, with confirmation)

## Features
- Switch between modes with radio buttons
- Safety confirmation for sudo
- Extra warning for dangerous commands
- Works on Linux and Windows

## Run
```bash
python cmd_sudo/cmd_sudo.py
```
