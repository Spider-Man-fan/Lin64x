# Lin64x on Arch Linux

## Install from source (recommended)

```bash
# Clone or extract Lin64x
cd Lin64x

# Install dependencies
sudo pacman -S python tk

# Optional
sudo pacman -S powershell ufw

# Run directly
python os_apps/desktop.py
```

## Build a package with makepkg

1. Copy the `arch/PKGBUILD` into the Lin64x root directory (or adjust paths).
2. From the Lin64x root:

```bash
makepkg -si
```

This will install Lin64x to `/opt/lin64x` and create a `lin64x` command + desktop entry.

## After installation

```bash
lin64x                  # Launch desktop shell
python /opt/lin64x/settings/settings_linux_windows.py
python /opt/lin64x/sudo/sudo_commands.py
```

## Notes
- The PKGBUILD is a starting point. You may need to adjust the `package()` function depending on how you organize the source.
- For a proper AUR package, host the source on GitHub and update the `source=` and checksums.
- Dual-boot helpers still require manual GRUB configuration.
