#!/usr/bin/env python3
"""
lin64xcalculator - Lin64x Calculator
Simple scientific-style calculator.
"""

import tkinter as tk
from tkinter import font as tkfont

class Lin64xCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("lin64xcalculator")
        self.root.geometry("340x480")
        self.root.configure(bg="#1e1e1e")
        self.root.resizable(False, False)

        self.expression = ""
        self.create_ui()

    def create_ui(self):
        # Display
        self.display_var = tk.StringVar(value="0")
        display = tk.Entry(self.root, textvariable=self.display_var, font=("Segoe UI", 24),
                           bg="#252526", fg="#ffffff", justify="right", relief="flat",
                           insertbackground="white", state="readonly")
        display.pack(fill="x", padx=12, pady=12, ipady=10)

        # Buttons
        buttons = [
            ["C", "⌫", "%", "/"],
            ["7", "8", "9", "*"],
            ["4", "5", "6", "-"],
            ["1", "2", "3", "+"],
            ["±", "0", ".", "="],
        ]

        btn_frame = tk.Frame(self.root, bg="#1e1e1e")
        btn_frame.pack(fill="both", expand=True, padx=8, pady=4)

        for r, row in enumerate(buttons):
            for c, text in enumerate(row):
                color = "#0078d4" if text == "=" else ("#c42b1c" if text == "C" else "#3c3c3c")
                btn = tk.Button(btn_frame, text=text, font=("Segoe UI", 16),
                                bg=color, fg="white", relief="flat",
                                command=lambda t=text: self.on_button(t))
                btn.grid(row=r, column=c, sticky="nsew", padx=3, pady=3)
            btn_frame.rowconfigure(r, weight=1)
        for c in range(4):
            btn_frame.columnconfigure(c, weight=1)

        # Status
        tk.Label(self.root, text="lin64xcalculator", bg="#1e1e1e", fg="#666",
                 font=("Segoe UI", 8)).pack(pady=4)

    def on_button(self, char):
        if char == "C":
            self.expression = ""
            self.display_var.set("0")
        elif char == "⌫":
            self.expression = self.expression[:-1]
            self.display_var.set(self.expression or "0")
        elif char == "=":
            self.calculate()
        elif char == "±":
            if self.expression.startswith("-"):
                self.expression = self.expression[1:]
            elif self.expression:
                self.expression = "-" + self.expression
            self.display_var.set(self.expression or "0")
        elif char == "%":
            try:
                val = float(self.expression or "0") / 100
                self.expression = str(val)
                self.display_var.set(self.expression)
            except Exception:
                self.display_var.set("Error")
                self.expression = ""
        else:
            if self.display_var.get() == "0" and char not in "+-*/.":
                self.expression = char
            else:
                self.expression += char
            self.display_var.set(self.expression)

    def calculate(self):
        try:
            # Safe eval with limited builtins
            result = eval(self.expression, {"__builtins__": {}}, {})
            # Clean up float display
            if isinstance(result, float) and result.is_integer():
                result = int(result)
            self.expression = str(result)
            self.display_var.set(self.expression)
        except Exception:
            self.display_var.set("Error")
            self.expression = ""

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 170
    y = (root.winfo_screenheight() // 2) - 240
    root.geometry(f"+{x}+{y}")
    app = Lin64xCalculator(root)
    root.mainloop()

if __name__ == "__main__":
    main()
