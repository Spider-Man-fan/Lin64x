# lin64xcalculator

Simple calculator for Lin64x.

## Features
- Basic operations (+ − × ÷)
- Percentage
- Plus/minus toggle
- Clear and backspace
- Dark theme

## Run
```bash
python lin64xcalculator/lin64xcalculator.py
```
