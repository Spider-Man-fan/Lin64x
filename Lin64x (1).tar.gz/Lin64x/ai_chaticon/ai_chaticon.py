#!/usr/bin/env python3
"""
ai chaticon - Lin64x AI Chat Helper
Simple chat interface for getting help with Lin64x tools and general questions.
"""

import tkinter as tk
from tkinter import scrolledtext, font as tkfont
import datetime
import random

class AIChaticon:
    def __init__(self, root):
        self.root = root
        self.root.title("ai chaticon")
        self.root.geometry("700x620")
        self.root.configure(bg="#0d1117")

        self.mono = tkfont.Font(family="Segoe UI", size=10)
        self.chat_font = tkfont.Font(family="Segoe UI", size=11)

        self.create_ui()
        self.add_message("ai chaticon", "Hello! I'm ai chaticon, your Lin64x helper.\nAsk me about the tools, how to use something, or type 'help'.", "bot")

    def create_ui(self):
        # Header
        header = tk.Frame(self.root, bg="#161b22", height=50)
        header.pack(fill="x")
        tk.Label(header, text="ai chaticon", font=("Segoe UI", 16, "bold"),
                 fg="#58a6ff", bg="#161b22").pack(side="left", padx=15, pady=10)
        tk.Label(header, text="Lin64x AI Chat Helper", font=("Segoe UI", 9),
                 fg="#8b949e", bg="#161b22").pack(side="left")

        # Chat area
        self.chat = scrolledtext.ScrolledText(self.root, bg="#0d1117", fg="#c9d1d9",
                                               font=self.chat_font, relief="flat", wrap="word",
                                               state="disabled")
        self.chat.pack(fill="both", expand=True, padx=10, pady=10)
        self.chat.tag_config("user", foreground="#58a6ff", font=("Segoe UI", 11, "bold"))
        self.chat.tag_config("bot", foreground="#4ec9b0")
        self.chat.tag_config("time", foreground="#666", font=("Segoe UI", 8))

        # Input
        input_frame = tk.Frame(self.root, bg="#0d1117")
        input_frame.pack(fill="x", padx=10, pady=(0, 10))

        self.entry = tk.Entry(input_frame, bg="#21262d", fg="#ffffff", insertbackground="#ffffff",
                              font=self.mono, relief="flat")
        self.entry.pack(side="left", fill="x", expand=True, ipady=6, padx=(0, 6))
        self.entry.bind("<Return>", self.send)

        tk.Button(input_frame, text="Send", command=self.send, bg="#238636", fg="white",
                  relief="flat", padx=16).pack(side="right")

    def add_message(self, sender, text, tag):
        self.chat.config(state="normal")
        time = datetime.datetime.now().strftime("%H:%M")
        self.chat.insert("end", f"[{time}] ", "time")
        self.chat.insert("end", f"{sender}: ", tag)
        self.chat.insert("end", f"{text}\n\n")
        self.chat.config(state="disabled")
        self.chat.see("end")

    def send(self, event=None):
        msg = self.entry.get().strip()
        if not msg:
            return
        self.entry.delete(0, "end")
        self.add_message("You", msg, "user")
        reply = self.get_reply(msg)
        self.root.after(300, lambda: self.add_message("ai chaticon", reply, "bot"))

    def get_reply(self, msg):
        m = msg.lower()
        if m in ("help", "?", "commands"):
            return ("I can help with Lin64x tools:\n"
                    "• Software Maker — write & test code\n"
                    "• Settings — system info & Lin64xwin64P\n"
                    "• Sudo Commands — elevated Linux commands\n"
                    "• Kali Linux — security tools reference\n"
                    "• Troubleshooting — common Linux fixes\n"
                    "• VMware — virtual machine helper\n"
                    "Ask me 'how do I use X' or just chat!")
        if "software maker" in m or "code" in m:
            return "Software Maker lets you write Python, Tkinter, C++, or Java. Use Check Code to validate, then Run / Test to execute."
        if "settings" in m or "processor" in m or "win64p" in m:
            return "Open Settings(Linux-windows) and click Lin64xwin64P to see the hidden Windows processor info."
        if "sudo" in m:
            return "Sudo Commands runs elevated commands on Linux. It checks if the command looks safe and asks for confirmation."
        if "kali" in m:
            return "The Kali Linux app is a reference for common penetration testing tools. Only use them on systems you have permission to test."
        if "troubleshoot" in m or "problem" in m:
            return "Lin64x Troubleshooting covers boot, network, packages, permissions, display, disk, and services with suggested fixes."
        if "vmware" in m or "virtual" in m:
            return "The VMware app can launch VMware, open .vmx files, and create basic VM templates."
        if "hello" in m or "hi" in m:
            return random.choice(["Hello! How can I help with Lin64x today?", "Hi there! Ask me about any tool.", "Hey! What do you need help with?"])
        if "thank" in m:
            return "You're welcome! Let me know if you need anything else."
        return ("I'm a simple helper for Lin64x. Try asking about:\n"
                "Software Maker, Settings, Sudo, Kali, Troubleshooting, or VMware.\n"
                "Or type 'help' for a list.")

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 350
    y = (root.winfo_screenheight() // 2) - 310
    root.geometry(f"+{x}+{y}")
    app = AIChaticon(root)
    root.mainloop()

if __name__ == "__main__":
    main()
