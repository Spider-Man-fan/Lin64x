# ai chaticon

Lin64x AI Chat Helper.

## Features
- Simple chat interface
- Help with Lin64x tools (Software Maker, Settings, Sudo, Kali, Troubleshooting, VMware, etc.)
- Quick replies for common questions
- Dark themed UI

## Run
```bash
python ai_chaticon/ai_chaticon.py
```

Type `help` inside the chat for a list of topics.
