# win64x(PowerShell)

Hybrid PowerShell console and .ps1 runner for Lin64x.

## Features
- Interactive PowerShell commands
- Run .ps1 script files
- Auto-detects `pwsh` or `powershell`
- Works on Windows (native) and Linux (if PowerShell Core is installed)
- Dark PowerShell-style UI

## Run
```bash
python powershell/win64x_powershell.py
```

On Linux, install PowerShell first if needed:
```bash
sudo apt install powershell
# or
snap install powershell
```
