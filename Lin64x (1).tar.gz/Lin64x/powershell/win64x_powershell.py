#!/usr/bin/env python3
"""
win64x(PowerShell) - Lin64x PowerShell Runner
Hybrid PowerShell console and .ps1 script runner for Linux and Windows.
"""

import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox, font as tkfont
import subprocess
import threading
import os
import platform
import sys
import shutil

class Win64xPowerShell:
    def __init__(self, root):
        self.root = root
        self.root.title("win64x(PowerShell)")
        self.root.geometry("900x580")
        self.root.configure(bg="#012456")

        self.is_windows = platform.system() == "Windows"
        self.is_linux = platform.system() == "Linux"
        self.cwd = os.getcwd()
        self.ps_cmd = self.detect_powershell()

        self.mono = tkfont.Font(family="Consolas", size=11)

        self.create_ui()
        self.write_banner()

    def detect_powershell(self):
        # Prefer pwsh (PowerShell Core / 7+), then powershell (Windows PowerShell)
        for cmd in ["pwsh", "powershell"]:
            if shutil.which(cmd):
                return cmd
        return None

    def create_ui(self):
        # Output
        self.output = scrolledtext.ScrolledText(
            self.root, bg="#012456", fg="#cccccc", insertbackground="#ffffff",
            font=self.mono, relief="flat"
        )
        self.output.pack(fill="both", expand=True, padx=5, pady=5)
        self.output.tag_config("prompt", foreground="#ffff00")
        self.output.tag_config("error", foreground="#ff6b6b")
        self.output.tag_config("info", foreground="#00ccff")
        self.output.tag_config("success", foreground="#00ff00")

        # Input
        input_frame = tk.Frame(self.root, bg="#012456")
        input_frame.pack(fill="x", padx=5, pady=(0, 5))

        self.prompt_label = tk.Label(input_frame, text="PS>", fg="#ffff00", bg="#012456", font=self.mono)
        self.prompt_label.pack(side="left")

        self.entry = tk.Entry(input_frame, bg="#012456", fg="#ffffff", insertbackground="#ffffff",
                              font=self.mono, relief="flat", borderwidth=0)
        self.entry.pack(side="left", fill="x", expand=True, padx=5)
        self.entry.bind("<Return>", self.on_enter)
        self.entry.focus()

        # Toolbar
        toolbar = tk.Frame(self.root, bg="#001a33")
        toolbar.pack(fill="x", side="bottom")
        tk.Button(toolbar, text="Run .ps1", command=self.run_ps1, bg="#0078d4", fg="white", relief="flat").pack(side="left", padx=4, pady=4)
        tk.Button(toolbar, text="Clear", command=self.clear, bg="#333", fg="white", relief="flat").pack(side="left", padx=4)
        status_text = f"win64x(PowerShell) | {self.ps_cmd or 'Not found'} | {platform.system()}"
        tk.Label(toolbar, text=status_text, bg="#001a33", fg="#888", font=("Segoe UI", 8)).pack(side="right", padx=8)

    def write_banner(self):
        if self.ps_cmd:
            banner = f"""win64x(PowerShell) - Lin64x PowerShell Console
Detected: {self.ps_cmd}
Type PowerShell commands or use 'Run .ps1' to execute scripts.
Type 'help' for tips, 'exit' to close.
"""
        else:
            banner = """win64x(PowerShell)
PowerShell not found on this system.

On Windows: PowerShell is usually pre-installed.
On Linux: Install with:
  sudo apt install powershell   (or snap install powershell)
  or download from https://github.com/PowerShell/PowerShell
"""
        self.output.insert("end", banner, "info")
        self.output.see("end")

    def clear(self):
        self.output.delete("1.0", "end")
        self.write_banner()

    def on_enter(self, event=None):
        cmd = self.entry.get().strip()
        self.entry.delete(0, "end")
        if not cmd:
            return

        self.output.insert("end", f"PS> {cmd}\n", "prompt")

        if cmd.lower() == "exit":
            self.root.destroy()
            return
        if cmd.lower() == "help":
            self.show_help()
            return
        if cmd.lower() in ("clear", "cls"):
            self.clear()
            return

        if not self.ps_cmd:
            self.output.insert("end", "PowerShell is not installed.\n", "error")
            self.output.see("end")
            return

        self.run_command(cmd)

    def show_help(self):
        help_text = """
Tips:
  help              Show this message
  clear / cls       Clear screen
  exit              Close window
  Get-Date          Example PowerShell command
  Get-Process       List processes

Use the 'Run .ps1' button to execute script files.
"""
        self.output.insert("end", help_text, "info")
        self.output.see("end")

    def run_command(self, cmd):
        def worker():
            try:
                full_cmd = [self.ps_cmd, "-NoProfile", "-Command", cmd]
                result = subprocess.run(
                    full_cmd, cwd=self.cwd,
                    capture_output=True, text=True, timeout=60
                )
                output = result.stdout
                if result.stderr:
                    output += result.stderr
                if not output.strip():
                    output = f"[Exit code {result.returncode}]\n"
                self.root.after(0, lambda: self.append(output))
            except subprocess.TimeoutExpired:
                self.root.after(0, lambda: self.append("Command timed out.\n", "error"))
            except Exception as e:
                self.root.after(0, lambda: self.append(f"Error: {e}\n", "error"))

        threading.Thread(target=worker, daemon=True).start()

    def append(self, text, tag=None):
        self.output.insert("end", text, tag)
        self.output.see("end")

    def run_ps1(self):
        if not self.ps_cmd:
            messagebox.showwarning("PowerShell missing", "PowerShell is not installed on this system.")
            return
        path = filedialog.askopenfilename(filetypes=[("PowerShell scripts", "*.ps1"), ("All files", "*.*")])
        if not path:
            return
        self.output.insert("end", f"\n--- Running {os.path.basename(path)} ---\n", "info")
        def worker():
            try:
                result = subprocess.run(
                    [self.ps_cmd, "-NoProfile", "-File", path],
                    cwd=os.path.dirname(path) or self.cwd,
                    capture_output=True, text=True, timeout=120
                )
                output = result.stdout + result.stderr
                if not output.strip():
                    output = f"[Exit code {result.returncode}]\n"
                self.root.after(0, lambda: self.append(output))
            except Exception as e:
                self.root.after(0, lambda: self.append(f"Error: {e}\n", "error"))
        threading.Thread(target=worker, daemon=True).start()

def main():
    root = tk.Tk()
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 450
    y = (root.winfo_screenheight() // 2) - 290
    root.geometry(f"+{x}+{y}")
    app = Win64xPowerShell(root)
    root.mainloop()

if __name__ == "__main__":
    main()
