#!/usr/bin/env python3
"""
Lin64x Windows 11-style OOBE Wizard
Multi-step Out-of-Box Experience for hybrid setup.
Simulates language selection, region, privacy, and hybrid configuration.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import platform

class OOBEWizard:
    def __init__(self, root):
        self.root = root
        self.root.title("Lin64x Setup - Windows 11 Style OOBE")
        self.root.geometry("800x600")
        self.root.configure(bg="#1a1a1a")
        
        self.step = 0
        self.steps = [
            self.step_welcome,
            self.step_language,
            self.step_region,
            self.step_privacy,
            self.step_hybrid,
            self.step_finish
        ]
        self.data = {}
        
        self.container = tk.Frame(root, bg="#1a1a1a")
        self.container.pack(fill="both", expand=True, padx=40, pady=40)
        
        self.show_step()

    def clear_container(self):
        for widget in self.container.winfo_children():
            widget.destroy()

    def show_step(self):
        self.clear_container()
        if self.step < len(self.steps):
            self.steps[self.step]()
        else:
            self.root.quit()

    def next_step(self):
        self.step += 1
        self.show_step()

    def step_welcome(self):
        tk.Label(self.container, text="Welcome to Lin64x", font=("Segoe UI", 28, "bold"),
                 fg="white", bg="#1a1a1a").pack(pady=40)
        tk.Label(self.container, text="Hybrid Linux & Windows Experience", font=("Segoe UI", 14),
                 fg="#a0a0a0", bg="#1a1a1a").pack(pady=10)
        tk.Label(self.container, text="Let's set up your hybrid environment.", font=("Segoe UI", 12),
                 fg="#cccccc", bg="#1a1a1a").pack(pady=20)
        
        btn = tk.Button(self.container, text="Get started", font=("Segoe UI", 12),
                        bg="#0078d4", fg="white", relief="flat", padx=30, pady=10,
                        command=self.next_step)
        btn.pack(pady=40)

    def step_language(self):
        tk.Label(self.container, text="Select your language", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#1a1a1a").pack(pady=30)
        
        languages = ["English (United States)", "Español", "Français", "Deutsch", "中文"]
        self.lang_var = tk.StringVar(value=languages[0])
        for lang in languages:
            ttk.Radiobutton(self.container, text=lang, variable=self.lang_var, value=lang).pack(anchor="w", pady=5)
        
        tk.Button(self.container, text="Next", command=self.save_and_next, 
                  bg="#0078d4", fg="white", relief="flat", padx=20, pady=8).pack(pady=30)

    def step_region(self):
        tk.Label(self.container, text="Choose your region", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#1a1a1a").pack(pady=30)
        regions = ["United States", "United Kingdom", "Canada", "Germany", "Japan", "Other"]
        self.region_var = tk.StringVar(value=regions[0])
        combo = ttk.Combobox(self.container, textvariable=self.region_var, values=regions, width=40)
        combo.pack(pady=20)
        tk.Button(self.container, text="Next", command=self.save_and_next,
                  bg="#0078d4", fg="white", relief="flat", padx=20, pady=8).pack(pady=30)

    def step_privacy(self):
        tk.Label(self.container, text="Privacy settings", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#1a1a1a").pack(pady=30)
        self.privacy_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self.container, text="Send optional diagnostic data (simulated)", 
                        variable=self.privacy_var).pack(pady=10)
        ttk.Checkbutton(self.container, text="Allow location access for hybrid features", 
                        variable=tk.BooleanVar(value=False)).pack(pady=10)
        tk.Button(self.container, text="Accept", command=self.save_and_next,
                  bg="#0078d4", fg="white", relief="flat", padx=20, pady=8).pack(pady=30)

    def step_hybrid(self):
        tk.Label(self.container, text="Hybrid Configuration", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#1a1a1a").pack(pady=30)
        tk.Label(self.container, text=f"Detected OS: {platform.system()}", 
                 fg="#cccccc", bg="#1a1a1a").pack(pady=10)
        tk.Label(self.container, text="Lin64x will configure dual-boot helpers and shared tools.",
                 fg="#a0a0a0", bg="#1a1a1a", wraplength=500).pack(pady=10)
        tk.Button(self.container, text="Configure Hybrid", command=self.next_step,
                  bg="#107c10", fg="white", relief="flat", padx=20, pady=8).pack(pady=30)

    def step_finish(self):
        tk.Label(self.container, text="You're all set!", font=("Segoe UI", 28, "bold"),
                 fg="white", bg="#1a1a1a").pack(pady=50)
        tk.Label(self.container, text="Lin64x hybrid tools are ready.\nLaunch the Code Editor or SD Save Card next.",
                 fg="#cccccc", bg="#1a1a1a", font=("Segoe UI", 12)).pack(pady=20)
        tk.Button(self.container, text="Finish", command=self.root.quit,
                  bg="#0078d4", fg="white", relief="flat", padx=30, pady=10).pack(pady=40)

    def save_and_next(self):
        # Simple data collection (extend as needed)
        if hasattr(self, 'lang_var'):
            self.data['language'] = self.lang_var.get()
        if hasattr(self, 'region_var'):
            self.data['region'] = self.region_var.get()
        self.next_step()

def main():
    root = tk.Tk()
    # Center window
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 400
    y = (root.winfo_screenheight() // 2) - 300
    root.geometry(f"+{x}+{y}")
    app = OOBEWizard(root)
    root.mainloop()
    print("OOBE completed. Collected data:", app.data)

if __name__ == "__main__":
    main()
