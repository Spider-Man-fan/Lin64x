# Lin64x Bootloader Component

Provides example configurations for dual-booting Linux and Windows.

## GRUB Setup

1. Backup your current GRUB config.
2. Copy relevant menuentry blocks from `grub.cfg.example` into `/etc/grub.d/40_custom`.
3. Run `sudo update-grub`.
4. Reboot and test carefully.

## Other Bootloaders
- systemd-boot
- rEFInd
- Limine

Always test in a VM first. Incorrect bootloader configs can make a system unbootable.

## Hybrid Notes
Lin64x tools can run from either OS once dual-boot is established.
