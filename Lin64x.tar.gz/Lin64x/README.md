# Lin64x - Linux & Windows Hybrid Software Suite

**Lin64x** is a hybrid software project designed for seamless Linux and Windows integration. It includes components for dual-boot management, a Windows 11-style OOBE (Out-of-Box Experience) wizard, a digital SD save card system, kernel/bootloader stubs, a Python installer, and a cross-platform Linux-focused code editor.

> **Important**: This is a foundational/open-source starter project. Full custom kernel/bootloader for production hybrid OS requires advanced low-level development, hardware testing, and significant engineering. Use for learning, dual-boot helpers, and tool development. Not a complete replacement OS.

## Features

- **Python Installer** (`.py`): Cross-platform setup for dependencies and configurations.
- **Windows 11 OOBE Wizard**: Multi-step setup experience (language, region, privacy, etc.).
- **SD Digital Save Card**: Virtual storage / save state manager for data persistence.
- **Kernel Stub**: Minimal example kernel source for educational dual-boot/hybrid experiments.
- **Bootloader Configs**: GRUB examples for Linux + Windows dual-boot.
- **Linux Code Editor App**: Lightweight, cross-platform code editor with basic syntax support.
- Hybrid focus: Runs tools on both Linux and Windows; assists dual-boot setups.

## Project Structure

```
Lin64x/
├── installer/lin64x_installer.py   # Main installer
├── oobe/oobe_wizard.py             # OOBE experience
├── editor/lin64x_editor.py         # Code editor
├── sd_card/digital_save.py         # SD digital save
├── kernel/minimal_kernel.c         # Kernel example
├── bootloader/grub.cfg.example     # Bootloader config
├── requirements.txt
└── README.md
```

## Quick Start

### Prerequisites
- Python 3.8+
- For full dual-boot: Linux with GRUB, Windows 10/11
- Optional: cross-compiler for kernel builds

### Install & Run

```bash
# Clone (after you push to GitHub)
git clone https://github.com/YOUR_USERNAME/Lin64x.git
cd Lin64x

# Install dependencies
pip install -r requirements.txt

# Run installer
python installer/lin64x_installer.py

# Launch OOBE wizard
python oobe/oobe_wizard.py

# Launch code editor
python editor/lin64x_editor.py

# SD save tool
python sd_card/digital_save.py
```

## Dual-Boot / Hybrid Setup Notes

1. Use the installer on Linux to generate GRUB entries.
2. Backup data before any partition changes.
3. For Windows 11 OOBE customization, the wizard simulates/guides setup steps.
4. Kernel/bootloader are educational stubs — integrate with existing Linux kernel builds for real use.

## Development

- Written primarily in Python for portability.
- Kernel in C (requires freestanding compilation).
- Contributions welcome for improving dual-boot reliability, GUI polish, and real kernel integration.

## License

MIT License - See LICENSE file.

## Disclaimer

This software is provided "as is". Dual-boot and low-level operations can damage data or systems if misused. Test in VMs (QEMU, VirtualBox) first. Not affiliated with Microsoft or the Linux kernel project.

---

**Make it yours**: Fork, customize the OOBE branding, expand the editor, or build a full custom distro on top of this foundation.
