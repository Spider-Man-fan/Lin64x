#!/usr/bin/env python3
"""
Lin64x SD Digital Save Card
Virtual digital storage / save state manager.
Simulates SD card operations for hybrid data persistence.
"""

import os
import json
import hashlib
from pathlib import Path
from datetime import datetime

class DigitalSaveCard:
    def __init__(self, card_path="lin64x_sd_card.json"):
        self.card_path = Path(card_path)
        self.data = self.load()

    def load(self):
        if self.card_path.exists():
            with open(self.card_path, "r") as f:
                return json.load(f)
        return {"saves": {}, "metadata": {"created": datetime.now().isoformat(), "version": "1.0"}}

    def save(self):
        with open(self.card_path, "w") as f:
            json.dump(self.data, f, indent=2)
        print(f"[SD Card] Saved to {self.card_path}")

    def create_save(self, name, content):
        save_id = hashlib.md5(name.encode()).hexdigest()[:8]
        self.data["saves"][save_id] = {
            "name": name,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "size": len(content)
        }
        self.save()
        return save_id

    def list_saves(self):
        print("=== Digital SD Save Card ===")
        for sid, info in self.data["saves"].items():
            print(f"  [{sid}] {info['name']} ({info['size']} bytes) - {info['timestamp']}")
        if not self.data["saves"]:
            print("  No saves yet.")

    def load_save(self, save_id):
        return self.data["saves"].get(save_id, {}).get("content")

def main():
    card = DigitalSaveCard()
    print("Lin64x SD Digital Save Card")
    print("Commands: create <name> <text>, list, load <id>, quit")
    
    while True:
        cmd = input("> ").strip().split(maxsplit=2)
        if not cmd:
            continue
        action = cmd[0].lower()
        if action == "quit":
            break
        elif action == "list":
            card.list_saves()
        elif action == "create" and len(cmd) >= 3:
            sid = card.create_save(cmd[1], cmd[2])
            print(f"Created save: {sid}")
        elif action == "load" and len(cmd) >= 2:
            content = card.load_save(cmd[1])
            print(content if content else "Save not found")
        else:
            print("Unknown command")

if __name__ == "__main__":
    main()
